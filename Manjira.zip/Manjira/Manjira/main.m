//
//  main.m
//  Manjira
//
//  Created by 小小 on 20/11/2556.
//  Copyright (c) 2556 BE 星凤. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
   return NSApplicationMain(argc, (const char **)argv);
}
