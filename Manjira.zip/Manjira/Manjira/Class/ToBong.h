//
//  Shaders.h
//  Benjarong
//
//  Created by 小小 on 4/1/2554.
//

#import <Cocoa/Cocoa.h>


@interface ToBong : NSObject {

}

+ (BOOL)compileShader:(GLuint *)shader type:(GLenum)type filePath:(NSString *)filePath;
+ (unsigned int)createShaderProgramWithVertexShader:(GLuint)vertexShader andFragmentShader:(GLuint)fragmentShader;

+ (BOOL)linkAndValidateProgram:(GLuint)program;

//+ (BOOL)validateProgram:(GLuint)prog;
//+ (unsigned int)createShaderProgramWithVertexShader:(NSString *)vertexShaderName
//                       fragmentShader:(NSString *)fragmentShaderName
//							  andUniformsArray:(unsigned int *)uniformsArray;
@end
