//
//  TinhPhanDang4x4.m
//  Manjira
//
//  Created by 小小 on 10/10/2557.
//

#import "TinhPhanDang4x4.h"
#import "ThongTinPhanDang.h"
#import "GiaiThuatPhanDang.h"

@implementation TinhPhanDang4x4

- (id)initVoiThongTinPhanDang:(ThongTinPhanDang *)thongTinPhanDang soLuongHang:(unsigned short)_soLuongHang soLuongCot:(unsigned short)_soLuongCot; {
   
   // ---- coi trừng cho các hàng cuối
   unsigned short beCao = [thongTinPhanDang beCao];
   beRong = [thongTinPhanDang beRong];
   unsigned short _soHang = [thongTinPhanDang soHangDangTinh];
   unsigned short _soCot = [thongTinPhanDang soCotDangTinh];
   
   // ---- xem nếu ra ngoài phạm vi ảnh, hơn bề cao ảnh
   if( _soHang >= beCao)
      return NULL;
   if( _soCot >= beRong)
      return NULL;

   self = [super init];
   
   if( self ) {
      // ---- coi chừng đi ra ngoài phạm vi ảnh
      if( _soHang + _soLuongHang >= beCao ) {
         _soLuongHang = beCao - _soHang;
      }
      
      if( _soCot + _soLuongCot >= beRong ) {
         _soLuongCot = beRong - _soCot;
      }

      // ---- số hàng và cột của thành phần chuẩn bị tính
      soHang = _soHang;
      soLuongHang = _soLuongHang;
      soCot = _soCot;
      soLuongCot = _soLuongCot;
      
      
      // ---- chứa bước trong không gian phân dạng
      buoc = [thongTinPhanDang buocTinh];
      buocTinhPhanTu = buoc*0.25;
      banKinhNghiTinhMu2 = [thongTinPhanDang banKinhNghiTinhMu2];
      
      // ---- tính cạnh trái dưới của thành phần ảnh đang tính
      gocX = soCot * buoc + [thongTinPhanDang gocX];
      gocY = soHang * buoc + [thongTinPhanDang gocY];
      beRong = [thongTinPhanDang beRong];
      
      tinhJulia = [thongTinPhanDang tinhJulia];
      hangSoJuliaX = [thongTinPhanDang hangSoThat];
      hangSoJuliaY = [thongTinPhanDang hangSoAo];
      
      soDiem = 0;
      // ---- số lượng điểm ảnh trong thành phần
      soLuongDiem = soLuongCot*soLuongHang;
      
      // ---- tính địa chỉ đến đầu thành phần trong ảnh
      diaChi = (soHang * beRong + soCot) << 2;
      diaChiCuoi = beCao*beRong << 2;
      
      cot = 0;
      hang = 0;
      x = gocX;
      y = gocY;
      
      mu = [thongTinPhanDang mu];
      lapLaiToiDa = [thongTinPhanDang soLapLaiToiDa];
      
      mangSoLapLai = [thongTinPhanDang mangSoLapLai];
   }
   
   return self;
}


#pragma mark ---- Main
- (void)main {
   
   if( ![self isCancelled] ) {
      
      while( soDiem < soLuongDiem ) {
         // ---- tính
         unsigned int soLuongLapLai0 = 0;
         unsigned int soLuongLapLai1 = 0;
         unsigned int soLuongLapLai2 = 0;
         unsigned int soLuongLapLai3 = 0;
         
         if( tinhJulia ) {
            soLuongLapLai0 = [giaiThuat tinhDiemThat:x-buocTinhPhanTu ao:y-buocTinhPhanTu
                                          hangSoThat:hangSoJuliaX ao:hangSoJuliaY banKinhThoatMu2:banKinhNghiTinhMu2 mu:mu
                                      gioiHanhLapLai:lapLaiToiDa];
            soLuongLapLai1 = [giaiThuat tinhDiemThat:x+buocTinhPhanTu ao:y-buocTinhPhanTu
                                          hangSoThat:hangSoJuliaX ao:hangSoJuliaY banKinhThoatMu2:banKinhNghiTinhMu2 mu:mu
                                      gioiHanhLapLai:lapLaiToiDa];
            soLuongLapLai2 = [giaiThuat tinhDiemThat:x-buocTinhPhanTu ao:y+buocTinhPhanTu
                                          hangSoThat:hangSoJuliaX ao:hangSoJuliaY banKinhThoatMu2:banKinhNghiTinhMu2 mu:mu
                                      gioiHanhLapLai:lapLaiToiDa];
            soLuongLapLai3 = [giaiThuat tinhDiemThat:x+buocTinhPhanTu ao:y+buocTinhPhanTu
                                          hangSoThat:hangSoJuliaX ao:hangSoJuliaY banKinhThoatMu2:banKinhNghiTinhMu2 mu:mu
                                      gioiHanhLapLai:lapLaiToiDa];
         }
         else {
            soLuongLapLai0 = [giaiThuat tinhDiemThat:x-buocTinhPhanTu ao:y-buocTinhPhanTu
                                     banKinhThoatMu2:banKinhNghiTinhMu2 mu:mu gioiHanhLapLai:lapLaiToiDa];
            soLuongLapLai1 = [giaiThuat tinhDiemThat:x+buocTinhPhanTu ao:y-buocTinhPhanTu
                                     banKinhThoatMu2:banKinhNghiTinhMu2 mu:mu gioiHanhLapLai:lapLaiToiDa];
            soLuongLapLai2 = [giaiThuat tinhDiemThat:x-buocTinhPhanTu ao:y+buocTinhPhanTu
                                     banKinhThoatMu2:banKinhNghiTinhMu2 mu:mu gioiHanhLapLai:lapLaiToiDa];
            soLuongLapLai3 = [giaiThuat tinhDiemThat:x+buocTinhPhanTu ao:y+buocTinhPhanTu
                                     banKinhThoatMu2:banKinhNghiTinhMu2 mu:mu gioiHanhLapLai:lapLaiToiDa];
         }
         
         // ---- giữ số lặp vòng tính
         if( diaChi < diaChiCuoi ) {
         mangSoLapLai[diaChi] = soLuongLapLai0;
         mangSoLapLai[diaChi+1] = soLuongLapLai1;
         mangSoLapLai[diaChi+2] = soLuongLapLai2;
         mangSoLapLai[diaChi+3] = soLuongLapLai3;
         }
         else {
      NSLog( @"TinhPhanDang4x4: SAI LẦM: diaChi %d/%d  soCot %d %d/%d  soHang %d: %d/%d", diaChi, diaChiCuoi, soCot, cot, soLuongCot, soHang, hang, soLuongHang );
         }
         
         // ---- xem tính hàng xong chưa
         cot++;
         if( cot < soLuongCot ) {
            x += buoc;
            diaChi += 4;
         }
         else {
            if( [self isCancelled] )
               return;
            cot = soCot;   // trở lại đầu thành phần
            hang++;
            
            y += buoc;
            // ---- trở lại cạnh trái của thành phần
            x = gocX;
            
            // ---- nâng cấp địa chỉ co hàng tiếp thep
            diaChi = (beRong*(soHang + hang) + soCot) << 2;
         }

         soDiem++;
      }

      // ---- kêu tính chùm tiếp
      [[NSNotificationCenter defaultCenter] postNotificationName:@"星凤NângCấpẢnhXuất" object:self];
   }
   
}


#pragma mark ---- Biến
@synthesize soHang;
@synthesize soLuongHang;
@synthesize soCot;
@synthesize soLuongCot;

@synthesize giaiThuat;

@end
