//
//  ExrCompression.m
//  OpenEXR
//
//  Created by 小小 on 20/12/2554.
//  Copyright (c) 2554 BE __MyCompanyName__. All rights reserved.
//

#import "ExrCompressorZIP.h"
#import "ExrBangThanhPhan.h"
#import "ExrKenh.h"
#import "ImfFilter.h"
#import "zlib.h"

#import "ImfConstants.h"

@implementation ExrCompressorZIP

#pragma mark ---- Lưu Và Nén Ảnh
+ (void)luuDuLieuAnh:(NSMutableData *)duLieuAnh voiBangThanhPhanHang16:(ExrBangThanhPhan *)bangThanhPhan vaMangKenh:(NSMutableArray *)mangKenh rong:(unsigned int)rong cao:(unsigned int)cao soHangDau:(unsigned int)soHangDau; {

   // ---- tính bề vài cho mỗi kênh trong một hàng, bề dài của một điểm ảnh, địa chỉ cho kênh trong hàng
   unsigned int beDaiMotHangChan = 0;
   unsigned int beDaiMotHangLe = 0;
   unsigned short soKenh = 0;
   unsigned short soLuongKenh = [mangKenh count];

   unsigned int *beDaiKenhTrongThanhPhan = malloc( sizeof( unsigned int )*soLuongKenh);
   
   while( soKenh < soLuongKenh) {
      ExrKenh *kenh = [mangKenh objectAtIndex:soKenh];
      unsigned char nhip = [kenh nhipX];
      
      unsigned int beDaiKieuDuLieu = [kenh beDaiKieuDuLieu];
      
      beDaiKenhTrongThanhPhan[soKenh] = beDaiKieuDuLieu*rong/nhip;
      
      if( nhip == 1 ) {
         beDaiMotHangChan += beDaiKenhTrongThanhPhan[soKenh];
         beDaiMotHangLe += beDaiKenhTrongThanhPhan[soKenh];
      }
      else
         beDaiMotHangChan += beDaiKenhTrongThanhPhan[soKenh];
      
      //      NSLog( @"ExrRLE: %d dai %d daiK %d", soKenh, beDaiKieuDuLieu, beDaiKenhTrongThanhPhan[soKenh] );
      soKenh++;
   }

   // ==== BẢNG THÀNH PHẦN, một thành phần cho mỗi hàng
   // ---- chưa biết bề dài cho một hàng, phải nén trước, sau mới biết bề dài
   // ---- nhưng biết số lượng hàng (phần tử trong bảng)

   // ---- giữ địa chỉ đầu bảng
   unsigned long diaChiTrongBang = [duLieuAnh length];
   
   unsigned long soKhong = 0;  // chưa có số này
   unsigned int soHang = 0;
   while( soHang < cao ) {
      NSLog( @"ZIP: soHang %d dc %ld", soHang, [duLieuAnh length ]);
      [duLieuAnh appendBytes:&soKhong length:8];

      soHang += 16; // bó 16 hàng chung
   }

   NSRange tamByte;  // tầm byte
   tamByte.length = 8;
   tamByte.location = diaChiTrongBang;
   // ---- địa chỉ lưu bề dài trong bảng thành phần
   unsigned long diaChiThanhPhan = [duLieuAnh length];
   [duLieuAnh replaceBytesInRange:tamByte withBytes:&diaChiThanhPhan];

   // ==== GOM THẢNH PHẦN
   // ---- chuẩn bị các đệm
   unsigned char *demDuLieuChoMotBoHang = malloc( beDaiMotHangChan << 4 ); // nhân 16 tại tối đa có 16 hàng
   unsigned char *demLoc = malloc( beDaiMotHangChan << 4 );  // nhân 16 tại tối đa có 16 hàng
   unsigned char *demNen = malloc( beDaiMotHangChan << 5 ); // nên có thể lớn hơn dữ liệu gốc

   soHang = 0;
   while( soHang < cao ) {

      // ---- tính số hàng dữ liệu (theo dataWindow)
      [duLieuAnh appendBytes:&soHangDau length:4];

      // ---- tính bao nhiêu hàng cho chép, cần cho bó cuối
      unsigned char soHangChep = 16;
      if( (soHang + 16) >= cao )
         soHangChep = cao - soHang;

//      NSLog( @"ExrZIP16: soHangChe %d", soHangChep );
      // ---- gom dữ liệu cho mỗi kênh
      // ---- địa chỉ trong đệm cho thành phần đang gom; ặt lại = 0 khi bắt đầu gom thành phần mới
      unsigned int diaChiTrongDemThanhPhan = 0;

      unsigned int soHangTrongBoHang = 0;   // số hàng trong bó hàng
      while( soHangTrongBoHang < soHangChep ) {

         soKenh = 0;
   
         while ( soKenh < soLuongKenh ) {
            
            ExrKenh *kenh = [mangKenh objectAtIndex:soKenh];
            // ---- rút dữ liệu từ kênh ảnh và bỏ vào dòng dữ liệu
            if( [kenh nhipX] == 1 ) {
               
               [kenh rutDuLieu:&(demDuLieuChoMotBoHang[diaChiTrongDemThanhPhan]) beDaiDem:beDaiKenhTrongThanhPhan[soKenh] tuCot:0 hang:soHang];
               diaChiTrongDemThanhPhan += beDaiKenhTrongThanhPhan[soKenh];
            }
            else if( !(soHang & 0x01) ) {   // nếu nhịp = 2 chỉ hàng chẵn có dữ liệu
               [kenh rutDuLieu:&(demDuLieuChoMotBoHang[diaChiTrongDemThanhPhan]) beDaiDem:beDaiKenhTrongThanhPhan[soKenh] tuCot:0 hang:soHang];
               diaChiTrongDemThanhPhan += beDaiKenhTrongThanhPhan[soKenh];
            }
            
            soKenh++;
         }
         soHangTrongBoHang++;
         soHang++;

      }
      // ---- lọc dữ liệu
      [ImfFilter filterDataInBuffer:demDuLieuChoMotBoHang withLength:diaChiTrongDemThanhPhan andPutInFilteredBuffer:demLoc];
      // ---- nén dữ liệu
      unsigned int beDaiDuLieuNen = (unsigned int)[ExrCompressorZIP compressChunk:demLoc withLength:diaChiTrongDemThanhPhan andPutInBuffer:demNen withLength:beDaiMotHangChan << 5];
      
      // ---- bề dài dữ liệu
      [duLieuAnh appendBytes:&beDaiDuLieuNen length:4];
      
      // ---- lưu giữ liệu
      [duLieuAnh appendBytes:demNen length:beDaiDuLieuNen];
//      NSLog( @"ExrZIP16: soHang %d soHangChep %d", soHang, soHangChep );

      // ---- sau lưu thành phần cuối không cần lưu địa chỉ tiếp
      if( soHang < cao ) {
         tamByte.location += 8;

         diaChiThanhPhan = [duLieuAnh length];
//         NSLog( @"CompZIP16: soHang %d diaChiThanhPhan %ld", soHang, tamByte.location );
         [duLieuAnh replaceBytesInRange:tamByte withBytes:&diaChiThanhPhan];
      }

      soHangDau += 16;
   }

   // ---- thả trí nhớ
   free( beDaiKenhTrongThanhPhan );
   free( demDuLieuChoMotBoHang );
   free( demLoc );
   free( demNen );
}

+ (void)luuDuLieuAnh:(NSMutableData *)duLieuAnh voiBangThanhPhanHang1:(ExrBangThanhPhan *)bangThanhPhan vaMangKenh:(NSMutableArray *)mangKenh rong:(unsigned int)rong cao:(unsigned int)cao soHangDau:(unsigned int)soHangDau; {
   
   // ---- tính bề vài cho mỗi kênh trong một hàng, bề dài của một điểm ảnh, địa chỉ cho kênh trong hàng
   unsigned int beDaiMotHangChan = 0;
   unsigned int beDaiMotHangLe = 0;
   unsigned short soKenh = 0;
   unsigned short soLuongKenh = [mangKenh count];

   unsigned int *beDaiKenhTrongThanhPhan = malloc( sizeof( unsigned int )*soLuongKenh);
   
   while( soKenh < soLuongKenh) {
      ExrKenh *kenh = [mangKenh objectAtIndex:soKenh];
      unsigned char nhip = [kenh nhipX];
      
      unsigned int beDaiKieuDuLieu = [kenh beDaiKieuDuLieu];
      
      beDaiKenhTrongThanhPhan[soKenh] = beDaiKieuDuLieu*rong/nhip;
      
      if( nhip == 1 ) {
         beDaiMotHangChan += beDaiKenhTrongThanhPhan[soKenh];
         beDaiMotHangLe += beDaiKenhTrongThanhPhan[soKenh];
      }
      else
         beDaiMotHangChan += beDaiKenhTrongThanhPhan[soKenh];
      
//      NSLog( @"ExrZIPS: %d dai %d daiK %d", soKenh, beDaiKieuDuLieu, beDaiKenhTrongThanhPhan[soKenh] );
      soKenh++;
   }
   
   // ==== BẢNG THÀNH PHẦN, một thành phần cho mỗi hàng
   // ---- chưa biết bề dài cho một hàng, phải nén trước, sau mới biết bề dài
   // ---- nhưng biết số lượng hàng (phần tử trong bảng)
   
   // ---- tính địa chỉ cho thành phần đầu tiên (sau bảng địa chỉ thành phần)
   // ---- giữ địa chỉ đầu bảng
   unsigned long diaChiTrongBang = [duLieuAnh length];

   unsigned long soKhong = 0;  // chưa có số này
   unsigned int soHang = 0;
   while( soHang < cao ) {
      [duLieuAnh appendBytes:&soKhong length:8];  // đặt phần tử trong bảng = 0, chưa nén và chưa biết độ dài
      soHang++;
   }

   NSRange tamByte;  // tầm byte
   tamByte.length = 8;
   tamByte.location = diaChiTrongBang;
   // ---- địa chỉ lưu bề dài trong bảng thành phần
   unsigned long diaChiThanhPhan = [duLieuAnh length];
   [duLieuAnh replaceBytesInRange:tamByte withBytes:&diaChiThanhPhan];

   // ==== GOM THẢNH PHẦN
   unsigned char *demDuLieuChoMotHang = malloc( beDaiMotHangChan );  // gom một hàng từ các kênh trước nén
   unsigned char *demLoc = malloc( beDaiMotHangChan );      // lọc trước nén
   unsigned char *demNen = malloc( beDaiMotHangChan << 1 ); // nên có thể lớn hơn dữ liệu gốc

   soHang = 0;
   while( soHang < cao ) {
      
      // ---- tính số hàng dữ liệu (theo dataWindow)
      [duLieuAnh appendBytes:&soHangDau length:4];

      // ---- gổm dữ liệu cho mỗi kênh
      soKenh = 0;
      // ---- địa chỉ trong đệm cho thành phần đang gom; ặt lại = 0 khi bắt đầu gom thành phần mới
      unsigned int diaChiTrongDemThanhPhan = 0;
      
      while ( soKenh < soLuongKenh ) {
         
         ExrKenh *kenh = [mangKenh objectAtIndex:soKenh];

         // ---- rút dữ liệu từ kênh ảnh và bỏ vào dòng dữ liệu
         if( [kenh nhipX] == 1 ) {
            
            [kenh rutDuLieu:&(demDuLieuChoMotHang[diaChiTrongDemThanhPhan]) beDaiDem:beDaiKenhTrongThanhPhan[soKenh] tuCot:0 hang:soHang];
            diaChiTrongDemThanhPhan += beDaiKenhTrongThanhPhan[soKenh];
         }
         else if( !(soHang & 0x01) ) {   // nếu nhịp = 2 chỉ hàng chẵn có dữ liệu
            [kenh rutDuLieu:&(demDuLieuChoMotHang[diaChiTrongDemThanhPhan]) beDaiDem:beDaiKenhTrongThanhPhan[soKenh] tuCot:0 hang:soHang];
            diaChiTrongDemThanhPhan += beDaiKenhTrongThanhPhan[soKenh];
         }
         
         soKenh++;
      }
      
      // ---- lọc dữ liệu và nén
      unsigned int beDaiDuLieuNen = 0;
      if( soHangDau & 0x01 ) {
         [ImfFilter filterDataInBuffer:demDuLieuChoMotHang withLength:beDaiMotHangLe andPutInFilteredBuffer:demLoc];
         
         beDaiDuLieuNen = (unsigned int)[ExrCompressorZIP compressChunk:demLoc withLength:beDaiMotHangLe andPutInBuffer:demNen withLength:beDaiMotHangChan << 1];
      }
      else {
         [ImfFilter filterDataInBuffer:demDuLieuChoMotHang withLength:beDaiMotHangChan andPutInFilteredBuffer:demLoc];
         beDaiDuLieuNen = (unsigned int)[ExrCompressorZIP compressChunk:demLoc withLength:beDaiMotHangChan andPutInBuffer:demNen withLength:beDaiMotHangChan << 1];
      }

      // ---- bề dài hàng
      [duLieuAnh appendBytes:&beDaiDuLieuNen length:4];
      /*
      unsigned int diaChi = 0;
      while ( diaChi < beDaiMotHang ) {
         printf( "%02x ", demDuLieuTuCacKenh[diaChi] );
         diaChi++;
      }
      printf( "\n\n" );
      diaChi = 0;
      while ( diaChi < beDaiMotHang ) {
         printf( "%02x ", demLoc[diaChi] );
         diaChi++;
      }
      [ImfFilter unfilterDataInBuffer:demLoc withLength:beDaiMotHang andPutInUnfilteredBuffer:demNen];
      printf( "\n\n" );
      diaChi = 0;
      while ( diaChi < beDaiMotHang ) {
         printf( "%02x ", demNen[diaChi] );
         diaChi++;
      } */

      // ---- lưu giữ liệu
      [duLieuAnh appendBytes:demNen length:beDaiDuLieuNen];
      
      // ---- sau lưu thành phần cuối không cần lưu địa chỉ tiếp
      if( soHang + 1 < cao) {
         tamByte.location += 8;
         diaChiThanhPhan = [duLieuAnh length];
         [duLieuAnh replaceBytesInRange:tamByte withBytes:&diaChiThanhPhan];
      }

      soHang++;
      soHangDau++;
   }
   
   // ---- thả trí nhớ
   free( beDaiKenhTrongThanhPhan );

   free( demDuLieuChoMotHang );
   free( demLoc );
   free( demNen );
}


// ------------------------------------ Ô CHỮ NHẬT -------------------------------------
//                       kênh        kênh         kênh
// một hàng ô chữ nhật +----------+-----------+----------+ .....
// một hàng ô chữ nhật +----------+-----------+----------+ .....
+ (void)luuDuLieuAnh:(NSMutableData *)duLieuAnh voiBangThanhPhanGach:(ExrBangThanhPhan *)bangThanhPhan
          vaMangKenh:(NSMutableArray *)mangKenh rongAnh:(unsigned int)rongAnh caoAnh:(unsigned int)caoAnh
            rongGach:(unsigned int)rongGach caoGach:(unsigned int)caoGach; {
   
   // ---- tính bề vài cho mỗi kênh trong một hàng gạch, bề dài của một điểm ảnh, địa chỉ cho kênh trong hàng gạch
   unsigned int beDaiMotDiemAnh = 0;
   unsigned short soKenh = 0;
   unsigned short soLuongKenh = [mangKenh count];
   unsigned int diaChiKenhTrongDiemAnh[256];
   unsigned int beDaiDuLieuTrongDiemAnh[256];
   
   while( soKenh < soLuongKenh) {
      ExrKenh *kenh = [mangKenh objectAtIndex:soKenh];
      unsigned int beDaiKieuDuLieu = [kenh beDaiKieuDuLieu];
      
      if( soKenh == 0 )
         diaChiKenhTrongDiemAnh[0] = 0;
      else
         diaChiKenhTrongDiemAnh[soKenh] = beDaiDuLieuTrongDiemAnh[soKenh-1] + diaChiKenhTrongDiemAnh[soKenh-1];  // dùng bề dài dữ liệu từ điểm ảnh trước
      
      beDaiMotDiemAnh += beDaiKieuDuLieu;
      beDaiDuLieuTrongDiemAnh[soKenh] = beDaiKieuDuLieu;
      //      NSLog( @"ExrNO: %d dai %d, dC %d daiK %d", soKenh, beDaiKieuDuLieu, diaChiKenhTrongDem[soKenh], beDaiDuLieuTuCacKenh[soKenh] );
      soKenh++;
   }
   
   // ==== làm được bàng thành phần, một thành phần cho mỗi hàng
   
   // ---- giữ địa chỉ đầu bảng
   unsigned long diaChiTrongBang = [duLieuAnh length];

   unsigned int soLuongGachX = rongAnh/rongGach;
   if( rongAnh % rongGach )
      soLuongGachX++;
   
   unsigned int soLuongGachY = caoAnh/caoGach;
   if( caoAnh % caoGach )
      soLuongGachY++;
   
   // ---- tính số lượng gạch
   unsigned soLuongGach = soLuongGachX*soLuongGachY;
   unsigned int soGach = 0;
   while( soGach < soLuongGach ) {
      
      unsigned long soKhong = 0;  // chưa có số này,dùng số không thay thế
      [duLieuAnh appendBytes:&soKhong length:8];
      
      soGach++;
   }

   NSRange tamByte;  // tầm byte
   tamByte.length = 8;
   tamByte.location = diaChiTrongBang;
   // ---- địa chỉ lưu bề dài trong bảng thành phần
   unsigned long diaChiThanhPhan = [duLieuAnh length];
   [duLieuAnh replaceBytesInRange:tamByte withBytes:&diaChiThanhPhan];

   // ---- tính địa chỉ cho thành phần đầu tiên (sau bảng địa chỉ thành phần)
//   unsigned long diaChiChoBang = (soLuongGach << 3) + [duLieuAnh length];  // một phần tử cho mỗi hàng
 
   // ---- chuẩn bị các đệm
   unsigned char *demDuLieuTuCacKenh = malloc( rongGach*caoGach*beDaiMotDiemAnh );
   unsigned char *demLoc = malloc( rongGach*caoGach*beDaiMotDiemAnh );
   unsigned char *demNen = malloc( rongGach*caoGach*beDaiMotDiemAnh << 1 );
   
   unsigned soCotGach = 0;
   unsigned soHangGach = 0;
   //   unsigned short soLuongHangGach = caoAnh/caoGach + 1;
   soGach = 0;
   
   while( soGach < soLuongGach ) {
      // ---- vị trí gạch x
      [duLieuAnh appendBytes:&soCotGach length:4];
      // ---- vị trí gạch y
      [duLieuAnh appendBytes:&soHangGach length:4];
      
      // ---- sự rõ hướng x
      unsigned int suRo = 0;   // hai hướng bằng 0
      [duLieuAnh appendBytes:&suRo length:4];
      // ---- sự rõ hướng y
      [duLieuAnh appendBytes:&suRo length:4];
      
      // ---- tính bề dài hàng cho gạch (gạch ở phía phải có thể nhỏ hơn rongGach)
      unsigned short soLuongCotGach = rongGach;
      unsigned short soLuongHangGach = caoGach;
      unsigned int viTriGachX = soCotGach*rongGach;
      unsigned int viTriGachY = soHangGach*caoGach;
      
      if( rongAnh - viTriGachX < soLuongCotGach )
         soLuongCotGach = rongAnh - viTriGachX;
      
      if( caoAnh - viTriGachY < soLuongHangGach )
         soLuongHangGach = caoAnh - viTriGachY;
      
      // ---- bề dài hàng
      unsigned int beDaiDuLieuGach = (unsigned int)soLuongCotGach*soLuongHangGach*beDaiMotDiemAnh;

      // ---- tính bề dài một hàng
      unsigned int beDaiMotHang = beDaiMotDiemAnh*soLuongCotGach;
      // ---- gồm dữ liệu cho hết hảng của gạch
      soKenh = 0;
      while ( soKenh < soLuongKenh ) {
         ExrKenh *kenh = [mangKenh objectAtIndex:soKenh];
         unsigned int diaChiKenhTrongDemKhongNen = soLuongCotGach*diaChiKenhTrongDiemAnh[soKenh];
         unsigned int beDaiDuLieuTuKenh = soLuongCotGach*[kenh beDaiKieuDuLieu];
         unsigned int soHang = 0;
         while( soHang < soLuongHangGach ) {
            // ---- rút dữ liệu từ một hàng một lược của kênh ảnh và bỏ vào đệm dữ liệu
            [kenh rutDuLieu:&(demDuLieuTuCacKenh[diaChiKenhTrongDemKhongNen + soHang*beDaiMotHang]) beDaiDem:beDaiDuLieuTuKenh tuCot:soCotGach*rongGach hang:soHangGach*caoGach + soHang];
            soHang++;
         }
         soKenh++;
      }

      // ---- lọc dữ liệu
      [ImfFilter filterDataInBuffer:demDuLieuTuCacKenh withLength:beDaiDuLieuGach andPutInFilteredBuffer:demLoc];
      // ---- nén dữ liệu
      unsigned int beDaiDuLieuNen = (unsigned int)[ExrCompressorZIP compressChunk:demLoc withLength:beDaiDuLieuGach andPutInBuffer:demNen withLength:beDaiDuLieuGach << 1];

      // ---- bề dài dữ liệu
      [duLieuAnh appendBytes:&beDaiDuLieuNen length:4];
      // ---- lưu giữ liệu
      [duLieuAnh appendBytes:demNen length:beDaiDuLieuNen];

      // ---- lưu địa chỉ của thành phần sau trong bảng thành phần
      if( soGach < soLuongGach - 1 ) {
         tamByte.location += 8;
         diaChiThanhPhan = [duLieuAnh length];
         [duLieuAnh replaceBytesInRange:tamByte withBytes:&diaChiThanhPhan];
      }

      // ---- nếu số lượng cột cho gạch này không bằng rộng gạch bình thường nghĩa là gạch cuối của hàng này
      soCotGach++;
      if( soCotGach == soLuongGachX ) {
         soCotGach = 0;
         soHangGach++;
      }

      soGach++;
   }
   
   // ---- thả trí nhớ
//   free( diaChiKenhTrongDiemAnh );
   free( demDuLieuTuCacKenh );
//   free( beDaiDuLieuTrongDiemAnh );
   free( demLoc );
   free( demNen );
}

#pragma mark ---- Đọc Và Rã Ảnh

// cần nhịp x và nhịp y
+ (void)docDuLieuAnh:(NSData *)duLieuAnh voiBangThanhPhan16:(ExrBangThanhPhan *)thongTinBangThanhPhan
vaMangKenh:(NSMutableArray *)mangKenh rong:(unsigned int)rong cao:(unsigned int)cao; {

   // ---- mảng số hàng cho những thành phần
//   int *mangSoHangThanhPhan = [thongTinBangThanhPhan mangSoHangThanhPhan];
   // ---- danh sách địa chỉ thành phần trong tập tin
   unsigned long *mangDiaChiDuLieuThanhPhan = [thongTinBangThanhPhan mangDiaChiDuLieuThanhPhan];
   // ---- mảng bề dài dư liệu thành phần
   unsigned int *mangBeDaiThanhPhan = [thongTinBangThanhPhan mangBeDaiThanhPhan];
   // ---- bao nhiều thành phần
   unsigned int baoNhieuThanhPhan = [thongTinBangThanhPhan baoNhieuThanhPhan];
   // ---- thành phần lớn nhất cho làm đệm giữ nó
   unsigned int thanhPhanLonNhat = [thongTinBangThanhPhan thanhPhanLonNhat];
   // ---- đệm thành phần
   unsigned char *demThanhPhan = malloc( thanhPhanLonNhat );

   unsigned char soKenh = 0;
   unsigned char soLuongKenh = [mangKenh count];
   unsigned int *beDaiKenhTrongMotHang = malloc( soLuongKenh * sizeof( unsigned int ) );
   unsigned short beDaiDemKhongNenChan = 0;
   unsigned short beDaiDemKhongNenLe = 0;
   // ---- chương trình này không cho hơn EXR_GIOI_HAN_KENH
   
   while( soKenh < soLuongKenh ) {
      // ---- tính bề dài của kênh trong mỗi hàng không nén
      ExrKenh *kenh = [mangKenh objectAtIndex:soKenh];
      unsigned char nhip = [kenh nhipX];
      
      beDaiKenhTrongMotHang[soKenh] = [kenh beDaiKieuDuLieu]*rong/nhip;
      if( nhip == 1 ) {
         beDaiDemKhongNenChan += beDaiKenhTrongMotHang[soKenh];
         beDaiDemKhongNenLe += beDaiKenhTrongMotHang[soKenh];
      }
      else
         beDaiDemKhongNenChan += beDaiKenhTrongMotHang[soKenh];
      
      soKenh++;
   }

   unsigned char *demKhongNen = malloc( beDaiDemKhongNenChan << 4 );  // có thể có 16 hàng, nhân 16
   unsigned char *demKhongLoc = malloc( beDaiDemKhongNenChan << 4 );
   
   unsigned int soThanhPhan = 0; 
   unsigned int soHang = 0;       // mỗi thành phần có 16 hàng (thành phần cuối có thể có ít hơn 16 hàng) 
   
   while( soThanhPhan < baoNhieuThanhPhan ) {
      // ---- đọc thành phần
      NSRange range;  // vaCham
      range.location = mangDiaChiDuLieuThanhPhan[soThanhPhan];
      range.length = mangBeDaiThanhPhan[soThanhPhan];
      [duLieuAnh getBytes:demThanhPhan range:range];

      // ---- tính bao nhiêu hàng cho chép, cần cho bó cuối
      unsigned char soHangChep = 16;
      if( (soThanhPhan + 1) == baoNhieuThanhPhan )
         soHangChep = cao - (soThanhPhan << 4);

      // ---- rã nén
      unsigned int beDaiDuLieu = (unsigned int)[ExrCompressorZIP uncompressChunk:demThanhPhan withLength:mangBeDaiThanhPhan[soThanhPhan] andPutInBuffer:demKhongNen withLength:beDaiDemKhongNenChan << 4];
      // ---- gỡ lọc
      [ImfFilter unfilterDataInBuffer:demKhongNen withLength:beDaiDuLieu andPutInUnfilteredBuffer:demKhongLoc];

      unsigned int diaChiKenhTrongThanhPhan = 0;

      unsigned int soHangTrongBoHang = 0;   // số hàng trong bộ hàng
      while( soHangTrongBoHang < soHangChep ) {
      // --- giữ dư liệu cho mỗi kệnh
         unsigned char chiSoKenh = 0;
         while( chiSoKenh < soLuongKenh ) {
            ExrKenh *kenh = [mangKenh objectAtIndex:chiSoKenh];

            // ---- chép dữ liệu trong kênh
            if( [kenh nhipX] == 1 ) {
               [kenh boDuLieu:&(demKhongLoc[diaChiKenhTrongThanhPhan]) beDaiDem:beDaiKenhTrongMotHang[chiSoKenh]
                       taiCot:0 hang:soHang];
               diaChiKenhTrongThanhPhan += beDaiKenhTrongMotHang[chiSoKenh];
            }
            else if( !(soHang & 0x01) ) {  // nếu nhịp = 2 chỉ hàng chẵn có dữ liệu
               [kenh boDuLieu:&(demKhongLoc[diaChiKenhTrongThanhPhan]) beDaiDem:beDaiKenhTrongMotHang[chiSoKenh]
                       taiCot:0 hang:soHang];
               diaChiKenhTrongThanhPhan += beDaiKenhTrongMotHang[chiSoKenh];
            }

            chiSoKenh++;
         }
         soHang++;
         soHangTrongBoHang++;
      }

      soThanhPhan++;
   }
   
   // ---- bỏ đệm
   free( demThanhPhan );
   free( demKhongNen );
   free( demKhongLoc );
}


+ (void)docDuLieuAnh:(NSData *)duLieuAnh voiBangThanhPhan1:(ExrBangThanhPhan *)thongTinBangThanhPhan
vaMangKenh:(NSMutableArray *)mangKenh rong:(unsigned int)rong cao:(unsigned int)cao; {
   
   // ---- mảng số hàng cho những thành phần
//   int *mangSoHangThanhPhan = [thongTinBangThanhPhan mangSoHangThanhPhan];
   // ---- danh sách địa chỉ thành phần trong tập tin
   unsigned long *mangDiaChiDuLieuThanhPhan = [thongTinBangThanhPhan mangDiaChiDuLieuThanhPhan];
   // ---- mảng bề dài dư liệu thành phần
   unsigned int *mangBeDaiThanhPhan = [thongTinBangThanhPhan mangBeDaiThanhPhan];
   // ---- bao nhiều thành phần
   unsigned int baoNhieuThanhPhan = [thongTinBangThanhPhan baoNhieuThanhPhan];
   // ---- thành phần lớn nhất cho làm đệm giữ nó
   unsigned int thanhPhanLonNhat = [thongTinBangThanhPhan thanhPhanLonNhat];
   // ---- đệm thành phần
   unsigned char *demThanhPhan = malloc( thanhPhanLonNhat );

   unsigned char soKenh = 0;
   unsigned char soLuongKenh = [mangKenh count];
   unsigned int *beDaiKenhTrongMotHang = malloc( soLuongKenh * sizeof( unsigned int ) );
   unsigned short beDaiDemKhongNenChan = 0;
   unsigned short beDaiDemKhongNenLe = 0;
   // ---- chương trình này không cho hơn EXR_GIOI_HAN_KENH

   while( soKenh < soLuongKenh ) {
      // ---- tính bề dài của kênh trong mỗi hàng không nén
      ExrKenh *kenh = [mangKenh objectAtIndex:soKenh];
      unsigned char nhip = [kenh nhipX];

      beDaiKenhTrongMotHang[soKenh] = [kenh beDaiKieuDuLieu]*rong/nhip;
      if( nhip == 1 ) {
         beDaiDemKhongNenChan += beDaiKenhTrongMotHang[soKenh];
         beDaiDemKhongNenLe += beDaiKenhTrongMotHang[soKenh];
      }
      else
         beDaiDemKhongNenChan += beDaiKenhTrongMotHang[soKenh];
      
      soKenh++;
   }
   
   unsigned char *demKhongNen = malloc( beDaiDemKhongNenChan );
   unsigned char *demKhongLoc = malloc( beDaiDemKhongNenChan );  // bề dài không lọc và không nén bằng nhau
   
   unsigned int soThanhPhan = 0;  // cũng bằng số hàng
   
   while( soThanhPhan < baoNhieuThanhPhan ) {
      // ---- đọc thành phần
      NSRange range;  // vaCham
      range.location = mangDiaChiDuLieuThanhPhan[soThanhPhan];
      range.length = mangBeDaiThanhPhan[soThanhPhan];
      [duLieuAnh getBytes:demThanhPhan range:range];

      // ---- rã và lọc ngược
      if( soThanhPhan & 0x01 ) {
         // ---- rã nén
         [ExrCompressorZIP uncompressChunk:demThanhPhan withLength:mangBeDaiThanhPhan[soThanhPhan] andPutInBuffer:demKhongNen withLength:beDaiDemKhongNenLe];
         // ---- lọc ngược
         [ImfFilter unfilterDataInBuffer:demKhongNen withLength:beDaiDemKhongNenLe andPutInUnfilteredBuffer:demKhongLoc];
      }
      else {
         // ---- rã nén
         [ExrCompressorZIP uncompressChunk:demThanhPhan withLength:mangBeDaiThanhPhan[soThanhPhan] andPutInBuffer:demKhongNen withLength:beDaiDemKhongNenChan];
         // ---- lọc ngược
         [ImfFilter unfilterDataInBuffer:demKhongNen withLength:beDaiDemKhongNenChan andPutInUnfilteredBuffer:demKhongLoc];
      }
      
      unsigned int diaChiKenhTrongThanhPhan = 0;
      
      // --- giữ dư liệu cho mỗi kệnh
      unsigned char chiSoKenh = 0;
      while( chiSoKenh < soLuongKenh ) {
         
         ExrKenh *kenh = [mangKenh objectAtIndex:chiSoKenh];
         
         // ---- chép dữ liệu trong kênh
         if( [kenh nhipX] == 1 ) {
            [kenh boDuLieu:&(demKhongLoc[diaChiKenhTrongThanhPhan]) beDaiDem:beDaiKenhTrongMotHang[chiSoKenh]
                    taiCot:0 hang:soThanhPhan];
            diaChiKenhTrongThanhPhan += beDaiKenhTrongMotHang[chiSoKenh];
         }
         else if( !(soThanhPhan & 0x01) ) {  // nếu nhịp = 2 chỉ hàng chẵn có dữ liệu
            [kenh boDuLieu:&(demKhongLoc[diaChiKenhTrongThanhPhan]) beDaiDem:beDaiKenhTrongMotHang[chiSoKenh]
                    taiCot:0 hang:soThanhPhan];
            diaChiKenhTrongThanhPhan += beDaiKenhTrongMotHang[chiSoKenh];
         }
         chiSoKenh++;
      }
      soThanhPhan++;
   }
   
   // ---- bỏ đệm
   free( beDaiKenhTrongMotHang );
   free( demThanhPhan );
   free( demKhongNen );
   free( demKhongLoc );
}

// ------------------------------------ ĐIỂM ẢNH SÂU
// cần nhịp x và nhịp y
+ (void)docDuLieuDiemAnhSau:(NSData *)duLieuAnh voiBangThanhPhan1:(ExrBangThanhPhan *)thongTinBangThanhPhan
          vaMangKenh:(NSMutableArray *)mangKenh rong:(unsigned int)rong cao:(unsigned int)cao; {
   
   // ---- mảng số hàng cho những thành phần
//   int *mangSoHangThanhPhan = [thongTinBangThanhPhan mangSoHangThanhPhan];
   // ---- danh sách địa chỉ thành phần trong tập tin
   unsigned long *mangDiaChiDuLieuBanDiemAnh = [thongTinBangThanhPhan mangDiaChiDuLieuThanhPhan];
   unsigned long *mangDiaChiDuLieuDiemAnhSau = [thongTinBangThanhPhan mangDiaChiDuLieuThanhPhanDiemAnhSau];
   // ---- mảng bề dài bản điểm ảnh (bị nén)
   unsigned int *mangBeDaiBanDiemAnhNen = [thongTinBangThanhPhan mangBeDaiThanhPhan];
   // ---- mảng bề dài dữ liệu điểm ảnh sôu (bị nén)
   unsigned long *mangBeDaiDuLieuDiemAnhSauNen = [thongTinBangThanhPhan mangBeDaiThanhPhanDiemAnhSauNen];
   // ---- mảng bề dài dữ liệu điểm ảnh sôu (sau rã)
   unsigned long *mangBeDaiDuLieuDiemAnhSauRa = [thongTinBangThanhPhan mangBeDaiThanhPhanDiemAnhSauRa];

   // ---- bao nhiều thành phần
   unsigned int baoNhieuThanhPhan = [thongTinBangThanhPhan baoNhieuThanhPhan];
   // ---- bảng điểm ảnh lớn nhất, cho làm đệm giữ nó
   unsigned int banDiemAnhNenLonNhat = [thongTinBangThanhPhan thanhPhanLonNhat];
   // ---- bảng dữ liệu điểm ảnh sâu lớn nhất (sau rã), cho làm đệm giữ nó
   unsigned long duLieuDiemAnhSauNenLonNhat = [thongTinBangThanhPhan duLieuDiemAnhSauNenLonNhat];
   // ---- bảng dữ liệu điểm ảnh sâu lớn nhất (sau rã), cho làm đệm giữ nó
   unsigned long duLieuDiemAnhSauRaLonNhat = [thongTinBangThanhPhan duLieuDiemAnhSauRaLonNhat];
   // ---- đệm bản điểm ảnh nén
   unsigned char *demBanDiemAnhNen = malloc( banDiemAnhNenLonNhat );
   // ---- đệm dữ liệu điểm ảnh (bị nén)
   unsigned char *demDuLieuDiemAnhSauNen = malloc( duLieuDiemAnhSauNenLonNhat );
   // ---- đệm dữ liệu điểm ảnh (sau rã)
   unsigned char *demDuLieuDiemAnhSauRa = malloc( duLieuDiemAnhSauRaLonNhat );

   // ---- cần bầ dài cho điểm ảnh (chỉ gồm kênh trong danh sách kênh, không gồm dữ liệu sâu)
   unsigned int beDaiDemKhongNen = 0;
   unsigned char soKenh = 0;
   unsigned char soLuongKenh = [mangKenh count];
   unsigned int diaChiKenhTrongMotDiemAnh[EXR_GIOI_HAN_KENH];

   if( soLuongKenh > EXR_GIOI_HAN_KENH )
      soLuongKenh = EXR_GIOI_HAN_KENH;    // ---- chương trình này không cho hơn 16 kênh

   // ---- tính vị trí trong điểm ảnh; bề dài dữ liệu rã khác cho mỗi hàng
   while( soKenh < soLuongKenh ) {
      // ---- tính bề dài của kênh trong mỗi hàng không nén
      ExrKenh *kenh = [mangKenh objectAtIndex:soKenh];
   
      // ---- địa chỉ của kênh trong một hàng
      diaChiKenhTrongMotDiemAnh[soKenh] = beDaiDemKhongNen;

      beDaiDemKhongNen += [kenh beDaiKieuDuLieu];
      soKenh++;
   }
   // ---- giữ bề dài cho một điểm ảnh
   unsigned short beDaiMoiDiemAnh = beDaiDemKhongNen;
   
   // ---- bêô daì cho bản điểm ảnh
   beDaiDemKhongNen *= rong;

   // ---- đệm cho bản điểm ảnh rã
   unsigned char *demBanDiemAnhRa = malloc( beDaiDemKhongNen );
   
   // ---- đếm không lọc, sau rã xong phải lọc dữ liệu
   unsigned char *banDiemAnhKhongLoc = malloc( beDaiDemKhongNen );
   unsigned char *duLieuDiemAnhSauKhongLoc = malloc( duLieuDiemAnhSauRaLonNhat );
   
   // ---- thông tin kênh
//   unsigned int beDaiKenhTrongMotHangKhongNen[EXR_GIOI_HAN_KENH];


   
   // ---- bắt đầu rã và lọc dữ liệu
   unsigned int soThanhPhan = 0;  // cũng bằng số hàng
   
   while( soThanhPhan < baoNhieuThanhPhan ) {
      NSRange range;
      // ---- đọc bản điểm ảnh
      range.location = mangDiaChiDuLieuBanDiemAnh[soThanhPhan];
      range.length = mangBeDaiBanDiemAnhNen[soThanhPhan];
      [duLieuAnh getBytes:demBanDiemAnhNen range:range];
   
      // ---- rã nén bản điểm ảnh
      unsigned int beDaiDuLieuRa = (unsigned int)[ExrCompressorZIP uncompressChunk:demBanDiemAnhNen withLength:mangBeDaiBanDiemAnhNen[soThanhPhan] andPutInBuffer:demBanDiemAnhRa withLength:beDaiDemKhongNen];
      [ImfFilter unfilterDataInBuffer:demBanDiemAnhRa withLength:beDaiDuLieuRa andPutInUnfilteredBuffer:banDiemAnhKhongLoc];

//      NSLog( @"%d ban diem anh: %d", soThanhPhan, beDaiDuLieuRa );

      // ---- đọc dữ liệu điểm ảnh sâu
      range.location = mangDiaChiDuLieuDiemAnhSau[soThanhPhan];
      range.length = mangBeDaiDuLieuDiemAnhSauNen[soThanhPhan];
      [duLieuAnh getBytes:demDuLieuDiemAnhSauNen range:range];

      // ---- rã nén dữ liệu cho điểm ảnh nếu có (có thể có bề dài bằng không); nếu bị nén
      if( mangBeDaiDuLieuDiemAnhSauNen[soThanhPhan] > 0 &&
         (mangBeDaiDuLieuDiemAnhSauRa[soThanhPhan] != mangBeDaiDuLieuDiemAnhSauNen[soThanhPhan]) ) {
         beDaiDuLieuRa = (unsigned int)[ExrCompressorZIP uncompressChunk:demDuLieuDiemAnhSauNen withLength:(unsigned int)mangBeDaiDuLieuDiemAnhSauNen[soThanhPhan] andPutInBuffer:demDuLieuDiemAnhSauRa withLength:beDaiDemKhongNen];
         [ImfFilter unfilterDataInBuffer:demDuLieuDiemAnhSauRa withLength:beDaiDuLieuRa andPutInUnfilteredBuffer:duLieuDiemAnhSauKhongLoc];
      }
      else {
         memcpy(demDuLieuDiemAnhSauNen, duLieuDiemAnhSauKhongLoc, mangBeDaiDuLieuDiemAnhSauNen[soThanhPhan]);
      }
         
      
      // số lượng byte (bề dài) cho dữ liệu của một kênh half
      unsigned int beDaiDuLieuChoMotKenhHalf = beDaiDuLieuRa/beDaiMoiDiemAnh;
      // ---- bề dài dữ liệu rã có thể bằnh không, nếu vấy cho 4 byte đầu bằng 0, 
      if( beDaiDuLieuRa == 0 ) {
         duLieuDiemAnhSauKhongLoc[0] = 0x00;
         duLieuDiemAnhSauKhongLoc[1] = 0x00;
         duLieuDiemAnhSauKhongLoc[2] = 0x00;
         duLieuDiemAnhSauKhongLoc[3] = 0x00;
      }
/*
      if( soThanhPhan == 5 || soThanhPhan == 6 ) {
         unsigned int chiSo = 0;
         while( chiSo < (rong << 2) ) {
            printf( "%02x%02x%02x%02x ", banDiemAnhKhongLoc[chiSo], banDiemAnhKhongLoc[chiSo+1], banDiemAnhKhongLoc[chiSo+2], banDiemAnhKhongLoc[chiSo+3] );
            chiSo+=4;
         }
         printf( "\n" );
         
         NSLog( @"ExrZIP: %d du lieu diem anh sau: %d", soThanhPhan, beDaiDuLieuRa );
         chiSo = 0;
         while( chiSo < beDaiDuLieuRa ) {
            printf( "%02x ", duLieuDiemAnhSauKhongLoc[chiSo] );
            chiSo++;
         }
         printf( "\n" );
      }
*/
      // --- giữ dư liệu cho mỗi kệnh
      unsigned char chiSoKenh = 0;
      while( chiSoKenh < soLuongKenh ) {
         ExrKenh *kenh = [mangKenh objectAtIndex:chiSoKenh];
 //        NSLog( @"ExrZIP:   %d  %d", chiSoKenh, diaChiKenhTrongMotDiemAnh[chiSoKenh]*beDaiDuLieuChoMotKenhHalf );
         // ---- chép dữ liệu trong kênh
         [kenh boDuLieu:&(duLieuDiemAnhSauKhongLoc[diaChiKenhTrongMotDiemAnh[chiSoKenh]*beDaiDuLieuChoMotKenhHalf]) voiBanDiemAnh:(unsigned int *)banDiemAnhKhongLoc soLuongDiemAnh:rong
                 taiCot:0 hang:soThanhPhan];

         chiSoKenh++;
      }
      soThanhPhan++;
   }
   
   // ---- bỏ đệm
   free( demBanDiemAnhNen );
   free( demBanDiemAnhRa );
   free( banDiemAnhKhongLoc );
   
   free( demDuLieuDiemAnhSauNen );
   free( demDuLieuDiemAnhSauRa );
   free( duLieuDiemAnhSauKhongLoc );
}


// ------------------------------------ GẠCH -------------------------------------
// cần nhịp x và nhịp y
+ (void)docDuLieuAnh:(NSData *)duLieuAnh voiBangThanhPhanGach:(ExrBangThanhPhan *)thongTinBangThanhPhan
          vaMangKenh:(NSMutableArray *)mangKenh rongHinh:(unsigned int)rongHinh caoHinh:(unsigned int)caoHinh
rongGach:(unsigned int)rongGach caoGach:(unsigned int)caoGach; {

   // ---- mảng số hàng cho những thành phần
//   int *mangSoHangThanhPhan = [thongTinBangThanhPhan mangSoHangThanhPhan];
   // ---- danh sách địa chỉ thành phần trong tập tin
   unsigned long *mangDiaChiDuLieuThanhPhan = [thongTinBangThanhPhan mangDiaChiDuLieuThanhPhan];
   // ---- mảng bề dài dư liệu thành phần
   unsigned int *mangBeDaiThanhPhan = [thongTinBangThanhPhan mangBeDaiThanhPhan];
   // ---- bao nhiều thành phần
   unsigned int baoNhieuThanhPhan = [thongTinBangThanhPhan baoNhieuThanhPhan];
   // ---- thành phần lớn nhất cho làm đệm giữ nó
   unsigned int thanhPhanLonNhat = [thongTinBangThanhPhan thanhPhanLonNhat];
   
   // ---- cho gạch
   unsigned int *mangSoGach = [thongTinBangThanhPhan mangSoGach];
//   unsigned int *mangSuRo = [thongTinBangThanhPhan mangSuRo];
   
   // ---- đệm thành phần
   unsigned char *demThanhPhan = malloc( thanhPhanLonNhat );

   unsigned short beDaiDiemAnh = 0;
   unsigned char soKenh = 0;
   unsigned char soLuongKenh = [mangKenh count];
   if( soLuongKenh > EXR_GIOI_HAN_KENH )
      soLuongKenh = EXR_GIOI_HAN_KENH;    // ---- chương trình này không cho hơn 16 kênh
   
   while( soKenh < soLuongKenh ) {
      // ---- tính bề dài của kênh trong mỗi hàng không nén
      ExrKenh *kenh = [mangKenh objectAtIndex:soKenh];
      beDaiDiemAnh += [kenh beDaiKieuDuLieu];
      soKenh++;
   }

   unsigned char *demKhongNen = malloc( beDaiDiemAnh*rongGach*caoGach );
   unsigned char *demKhongLoc = malloc( beDaiDiemAnh*rongGach*caoGach );  // bề dài không lọc và không nén bằng nhau
   
   // ---- thông tin kênh
   unsigned int beDaiKenhTrongMotDiemAnh[EXR_GIOI_HAN_KENH];
   unsigned int diaChiKenhTrongMotDiemAnh[EXR_GIOI_HAN_KENH];


   unsigned short baoNhieuKenh = [mangKenh count];
   unsigned char chiSoKenh = 0; // chỉ số kênh
   if( baoNhieuKenh > EXR_GIOI_HAN_KENH )
      baoNhieuKenh = EXR_GIOI_HAN_KENH;    // ---- chương trình này không cho hơn EXR_GIOI_HAN_KENH 
   
   while( chiSoKenh < baoNhieuKenh ) {
      // ---- tính bề dài của kênh trong mỗi hàng không nén
      ExrKenh *kenh = [mangKenh objectAtIndex:chiSoKenh];
      
      beDaiKenhTrongMotDiemAnh[chiSoKenh] = [kenh beDaiKieuDuLieu];
      
      // ---- địa chỉ của kênh trong một hàng
      if( chiSoKenh == 0 ) {
         diaChiKenhTrongMotDiemAnh[chiSoKenh] = 0;
      }
      else {
         diaChiKenhTrongMotDiemAnh[chiSoKenh] = diaChiKenhTrongMotDiemAnh[chiSoKenh-1] + beDaiKenhTrongMotDiemAnh[chiSoKenh-1];
      }
      
      chiSoKenh++;
   }
   
   unsigned int soThanhPhan = 0;  // cũng 
//   unsigned int soHang = 0;       // mỗi thành phần có 16 hàng (thành phần cuối có thể có ít hơn 16 hàng)

   while( soThanhPhan < baoNhieuThanhPhan ) {
      
      // ---- tính vị trí gạch
      unsigned int viTriGachX = rongGach*mangSoGach[soThanhPhan << 1];
      unsigned int viTriGachY = caoGach*mangSoGach[(soThanhPhan << 1)+1];
      
      // ---- xem nếu gạch ở phía dưới, gạch có lẻ không cao bằng gạch bình thường
      unsigned int soHangChep = caoGach;
      if( caoHinh - viTriGachY < caoGach ) {
         soHangChep = caoHinh - viTriGachY;
      }
      
      // ---- xem nếu gạch ở phía phải, gạch đó có lẻ không cao bằng gạch bình thường
      unsigned int beRongGach = rongGach;
      if( rongHinh - viTriGachX < rongGach )
         beRongGach = rongHinh - viTriGachX;

      // ---- tính bề dài; có khi nhỏ hơn beDaiDemKhongNen tính cho đệm, phái có giá trị đúng cho ImfFilter
      unsigned int beDaiDemKhongNen = beRongGach*soHangChep*beDaiDiemAnh;

      // ---- đọc thành phần
      NSRange range;  // vaCham
      range.location = mangDiaChiDuLieuThanhPhan[soThanhPhan];
      range.length = mangBeDaiThanhPhan[soThanhPhan];
//      NSLog( @"ZIPGach: thanhPhan %d location %ld beDai %ld", soThanhPhan, range.location, range.length );
      [duLieuAnh getBytes:demThanhPhan range:range];

      // ---- rã nén
      [ExrCompressorZIP uncompressChunk:demThanhPhan withLength:mangBeDaiThanhPhan[soThanhPhan] andPutInBuffer:demKhongNen withLength:beDaiDemKhongNen];
      // ---- gỡ lọc
      [ImfFilter unfilterDataInBuffer:demKhongNen withLength:beDaiDemKhongNen andPutInUnfilteredBuffer:demKhongLoc];
      
      // --- giữ dư liệu cho mỗi kệnh
      unsigned char chiSoKenh = 0;
      while( chiSoKenh < baoNhieuKenh ) {
         
         ExrKenh *kenh = [mangKenh objectAtIndex:chiSoKenh];
         
         // ---- tính địa chỉ và bề dài kenh tron đệm không nén
         unsigned int beDaiDuLieuKenhTrongDemKhongNen;
         unsigned int diaChiKenhTrongDemKhongNen;
         beDaiDuLieuKenhTrongDemKhongNen = beRongGach*beDaiKenhTrongMotDiemAnh[chiSoKenh];
         diaChiKenhTrongDemKhongNen = beRongGach*diaChiKenhTrongMotDiemAnh[chiSoKenh];
         
         unsigned int suDoi = 0;   // sự dời
         unsigned int soHangTrongBoHang = 0;   // số hàng trong bộ hàng
         while( soHangTrongBoHang < soHangChep ) {
            
            // ---- chép dữ liệu trong kênh
            [kenh boDuLieu:&(demKhongLoc[diaChiKenhTrongDemKhongNen+suDoi])
                  beDaiDem:beDaiDuLieuKenhTrongDemKhongNen taiCot:viTriGachX hang:viTriGachY+soHangTrongBoHang];
            suDoi += beRongGach*beDaiDiemAnh;  // nếu beRongGach không dúng có thể làm hình lạ mà đẹp?
            soHangTrongBoHang++;
         }
         chiSoKenh++;
      }
//      soHang += soHangChep;
      soThanhPhan++;
   }
      
   // ---- bỏ đệm
   free( demThanhPhan );
   free( demKhongNen );
   free( demKhongLoc );
}


+ (unsigned long)compressChunk:(unsigned char *)in withLength:(unsigned int)inLength andPutInBuffer:(unsigned char *)out withLength:(unsigned int)outLength; {

   /*   unsigned int diaChi = 0;
    while ( diaChi < inLength ) {
    printf( "%02x ", in[diaChi] );
    diaChi++;
    } */
   
   int err;
   z_stream c_stream; // decompression stream data struct
   
   c_stream.zalloc = Z_NULL;
   c_stream.zfree = Z_NULL;
   c_stream.opaque = Z_NULL;
   //   c_stream.data_type = Z_BINARY;
   
   
   // ---- check if initialization has no error
   //   err = deflateInit2( &c_stream, Z_BEST_COMPRESSION, Z_DEFLATED, 15, 8, Z_DEFAULT_STRATEGY );
   err = deflateInit(&c_stream, Z_DEFAULT_COMPRESSION);
   
   if( err != Z_OK )
      NSLog( @"ExrZIP: compress: error deflateInit %d (%x) c_stream.avail_in %d", err, err, c_stream.avail_in );
   
   // ---- give data to compress
   c_stream.next_in = in;
   c_stream.avail_in = inLength;
   
   // ---- estimate space needed for compression
   unsigned int beDaiDuDoan = (unsigned int)deflateBound(&c_stream, inLength );
   if( beDaiDuDoan > outLength )
      NSLog( @"ExrZIP: zlib compress beDaiDuDoan %d > outLength %d", beDaiDuDoan, outLength );
   
   // ---- buffer to put compressed data
   c_stream.next_out  = out;
   c_stream.avail_out = outLength;  // same length as in buffer
   err = deflate(&c_stream, Z_FINISH);
   
   if( err != Z_STREAM_END ) {
      if( err == Z_OK) {
         NSLog( @"ImfCompressorZIP: compress: Z_OK d_stream.avail_out %d d_stream.total_out %lu",
               c_stream.avail_out, c_stream.total_out );
      }
      else
         NSLog( @"ImfCompressorZIP: compress: error deflate %d (%x) d_stream.avail_out %d d_stream.total_out %lu",
               err, err, c_stream.avail_in, c_stream.total_in );
   }
   
   err = deflateEnd( &c_stream );
   if( err != Z_OK )
      NSLog( @"ExrZIP: compress: error deflateEnd %d (%x) c_stream.avail_out %d", err, err, c_stream.avail_out );
   return c_stream.total_out;
}

+ (unsigned long)uncompressChunk:(unsigned char *)in withLength:(unsigned int)inLength andPutInBuffer:(unsigned char *)out withLength:(unsigned int)outLength; {

   // ---- use zlib to inflate (decompress) image data
   int err;
   z_stream d_stream; // decompression stream data struct
   
   d_stream.zalloc = Z_NULL;
   d_stream.zfree = Z_NULL;
   d_stream.opaque = Z_NULL;
   d_stream.data_type = Z_BINARY;
   
   d_stream.next_in  = in;
   d_stream.avail_in = inLength;

   // ---- check if initialization has no error
   
   if( (in[0] & 0x08) == 0x08 ) {   // only check if lower 4 bits are 0x8
      err = inflateInit(&d_stream);
   }
   else {
      err = inflateInit2(&d_stream, -15);
   }

   if( err != Z_OK ) {
      NSLog( @"ImfCompressorZIP: uncompress: error inflateInit %d (%x) d_stream.avail_in %d", err, err, d_stream.avail_in );
   }
   
   // ---- give data to decompress
   d_stream.next_out = out;
   d_stream.avail_out = outLength;
   
   err = inflate(&d_stream, Z_STREAM_END);
   
   if( err != Z_STREAM_END ) {
      if( err == Z_OK) {
         NSLog( @"ImfCompressorZIP: uncompress: Z_OK d_stream.avail_out %d d_stream.total_out %lu",
               d_stream.avail_out, d_stream.total_out );
      }
      else
      NSLog( @"ImfCompressorZIP: uncompress: error inflate %d (%x) d_stream.avail_out %d d_stream.total_out %lu",
            err, err, d_stream.avail_out, d_stream.total_out );
      
   }

   err = inflateEnd( &d_stream );
   if( err != Z_OK )
      NSLog( @"ExrZIP: uncompress: error inflateEnd %d (%x) c_stream.avail_in %d", err, err, d_stream.avail_in );

   return d_stream.total_out;
}


@end
