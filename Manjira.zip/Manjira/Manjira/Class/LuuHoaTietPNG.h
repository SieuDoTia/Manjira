//
//  LuuHoaTietPNG.h
//  PhatHinhBaChieu
//
//  Created by Joe Ho on 17/3/2554.
//

#import <Foundation/Foundation.h>


@interface LuuHoaTietPNG : NSObject {

}

+ (void)luuBGRO_PNG_voiURL:(NSURL *)URLTapTin duLieuAnh:(unsigned char *)duLieuAnh
         beRong:(unsigned int)beRong beCao:(unsigned int)beCao soLuongBit:(unsigned char)soLuongBit;

// ---- chắc không bao giờ xài mấy cái này mmà có mã nguồn sẵn cho nó
/*
+ (void)luuXam16bit_PNG_voiURL:(NSString *)urlTapTin duLieuAnh:(unsigned char *)duLieuAnh
                        beRong:(unsigned int)beRong beCao:(unsigned int)beCao;
 */
/*
 + (void)luuBGRO_StereoPNG_voiURL:(NSURL *)urlTapTin duLieuMau:(unsigned char *)duLieuMau
           duLieuAnhSau:(unsigned char *)duLieuSau beRong:(unsigned int)beRong beCao:(unsigned int)beCao;
*/
@end
