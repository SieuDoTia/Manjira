//
//  DocXML_ThongTinPhanDang.m
//  Manjira
//
//  Created by 小小 on 18/2/2560.
//

#import "DocXML_ThongTinPhanDang.h"
#import "ThongTinPhanDang.h"

@implementation DocXML_ThongTinPhanDang

- (unsigned char)docVoiURL:(NSURL *)URL_tapTin; {
   
   // ---- đọc dữ liệu vào đối tượng NSData
   NSData *modelFileData = [NSData dataWithContentsOfURL:URL_tapTin];
   
   // ---- nếu không thể đọc dữ liệu
   if( !modelFileData ) {
	   return 0;
   }
   
   // ---- model parser
   modelParser = [[NSXMLParser alloc] initWithData:modelFileData];
	
	[modelParser setDelegate:self];
   
	if( ![modelParser parse] ) {
	   NSLog( @"DocXML_DanhSahMau: parse THẤT BẠI" );
		return 0;
   }
   
   return 1;
}


// ---- tìm phần tử của tệp XML
- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)tenPhanTu namespaceURI:(NSString *)namespaceURI
 qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict; {
   
   // ----
   if( [tenPhanTu isEqualToString:NSLocalizedString( @"Mandelbrot", @"")] ) {
      return;
   }
   else if( [tenPhanTu isEqualToString:NSLocalizedString( @"Julia", @"")] ) {
      return;
   }
   else if( [tenPhanTu isEqualToString:NSLocalizedString( @"thôngTin", @"")] ) {
      tinhJulia = [[attributeDict valueForKey:NSLocalizedString( @"tinhJulia", @"đặc điểm XML")] boolValue];
      trungTamX = [[attributeDict valueForKey:NSLocalizedString( @"trungTâmX", @"đặc điểm XML")] floatValue];
      trungTamY = [[attributeDict valueForKey:NSLocalizedString( @"trungTâmY", @"đặc điểm XML")] floatValue];
      phongTo = [[attributeDict valueForKey:NSLocalizedString( @"phóngTo", @"")] floatValue];
      mu = [[attributeDict valueForKey:NSLocalizedString( @"mũ", @"")] floatValue];
      banKinhNghiTinhMu2 = [[attributeDict valueForKey:NSLocalizedString( @"bánKínhNghỉBình=", @"đặc điểm XML")] floatValue];
      beRong = [[attributeDict valueForKey:NSLocalizedString( @"bềRộng", @"đặc điểm XML")] intValue];
      beCao = [[attributeDict valueForKey:NSLocalizedString( @"bềCao", @"đặc điểm XML")] intValue];
      soLapLaiToiDa = [[attributeDict valueForKey:NSLocalizedString( @"sốLặpLạiTốiĐa", @"đặc điểm XML")] intValue];
      
      if( tinhJulia ) {
         hangSoThat = [[attributeDict valueForKey:NSLocalizedString( @"hằngSốThật", @"đặc điểm XML")] floatValue];
         hangSoAo = [[attributeDict valueForKey:NSLocalizedString( @"hằngSốẢo", @"đặc điểm XML")] floatValue];
      }
         
		return;
   }

   else if( [tenPhanTu isEqualToString:NSLocalizedString( @"trungTâmY", @"")] ) {
      
      
		return;
   }
   
}


- (void)parser:(NSXMLParser *)parser parseErrorOccurred:(NSError *)parseError; {
   
   NSLog( @"DocXML_DanhSachMau: Sai Lầm MÃ SỐ %ld tại dòng %ld", [parseError code], [parser lineNumber] );

   saiLam = YES;
}

#pragma mark ---- Biến
@synthesize tinhJulia;
@synthesize hangSoThat;
@synthesize hangSoAo;

@synthesize trungTamX;
@synthesize trungTamY;
@synthesize phongTo;
@synthesize banKinhBinh;
@synthesize mu;
@synthesize giaiThuat;

@synthesize beRong;
@synthesize beCao;

@synthesize soLapLaiToiDa;

@synthesize saiLam;

@end
