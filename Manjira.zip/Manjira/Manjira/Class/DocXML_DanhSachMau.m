//
//  DocXML_DanhSachMau.m
//  Manjira
//
//  Created by 小小 on 16/2/2560.
//

#import "DocXML_DanhSachMau.h"
#import "ToMau.h"

@implementation DocXML_DanhSachMau

- (unsigned char)docVoiURL:(NSURL *)URL_tapTin; {
   
   // ---- đọc dữ liệu vào đối tượng NSData
   NSData *modelFileData = [NSData dataWithContentsOfURL:URL_tapTin];
   
   // ---- nếu không thể đọc dữ liệu
   if( !modelFileData ) {
	   return 0;
   }
   
   // ---- model parser
   modelParser = [[NSXMLParser alloc] initWithData:modelFileData];
	
	[modelParser setDelegate:self];
   
	if( ![modelParser parse] ) {
	   NSLog( @"DocXML_DanhSahMau: parse THẤT BẠI" );
		return 0;
   }
   
   return 1;
}


// ---- tìm phần tử của tệp XML
- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)tenPhanTu namespaceURI:(NSString *)namespaceURI
 qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict; {
   
   // ----
   if( [tenPhanTu isEqualToString:NSLocalizedString( @"danhSáchMàu", @"")] ) {
      soLuongMau = 0;
      
      // ---- đặt màu mặc định
      mauTapHop[0] = 0.0f;
      mauTapHop[1] = 0.0f;
      mauTapHop[2] = 0.0f;
      mauTapHop[3] = 1.0f;
   }
   else if( [tenPhanTu isEqualToString:NSLocalizedString( @"màu", @"")] ) {
      if( soLuongMau < 256 ) {
         unsigned int chiSoMau = soLuongMau << 2;
         danhSachMau[chiSoMau] = [[attributeDict valueForKey:NSLocalizedString( @"đỏ", @"đặc điểm XML")] floatValue];
         danhSachMau[chiSoMau+1] = [[attributeDict valueForKey:NSLocalizedString( @"lục", @"đặc điểm XML")] floatValue];
         danhSachMau[chiSoMau+2] = [[attributeDict valueForKey:NSLocalizedString( @"xanh", @"đặc điểm XML")] floatValue];
         danhSachMau[chiSoMau+3] = [[attributeDict valueForKey:NSLocalizedString( @"độ đục", @"đặc điểm XML")] floatValue];
         soLuongMau++;
      }
      else{
         NSLog( @"DocXML_DanhSachMau: parser: soLuongMau > 256" );
      }
		return;
   }
   // ---- đọc họa tiết cho sprites
   else if( [tenPhanTu isEqualToString:NSLocalizedString( @"màuTậpHợp", @"")] ) {
         
      mauTapHop[0] = [[attributeDict valueForKey:NSLocalizedString( @"đỏ", @"")] floatValue];
      mauTapHop[1] = [[attributeDict valueForKey:NSLocalizedString( @"lục", @"")] floatValue];
      mauTapHop[2] = [[attributeDict valueForKey:NSLocalizedString( @"xanh", @"")] floatValue];
      mauTapHop[3] = [[attributeDict valueForKey:NSLocalizedString( @"độ đục", @"")] floatValue];

		return;
   }
   
}


- (void)parser:(NSXMLParser *)parser parseErrorOccurred:(NSError *)parseError; {
   
   NSLog( @"DocXML_DanhSachMau: Sai Lầm MÃ SỐ %ld tại dòng %ld", [parseError code], [parser lineNumber] );
   
   saiLam = YES;
}

#pragma mark ---- Biến
@synthesize soLuongMau;

- (float *)danhSachMau; {
   return danhSachMau;
}

- (float *)mauTapHop; {
   return mauTapHop;
}

@synthesize saiLam;

@end
