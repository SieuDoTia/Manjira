//
//  LuuXML_ThongTinPhanDang.h
//  Manjira
//
//  Created by 小小 on 18/2/2560.
//

#import <Foundation/Foundation.h>
@class ThongTinPhanDang;

@interface LuuXML_ThongTinPhanDang : NSObject

+ (void)luuVoiURL:(NSURL *)URL_tapTin thongTinPhanDang:(ThongTinPhanDang *)thongTinPhanDang;

@end
