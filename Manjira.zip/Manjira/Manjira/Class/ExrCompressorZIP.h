//
//  ExrCompressorZIP.h
//  OpenEXR
//
//  Created by 小小 on 20/12/2554.
//  Copyright (c) 2554 BE __MyCompanyName__. All rights reserved.
//
#import <Foundation/Foundation.h>

@class ExrBangThanhPhan;

@interface ExrCompressorZIP : NSObject

// ---- 16 hàng chung
+ (void)luuDuLieuAnh:(NSMutableData *)duLieuAnh voiBangThanhPhanHang16:(ExrBangThanhPhan *)bangThanhPhan vaMangKenh:(NSMutableArray *)mangKenh rong:(unsigned int)rong cao:(unsigned int)cao soHangDau:(unsigned int)soHangDau;;

// ---- mỗi hành riêng
+ (void)luuDuLieuAnh:(NSMutableData *)duLieuAnh voiBangThanhPhanHang1:(ExrBangThanhPhan *)bangThanhPhan vaMangKenh:(NSMutableArray *)mangKenh rong:(unsigned int)rong cao:(unsigned int)cao soHangDau:(unsigned int)soHangDau;;

+ (void)luuDuLieuAnh:(NSMutableData *)duLieuAnh voiBangThanhPhanGach:(ExrBangThanhPhan *)bangThanhPhan
          vaMangKenh:(NSMutableArray *)mangKenh rongAnh:(unsigned int)rongAnh caoAnh:(unsigned int)caoAnh
            rongGach:(unsigned int)rongGach caoGach:(unsigned int)caoGach;



// ---- 16 hàng chung
+ (void)docDuLieuAnh:(NSData *)duLieuAnh voiBangThanhPhan16:(ExrBangThanhPhan *)thongTinBangThanhPhan
          vaMangKenh:(NSMutableArray *)mangKenh rong:(unsigned int)rong cao:(unsigned int)cao;

// ---- mỗi hành riêng
+ (void)docDuLieuAnh:(NSData *)duLieuAnh voiBangThanhPhan1:(ExrBangThanhPhan *)thongTinBangThanhPhan
          vaMangKenh:(NSMutableArray *)mangKenh rong:(unsigned int)rong cao:(unsigned int)cao;


// ĐIỂM ẢNH SâU
// ---- mỗi hành riêng
+ (void)docDuLieuDiemAnhSau:(NSData *)duLieuAnh voiBangThanhPhan1:(ExrBangThanhPhan *)thongTinBangThanhPhan
          vaMangKenh:(NSMutableArray *)mangKenh rong:(unsigned int)rong cao:(unsigned int)cao;



// GẠCH
// ---- hàng bằng bề cao gạch chung
+ (void)docDuLieuAnh:(NSData *)duLieuAnh voiBangThanhPhanGach:(ExrBangThanhPhan *)thongTinBangThanhPhan
          vaMangKenh:(NSMutableArray *)mangKenh rongHinh:(unsigned int)rongHinh caoHinh:(unsigned int)caoHinh
            rongGach:(unsigned int)rongGach caoGach:(unsigned int)caoGach;

// ---- phủ hợp
+ (unsigned long)compressChunk:(unsigned char *)in withLength:(unsigned int)inLength andPutInBuffer:(unsigned char *)out withLength:(unsigned int)bufferLength;

+ (unsigned long)uncompressChunk:(unsigned char *)in withLength:(unsigned int)inLength andPutInBuffer:(unsigned char *)out withLength:(unsigned int)bufferLength;

@end
