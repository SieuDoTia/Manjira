//
//  ImfFilter.m
//  Test13
//
//  Created by 小小 on 1/7/2555.
//

#import "ImfFilter.h"

@implementation ImfFilter


// ---- cho RLE, ZIPS, ZIP
+ (void)filterDataInBuffer:(unsigned char *)buffer withLength:(unsigned int)length
    andPutInFilteredBuffer:(unsigned char *)filteredBuffer; {
   
   //
   // Tổ chức dữ liệu; || 0; (length+1)/2 || 1; (length+1)/2 + 1 || 2; (length+1)/2 + 2 || v.v.
   //
   
   {
      unsigned char *t1 = filteredBuffer;
      unsigned char *t2 = filteredBuffer + (length + 1) / 2;
      char *s = (char *)buffer;  // start of unfiltered buffer
      char *stop = s + length;
      unsigned char finished = NO;
      
      while( !finished )
      {
         if (s < stop)
            *(t1++) = *(s++);
         else
            finished = YES;
         
         if (s < stop)
            *(t2++) = *(s++);
         else
            finished = YES;
      }
   }
   
   // trừ
   {
      unsigned char *t = (unsigned char *)filteredBuffer + 1;
      unsigned char *stop = (unsigned char *)filteredBuffer + length;
      int p = t[-1];
      
      while (t < stop) {

         int d = (int)(t[0]) - p + 128;
         p = t[0];
         t[0] = d;
         ++t;
      }
   }
}

/* không xài */
/*
// ---- cho RLE, ZIPS, ZIP
+ (void)unfilterDataInBuffer:(unsigned char *)buffer withLength:(unsigned int)length
    andPutInUnfilteredBuffer:(unsigned char *)unfilteredBuffer; {

   // cộng
   {
      unsigned char *t = (unsigned char *)buffer + 1;           // bỏ byte đầu tiên
      unsigned char *stop = (unsigned char *)buffer + length;   // cuối buffer
      
      while (t < stop) {
         // ---- unfilter byte
         int d = (int) (t[-1]) + (int)(t[0]) - 128;  // cộng chênh lệch byte trước trừ 128
         //      NSLog( @"ImfFilter: unfilter t[-1] %d + t[0] %d - 128 = d %d", t[-1], t[0], d);
         // ---- save unfiltered byte
         t[0] = d;
         ++t;
      }
   }
   //
   // Tổ chức dữ liệu; || 0; (length+1)/2 || 1; (length+1)/2 + 1 || 2; (length+1)/2 + 2 || v.v.
   //
   
   char *t1 = (char *)buffer;          // đầu buffer
   char *t2 = (char *)buffer + (length + 1) / 2;  // nữa buffer
   char *s = (char *)unfilteredBuffer;  // start of unfiltered buffer
   char *stop = s + length;             // end unfiltred buffer
   unsigned char finished = NO;
   
   while( !finished ) {
      // ---- if not at unfilteredBuffer end
      if (s < stop)
         *(s++) = *(t1++);  // chép tiếp từ đệm
      else
         finished = YES;
      // ---- if not at unfilteredBuffer end
      if (s < stop)
         *(s++) = *(t2++);  // chép tiếp từ nữa đệm
      else
         finished = YES;
   }
}
*/
@end
