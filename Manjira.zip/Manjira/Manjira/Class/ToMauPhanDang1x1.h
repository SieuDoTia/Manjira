//
//  ToMauPhanDang1x1.h
//  Manjira
//
//  Created by 小小 on 10/10/2557.
//

#import <Foundation/Foundation.h>

@class ThongTinPhanDang;
@class ChieuPhanDang;
@class ToMau;

@interface ToMauPhanDang : NSOperation {
   
   ThongTinPhanDang *thongTinPhanDang;
   ToMau *toMau;
   ChieuPhanDang *chieuPhanDang;
   
   unsigned short soHang;
   unsigned short soLuongHang;
}


- (id)initChoSoHang:(unsigned short)_soHang soLuongHang:(unsigned short)_soLuongHang
           thongTinPhanDang:(ThongTinPhanDang *)_thongTinPhanDang chieuPhanDang:(ChieuPhanDang *)_chieuPhanDang;

@end
