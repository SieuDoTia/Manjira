//
//  ToMau.h
//  Manjira
//
//  Created by 小小 on 21/11/2556.
//

#import <Foundation/Foundation.h>
@class ThongTinPhanDang;

#define kKIEU_TO__LAP_VONG     0
#define kKIEU_TO__LAP_VONG_DEU 1

#define kSO_LUONG__MAU_TOI_DA 256

@interface ToMau : NSObject {

   float mauTap[4];      // màu cho tập Mandelbrot hay Julia
 
   float *danhSachMau;   // có 4 float cho mỗi màu; thành phần: đỏ, lục, xanh vương, đục
   unsigned char soLuongMau;
   float cachGiuaMau;    // ---- cách giữa màu, danh bạ màu là 0,0 tới 1,0; CHƯA XÀI
   
   unsigned int chuTrinhMau;   // chu trình màu
   float mu;     // mũ cho hàm số màu (1,0 0,01)
   unsigned int dich;  // dịch màu
   
   unsigned int soLapLaiToiDa; // số lặp lại tối đa
   
//   BOOL keoDenToanPhamVa;   // kéo màu cho toàn phạm vi
}


- (BOOL)chenMau:(float *)mau taiChiSo:(unsigned char)chiSoChen;
- (BOOL)xoaMauTaiChiSo:(unsigned short)chiSoMauBo;

- (void)datMauTapDo:(float)mauDo luc:(float)mauLuc xanh:(float)mauXanh duc:(float)duc;

- (void)to1x1VoiThongTin:(ThongTinPhanDang *)thongTinPhanDang soHang:(unsigned short)soHang soLuongHang:(unsigned short)soLuongHang;
- (void)to4x4VoiThongTin:(ThongTinPhanDang *)thongTinPhanDang soHang:(unsigned short)soHang soLuongHang:(unsigned short)soLuongHang;


- (void)toMau:(float *)mau choLapLai:(unsigned int)lapLai vaGioiHanLapLai:(unsigned int)gioiHanLapLai;

- (void)thayMau:(float *)mau chiSo:(unsigned char)soMau;
- (void)thayMauTapHop:(float *)mau;

+ (void)toMauLai:(ToMau *)toMau choThongTinPhanDang:(ThongTinPhanDang *)thongTinPhanDang;

+ (void)chepToMauNguon:(ToMau *)toMauNguon toMauDich:(ToMau *)toMauDich;

- (void)veLaiVoiMangMau:(float *)mangMau vaMangSoLuongLapLai:(unsigned int *)mangSoLuongLapLai soLuongDiem:(unsigned int)soLuongDiem vaGioiHanLapLai:(unsigned int)gioiHanLapLai;

- (void)datKhong;
- (void)datVuTruong;
- (void)datMuaDong;
- (void)datGiangSinh;
- (void)datHoaHongVaXanh;
- (void)datSaMac;
- (void)datBauTroiSaMac;
- (void)datThaiDuong;
- (void)datSoCoLa;
- (void)datSoCoLaDeo;
- (void)datCauVong;
- (void)datCauVong2;
- (void)datVatDen;
- (void)datTuyet;
- (void)datPhimXua;
- (void)datKimLoai;
- (void)datRauCau;
- (void)datNeon;
- (void)datKeoBong;
- (void)datHoangGia;
- (void)datSilic;
- (void)datQuan;

- (void)thayDanhSachMau:(float *)danhSachMauMoi soLuongMau:(unsigned char)soLuongMauMoi;

@property (readonly) float *danhSachMau;
@property (readonly) float *mauTapHop;
@property (readonly) unsigned char soLuongMau;
@property (readwrite) unsigned int chuTrinhMau;
@property (readwrite) float mu;
@property (readwrite) unsigned int dich;
@property (readwrite) unsigned int soLapLaiToiDa;

@end
