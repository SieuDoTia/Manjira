//
//  ChieuPhanDang.h
//  Manjira
//
//  Created by 小小 on 20/11/2556.
//

#import <Cocoa/Cocoa.h>

@interface ChieuPhanDang : NSOpenGLView {

   float *hoaTietChanh;     // họa tiết chánh cho vẽ phân dạng
   unsigned short beRong;   // bề rộng ảnh
   unsigned short beCao;    // bề cao ảnh
   
   unsigned int hoaTietPhanDang;  // ssố của họa tiết phần dạng
   unsigned int soChuongTrinhVe;  // số của chương trình vẽ (tô sắc)
   unsigned int uniform_MaTranChieu;  // biến uniform (đều) cho chương trình vẽ
    
   float phongToCuaSo;  // phóng to cửa sổ cho màn Retina

   float maTranChieu[16];  // ma trận chiếu

   CGPoint viTriBamTuongDoi;   // vị trí bấm chuột tương đối ảnh phần dạng
   BOOL phimShift;     // có bấm phím shift - phóng ra (rút nhỏ lại)
   BOOL phimCtrl;      // có bấm phím ctrl - phóng to và di chuyển nhanh,
   unsigned char huong;  // hướng di chuyển

   BOOL keoHinh;   // kéo hình, xài cho phân biệt nên kéo màn hay phóng to màn
   CGPoint viTriBamDau;  // vị trí bấm đầu, để biết kéo màn bao xa khi buông chuột
   CGPoint cachKeoMan;  // cách kéo màn
}


- (void)chepAnh:(float *)anh;
- (void)xoa;


@property (readwrite) unsigned short beRong;
@property (readwrite) unsigned short beCao;
@property (readonly) CGPoint viTriBamTuongDoi;
@property (readonly) BOOL phimShift;
@property (readonly) BOOL phimCtrl;

@property (readonly) unsigned char huong;
@property (readonly) CGPoint cachKeoMan;

@property (readonly) float phongToCuaSo;

@end
