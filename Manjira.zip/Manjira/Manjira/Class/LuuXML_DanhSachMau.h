//
//  LuuXML_DanhSachMau.h
//  Manjira
//
//  Created by 小小 on 16/2/2560.
//

#import <Foundation/Foundation.h>
@class ToMau;


@interface LuuXML_DanhSachMau : NSObject

+ (void)luuVoiURL:(NSURL *)URL_tapTin danhSachMau:(ToMau *)toMau;

@end
