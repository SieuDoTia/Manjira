//
//  LuuXML_ThongTinPhanDang.m
//  Manjira
//
//  Created by 小小 on 18/2/2560.
//  Copyright (c) 2560 BE 星凤. All rights reserved.
//

#import "LuuXML_ThongTinPhanDang.h"
#import "ThongTinPhanDang.h"

@implementation LuuXML_ThongTinPhanDang

+ (void)luuVoiURL:(NSURL *)URL_tapTin thongTinPhanDang:(ThongTinPhanDang *)thongTinPhanDang; {

   // ----
   char *dauTep = "<?xml version=\"1.0\" ?>\n\n";
   
   NSMutableData *dongDuLieu = [NSMutableData dataWithBytes:dauTep length:24];
   
   // ==== đầu phân dạng Julia
   if( [thongTinPhanDang tinhJulia] )
      [dongDuLieu appendData:[[NSString stringWithFormat:@"<%@>\n", NSLocalizedString(@"Julia", @"tên phần tử trong tệp XML")] dataUsingEncoding:NSUTF8StringEncoding]];
   // ==== đầu phân dạng Mandebrot
   else
      [dongDuLieu appendData:[[NSString stringWithFormat:@"<%@>\n", NSLocalizedString(@"Mandelbrot", @"tên phần tử trong tệp XML")] dataUsingEncoding:NSUTF8StringEncoding]];

   [dongDuLieu appendData:[[NSString stringWithFormat:@"   <%@  ", NSLocalizedString(@"thôngTin", @"tên phần tử trong tệp XML")] dataUsingEncoding:NSUTF8StringEncoding]];

   // ---- giải thuật
   [dongDuLieu appendData:[[NSString stringWithFormat:@"%@=\"", NSLocalizedString(@"giảiThuật", @"tên đặc điểm trong tệp XML")] dataUsingEncoding:NSUTF8StringEncoding]];
   [dongDuLieu appendData:[[NSString stringWithFormat:@"%d\" ", [thongTinPhanDang giaiThuat]] dataUsingEncoding:NSUTF8StringEncoding]];

   // ---- trung tâm X
   [dongDuLieu appendData:[[NSString stringWithFormat:@"%@=\"", NSLocalizedString(@"trungTâmX", @"tên đặc điểm trong tệp XML")] dataUsingEncoding:NSUTF8StringEncoding]];
   [dongDuLieu appendData:[[NSString stringWithFormat:@"%21.18f\" ", [thongTinPhanDang trungTamX]] dataUsingEncoding:NSUTF8StringEncoding]];
   
   // ---- trung tâm Y
   [dongDuLieu appendData:[[NSString stringWithFormat:@"%@=\"", NSLocalizedString(@"trungTâmY", @"tên đặc điểm trong tệp XML")] dataUsingEncoding:NSUTF8StringEncoding]];
   [dongDuLieu appendData:[[NSString stringWithFormat:@"%21.18f\" ", [thongTinPhanDang trungTamY]] dataUsingEncoding:NSUTF8StringEncoding]];
   
   // ---- phóng to
   [dongDuLieu appendData:[[NSString stringWithFormat:@"%@=\"", NSLocalizedString(@"phóngTo", @"tên đặc điểm trong tệp XML")] dataUsingEncoding:NSUTF8StringEncoding]];
   [dongDuLieu appendData:[[NSString stringWithFormat:@"%21.18e\" ", [thongTinPhanDang phongTo]] dataUsingEncoding:NSUTF8StringEncoding]];
   
   // ---- mũ
   [dongDuLieu appendData:[[NSString stringWithFormat:@"%@=\"", NSLocalizedString(@"mũ", @"tên đặc điểm tệp XML")] dataUsingEncoding:NSUTF8StringEncoding]];
   [dongDuLieu appendData:[[NSString stringWithFormat:@"%21.18f\" ", [thongTinPhanDang mu]] dataUsingEncoding:NSUTF8StringEncoding]];

   // ---- bán kính nghỉ bình
   [dongDuLieu appendData:[[NSString stringWithFormat:@"%@=\"", NSLocalizedString(@"bánKínhNghỉBình", @"tên phần đặc điểm tệp XML")] dataUsingEncoding:NSUTF8StringEncoding]];
   [dongDuLieu appendData:[[NSString stringWithFormat:@"%21.18f\" ", [thongTinPhanDang banKinhNghiTinhMu2]] dataUsingEncoding:NSUTF8StringEncoding]];
   
   // ---- bề rộng
   [dongDuLieu appendData:[[NSString stringWithFormat:@"%@=\"", NSLocalizedString(@"bềRộng", @"tên đặc điểm trong tệp XML")] dataUsingEncoding:NSUTF8StringEncoding]];
   [dongDuLieu appendData:[[NSString stringWithFormat:@"%d\" ", [thongTinPhanDang beRong]] dataUsingEncoding:NSUTF8StringEncoding]];

   // ---- bề cao
   [dongDuLieu appendData:[[NSString stringWithFormat:@"%@=\"", NSLocalizedString(@"bềCao", @"tên đặc điểm trong tệp XML")] dataUsingEncoding:NSUTF8StringEncoding]];
   [dongDuLieu appendData:[[NSString stringWithFormat:@"%d\" ", [thongTinPhanDang beCao]] dataUsingEncoding:NSUTF8StringEncoding]];
   
   // ---- số lặp lại tối đa
   [dongDuLieu appendData:[[NSString stringWithFormat:@"%@=\"", NSLocalizedString(@"sốLặpLạiTốiĐa", @"tên đặc điểm trong tệp XML")] dataUsingEncoding:NSUTF8StringEncoding]];
   [dongDuLieu appendData:[[NSString stringWithFormat:@"%d\" ", [thongTinPhanDang soLapLaiToiDa]] dataUsingEncoding:NSUTF8StringEncoding]];
   
   // ==== kết thúc phân dạng Julia
   if( [thongTinPhanDang tinhJulia] ) {
      // ---- hằng số thật
      [dongDuLieu appendData:[[NSString stringWithFormat:@"%@=\"", NSLocalizedString(@"hằngSốThật", @"tên đặc điểm trong tệp XML")] dataUsingEncoding:NSUTF8StringEncoding]];
      [dongDuLieu appendData:[[NSString stringWithFormat:@"%21.18f\" ", [thongTinPhanDang hangSoThat]] dataUsingEncoding:NSUTF8StringEncoding]];
      
      // ---- hằng số ảo
      [dongDuLieu appendData:[[NSString stringWithFormat:@"%@=\"", NSLocalizedString(@"hằngSốẢo", @"tên đặc điểm trong tệp XML")] dataUsingEncoding:NSUTF8StringEncoding]];
      [dongDuLieu appendData:[[NSString stringWithFormat:@"%21.18f\"/>\n", [thongTinPhanDang hangSoAo]] dataUsingEncoding:NSUTF8StringEncoding]];
   
      
      [dongDuLieu appendData:[[NSString stringWithFormat:@"/>\n</%@>\n", NSLocalizedString(@"Julia", @"tên phần tử trong tệp XML")] dataUsingEncoding:NSUTF8StringEncoding]];
   }
   // ==== đầu phân dạng Mandebrot
   else
      [dongDuLieu appendData:[[NSString stringWithFormat:@"/>\n</%@>\n", NSLocalizedString(@"Mandelbrot", @"tên phần tử trong tệp XML")] dataUsingEncoding:NSUTF8StringEncoding]];
   
   // ---- lưu tập tin
   [dongDuLieu writeToURL:URL_tapTin atomically:YES];
}

@end
