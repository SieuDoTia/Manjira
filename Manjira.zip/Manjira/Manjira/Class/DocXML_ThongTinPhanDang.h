//
//  DocXML_ThongTinPhanDang.h
//  Manjira
//
//  Created by 小小 on 18/2/2560.
//  Copyright (c) 2560 BE 星凤. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DocXML_ThongTinPhanDang : NSObject <NSXMLParserDelegate> {
   
   NSXMLParser *modelParser;
   
   double banKinhNghiTinhMu2;   // bán kính nghỉ (khi xa hơn, nghỉ tính)
   
   unsigned int beRong;  // độ giải cho hướng X
   unsigned int beCao;  // độ giải cho hướng Y
//   unsigned int tinhCot;   // cột đang tính
//   unsigned int tinhHang;  // hàng đang tính
   
   double trungTamX;
   double trungTamY;
   double phongTo;
   
//   double gocX;       // góc X bắt đầu tính
//   double gocY;       // góc Y bắt đầu tính
//   double tinhX;      // tung độ đang tính
//   double tinhY;      // hoành độ đanh tính
//   double buocTinh;   // bước (cách) giữa điểm
//   double buocTinhPhanTu;   // bước phần tư, cho tính ảnh đẹp hơn
   
//   unsigned short soHangDangTinh;  // số hàng đang tính, thật là hàng của chùn hàng đang tính
   
   unsigned int soLapLaiToiDa;   // số lặp lại tối đa (mực nhgỉ tính và nhận điểm ở trong tậư hợp Mandelbrot)
//   unsigned int soLapLaiToiDaCu;   // số lặp lại tối đa (mực nhgỉ tính và nhận điểm ở trong tậư hợp Mandelbrot)
   
   double mu;   // chỉ xài cho mũ phần số
   unsigned char giaiThuat;   // giải thuật cho tính phân dạng
   
   // ---- tô màu
//   ToMau *toMau;
   
   // ----
//   unsigned int soLuongDiemDaTinh; // số lượng đã tính rồi
//   unsigned int soLuongDiem;       // số lượng cho hết điểm
   
//   BOOL tinhLaiSoLapLai;
   
   // ---- Julia
   BOOL tinhJulia;
   double hangSoThat;   // hằng số thật cho tính Julia
   double hangSoAo;     // hằng số ảo cho tính Julia
   
   BOOL saiLam;         // sai lầm
}

- (unsigned char)docVoiURL:(NSURL *)URL_tapTin;

// ---- của NSXMLParser, phải dùng các tên này
- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI
 qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict;

- (void)parser:(NSXMLParser *)parser parseErrorOccurred:(NSError *)parseError;

@property (readonly) BOOL tinhJulia;
@property (readonly) double hangSoThat;
@property (readonly) double hangSoAo;

@property (readonly) double trungTamX;
@property (readonly) double trungTamY;
@property (readonly) double phongTo;
@property (readonly) double banKinhBinh;
@property (readonly) double mu;
@property (readonly) unsigned char giaiThuat;

@property (readonly) unsigned int beRong;
@property (readonly) unsigned int beCao;

@property (readonly) unsigned int soLapLaiToiDa;

@property (readonly) BOOL saiLam;


@end
