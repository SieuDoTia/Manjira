//
//  ToBong.m
//  Benjarong
//
//  Created by 小小 on 4/1/2554.
//   Cần chéo chương trình tô bóng vào: Targets -> <tên chương trình> ->  Copy Bundle resources

// Nếu tô bóng không hoạt động:
//  - xem nếu được biên dịch
//  - xem được kết nối (xài OpenGL Shader Builder)
//  - xem được biến uniforms có dữ liệu chưa
//  - xem đặc điểm đỉnh có dữ liệu chưa (vertex attributes)
//  - đã đọc họa tiết (nếu có)
//  - họa tiết cỡ kích mũ 2
//  - xem nếu biến có dữ liệu cho uniform và đặc điểm điểm đúng
//  - xem ma trận biến hóa
//  - xem có thể nhìn mô phong (vị trí trước màn chiểu)
//  - xem có vấn đề với màn
//  - nếu họa tiết kỳ mà màu đúng, xem đổi ngược bề rộng/bề cao


#import "ToBong.h"

@implementation ToBong

// ================= SHADER CODE ===================
+ (BOOL)compileShader:(GLuint *)shader type:(GLenum)type filePath:(NSString *)filePath; {

    GLint status;
    const GLchar *source;

    source = (GLchar *)[[NSString stringWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:nil] UTF8String];
    if (!source) {

        NSLog(@"ToBong: compileShader: failed to load vertex shader at path %@", filePath);
        return FALSE;
    }

    *shader = glCreateShader(type);
    glShaderSource(*shader, 1, &source, NULL);
    glCompileShader(*shader);

//#if defined(DEBUG)
    GLint logLength;
    glGetShaderiv(*shader, GL_INFO_LOG_LENGTH, &logLength);
    if(logLength > 0) {

        GLchar *log = (GLchar *)malloc(logLength);
        glGetShaderInfoLog(*shader, logLength, &logLength, log);
        NSLog(@"Shaders: compileShader: %@ log \n%s", filePath, log);
        free(log);
    }


    glGetShaderiv(*shader, GL_COMPILE_STATUS, &status);
    if(status == 0) {
        glDeleteShader(*shader);
        return FALSE;
    }
//#endif
    return TRUE;
}



+ (BOOL)linkAndValidateProgram:(GLuint)program; {
   GLint status;

   glLinkProgram(program);

//#if defined(DEBUG)
   GLint logLength;
   glGetProgramiv(program, GL_INFO_LOG_LENGTH, &logLength);
   if(logLength > 0) {

      GLchar *log = (GLchar *)malloc(logLength);
      glGetProgramInfoLog(program, logLength, &logLength, log);
      NSLog(@"Shaders: linkProgram: Program %d link log:\n%s", program, log);
      free(log);
   }

   glGetProgramiv(program, GL_LINK_STATUS, &status);
   if(status == 0) {
      NSLog(@"Shaders: linkProgram: Failed to link program" );
      return FALSE;
   }

   glValidateProgram(program);
	glGetProgramiv(program, GL_INFO_LOG_LENGTH, &logLength);
    if(logLength > 0) {

      GLchar *log = (GLchar *)malloc(logLength);
      glGetProgramInfoLog(program, logLength, &logLength, log);
      NSLog(@"Shaders: linkProgram: Program %d validate log:\n%s", program, log);
      free(log);
   }

	glGetProgramiv(program, GL_VALIDATE_STATUS, &status);
	if(status == 0) {
      NSLog(@"Shaders: linkProgram: Failed to validate program" );
      return FALSE;
   }
//#endif
   return TRUE;
}


+ (unsigned int)createShaderProgramWithVertexShader:(GLuint)vertexShader andFragmentShader:(GLuint)fragmentShader; {

   GLuint shaderProgram = glCreateProgram();

   // Attach vertex shader to program
   glAttachShader(shaderProgram, vertexShader);

    // Attach fragment shader to program
   glAttachShader(shaderProgram, fragmentShader);

   return shaderProgram;
}

@end
