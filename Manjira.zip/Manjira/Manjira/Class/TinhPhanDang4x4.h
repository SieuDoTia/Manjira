//
//  TinhPhanDang4x4.h
//  Manjira
//
//  Created by 小小 on 10/10/2557.
//

#import <Foundation/Foundation.h>
#import "GiaiThuat.h"

@class ThongTinPhanDang;

@interface TinhPhanDang4x4 : NSOperation {
   
   // ---- biến phân dạng
   double buoc;       // bước giữa điểm ảnh (không gian tọa độ phân dạng)
   double buocTinhPhanTu;  // bước phần tư (không gian tọa độ phân dạng)
   double gocX;       // tọa độ x góc thành phần đang tính (không gian tọa độ phân dạng)
   double gocY;       // tọa độ y góc thành phần đang tính (không gian tọa độ phân dạng)
   double banKinhNghiTinhMu2;
   
   double x;   // tọa đồ x trong không gian tọa độ phân dạng đang tính
   double y;   // tọa đồ y trong không gian tọa độ phân dạng đang tính
   double mu;  // mũ phân dạng

   // ---- biến ảnh
   unsigned short beRong;    // bề rộng ảnh, cũng cần cho tính địa chỉ
   unsigned int soDiem;      // số điểm ảnh đang tính
   unsigned int soLuongDiem; // số lượng điểm ảnh
   unsigned int diaChi;      // điạ chỉ trong dữ liệu ảnh
   unsigned int diaChiCuoi;  // cho bảo vệ đi huốt ngaòi mảng
   unsigned short cot;       // cột ảnh đang tính trong thành phần
   unsigned short hang;      // hàng ảnh đang tính trong thành phần

   
   // ---- biến thêm cho phân dạng Julia
   BOOL tinhJulia;        // bật/tắt tính phần dạng Julia
   double hangSoJuliaX;   // hằng số của tọa độ x cho phân dạng Julia
   double hangSoJuliaY;   // hằng số của tọa độ y cho phân dạng Julia

   // ---- lặp lại
   unsigned int lapLaiToiDa;   // lặp lại tối đa cho nghỉ tính phân dạng tại một địa điểm trong phân dạng
   unsigned int *mangSoLapLai;   // mạng chứa kết qủa lại từ tính phân dạng
   
   unsigned short soHang;      // số hàng bắt đầu tính thành phần của ảnh
   unsigned short soLuongHang; // số lượng hàng trong thành phần này
   
   unsigned short soCot;      // số cột bắt đầu tính thành phần của ảnh
   unsigned short soLuongCot; // số lượng cột trong thành phần này
   
   id <GiaiThuat>  giaiThuat;  // hàm cho giải thuật phân dạng
}

- (id)initVoiThongTinPhanDang:(ThongTinPhanDang *)thongTinPhanDang soLuongHang:(unsigned short)_soLuongHang soLuongCot:(unsigned short)_soLuongCot;

@property (readonly) unsigned short soHang;
@property (readonly) unsigned short soLuongHang;
@property (readonly) unsigned short soCot;
@property (readonly) unsigned short soLuongCot;

@property (readwrite) id <GiaiThuat> giaiThuat;


@end
