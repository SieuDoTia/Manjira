//
//  ToMau.m
//  Manjira
//
//  Created by 小小 on 21/11/2556.
// Sở Vân Cứu Giá

/* Lets say you start with the complex number z0 and iterate n times until it escapes. Let the end point be zn.
A smooth value wolud be
nsmooth := n + 1 - Math.log(Math.log(zn.abs()))/Math.log(2)
This only works for mandelbrot, if you want to compute a smoot function for julia sets, then use
Complex z = new Complex(x,y);
double smoothcolor = Math.exp(-z.abs());

for(i=0;i<max_iter && z.abs() < 30;i++) {
   z = f(z);
   smoothcolor += Math.exp(-z.abs());
}
Then smoothcolor is in the interval (0,max_iter).
Divide smoothcolor with max_iter to get a value between 0 and 1.
To get a smooth color from the value:
This can be passed to for example (in Java):
Color.HSBtoRGB(0.95f + 10 * smoothcolor ,0.6f,1.0f);
since the first value in HSB color parameters is used to define the color from the color circle.
*/

#import "ToMau.h"
#import "ThongTinPhanDang.h"


@implementation ToMau


unsigned char soLuongMau = 3;
//float cachGiuaMau = 1.0f/(soLuongMau - 1);
// phong viên từ báo

- (id)init; {
   
   self = [super init];
   
   if( self ) {
      // ---- chép danh sách màu
      soLuongMau = 0;
      danhSachMau = malloc( kSO_LUONG__MAU_TOI_DA*sizeof( float ) << 2 );
      
      // ---- mặc định là màu đen
      mauTap[0] = 0.0f;
      mauTap[1] = 0.0f;
      mauTap[2] = 0.0f;
      mauTap[3] = 1.0f;
      
      // ---- mặc định
      chuTrinhMau = 200;
      mu = 0.5f;
      dich = 0;
      soLapLaiToiDa = 200;
      
      // ---- đặt màu chuẩn 0
      [self datVuTruong];
   }
   
   return self;
}

#pragma mark ---- Chèn Màu
- (BOOL)chenMau:(float *)mau taiChiSo:(unsigned char)chiSoChen; {

   if( soLuongMau < kSO_LUONG__MAU_TOI_DA ) {
      if( chiSoChen > soLuongMau ) {
         chiSoChen = soLuongMau;
         unsigned int diaChi = chiSoChen << 2;
         // ---- chép màu
         danhSachMau[diaChi] = mau[0];
         danhSachMau[diaChi+1] = mau[1];
         danhSachMau[diaChi+2] = mau[2];
         danhSachMau[diaChi+3] = mau[3];
         // ---- tăng thêm số lượng màu
         soLuongMau++;
      }
      else {
         // ---- dịch màu
         unsigned short chiSo = soLuongMau;
         unsigned int diaChi = soLuongMau << 2;
         while ( chiSo > chiSoChen ) {
            danhSachMau[diaChi] = danhSachMau[diaChi-4];
            danhSachMau[diaChi+1] = danhSachMau[diaChi-3];
            danhSachMau[diaChi+2] = danhSachMau[diaChi-2];
            danhSachMau[diaChi+3] = danhSachMau[diaChi-1];
            diaChi -= 4;
            chiSo--;
         }
         danhSachMau[diaChi] = mau[0];
         danhSachMau[diaChi+1] = mau[1];
         danhSachMau[diaChi+2] = mau[2];
         danhSachMau[diaChi+3] = mau[3];
         
         soLuongMau++;
      }
      
      // ---- tính cách giữa màu
      if( soLuongMau > 1 )
         cachGiuaMau = 1.0f/(soLuongMau - 1);
      
      return YES;
   }
   else {
      NSLog( @"ToMau: chenMau: danh sách màu đây, số lượng màu = %d", soLuongMau );
      return NO;
   }
   
}

#pragma mark ---- Xóa Màu
- (BOOL)xoaMauTaiChiSo:(unsigned short)chiSoMauBo; {
   if( soLuongMau > 2 ) {     // không cho bỏ màu nào nếu ít hơn 2 màu
      unsigned int diaChi = chiSoMauBo << 2;
      unsigned short soMau = chiSoMauBo;

      soLuongMau--;
      while( soMau < soLuongMau ) {
         danhSachMau[diaChi] = danhSachMau[diaChi+4];
         danhSachMau[diaChi+1] = danhSachMau[diaChi+5];
         danhSachMau[diaChi+2] = danhSachMau[diaChi+6];
         danhSachMau[diaChi+3] = danhSachMau[diaChi+7];
         soMau++;
         diaChi += 4;
      }

      cachGiuaMau = 1.0f/(soLuongMau - 1);
      return YES;
   }
   
   return NO;  // không được xóa màu (phải có ít nhất 2 màu)
}

#pragma mark ---- Đặt Màu Tập
- (void)datMauTapDo:(float)mauDo luc:(float)mauLuc xanh:(float)mauXanh duc:(float)duc; {
   
   mauTap[0] = mauDo;
   mauTap[1] = mauLuc;
   mauTap[2] = mauXanh;
   mauTap[3] = duc;
}


#pragma mark ---- Tô Màu 1 x 1
- (void)to1x1VoiThongTin:(ThongTinPhanDang *)thongTinPhanDang soHang:(unsigned short)soHang
          soLuongHang:(unsigned short)soLuongHang; {

   unsigned int beRong = [thongTinPhanDang beRong];  // ---- bề rộng một hàng
   unsigned int beCao = [thongTinPhanDang beCao];

   // ---- hơn bề cao, không có gì để tính
   if( soHang >= beCao )
      return;
   // ---- coi trừng cho các hàng cuối
   if( soHang + soLuongHang >= beCao ) {
      soLuongHang = [thongTinPhanDang beCao] - soHang;
   }

   // ---- tính số lượng điểm cần tô
   unsigned int soDiemCanTo = soLuongHang * beRong;
   unsigned int soDiem = 0;
   
   unsigned int diaChi = soHang*beRong << 2;

   float *mangMau= [thongTinPhanDang mangMau];
   unsigned int *mangSoLapLai = [thongTinPhanDang mangSoLapLai];

   while( soDiem < soDiemCanTo ) {
      // ---- tô màu
      float mau[4] = {1.0f, 0.0f, 0.0f, 1.0f};
      [self toMau:mau choLapLai:mangSoLapLai[diaChi >> 2] vaGioiHanLapLai:soLapLaiToiDa];
      
      mangMau[diaChi] = mau[0];
      mangMau[diaChi+1] = mau[1];
      mangMau[diaChi+2] = mau[2];
      mangMau[diaChi+3] = mau[3];
      
      diaChi += 4;
      soDiem++;
   }
}


- (void)to4x4VoiThongTin:(ThongTinPhanDang *)thongTinPhanDang soHang:(unsigned short)soHang
             soLuongHang:(unsigned short)soLuongHang; {
   
   unsigned int beRong = [thongTinPhanDang beRong];  // ---- bề rộng một hàng
   unsigned int beCao = [thongTinPhanDang beCao];

   // ---- hơn bề cao, không có gì để tính
   if( soHang >= beCao )
      return;
   // ---- coi trừng cho các hàng cuối
   if( soHang + soLuongHang >= beCao ) {
      soLuongHang = [thongTinPhanDang beCao] - soHang;
   }

   // ---- tính số lượng điểm cần tô
   unsigned int soDiemCanTo = soLuongHang * beRong;
   unsigned int soDiem = 0;
   
   unsigned int diaChi = soHang*beRong << 2;
   
   float *mangMau= [thongTinPhanDang mangMau];
   unsigned int *mangSoLapLai = [thongTinPhanDang mangSoLapLai];
   
   while( soDiem < soDiemCanTo ) {
      // ----
      unsigned int soLuongLapLai0 = mangSoLapLai[diaChi];
      unsigned int soLuongLapLai1 = mangSoLapLai[diaChi+1];
      unsigned int soLuongLapLai2 = mangSoLapLai[diaChi+2];
      unsigned int soLuongLapLai3 = mangSoLapLai[diaChi+3];

      // ---- tô màu
      float mau0[4] = {1.0f, 1.0f, 1.0f, 1.0f};
      float mau1[4] = {1.0f, 1.0f, 1.0f, 1.0f};
      float mau2[4] = {1.0f, 1.0f, 1.0f, 1.0f};
      float mau3[4] = {1.0f, 1.0f, 1.0f, 1.0f};
      [self toMau:mau0 choLapLai:soLuongLapLai0 vaGioiHanLapLai:soLapLaiToiDa];
      [self toMau:mau1 choLapLai:soLuongLapLai1 vaGioiHanLapLai:soLapLaiToiDa];
      [self toMau:mau2 choLapLai:soLuongLapLai2 vaGioiHanLapLai:soLapLaiToiDa];
      [self toMau:mau3 choLapLai:soLuongLapLai3 vaGioiHanLapLai:soLapLaiToiDa];

      // ---- tính trung bình
      mangMau[diaChi] = (mau0[0] + mau1[0] + mau2[0] + mau3[0])*0.25f;
      mangMau[diaChi+1] = (mau0[1] + mau1[1] + mau2[1] + mau3[1])*0.25f;
      mangMau[diaChi+2] = (mau0[2] + mau1[2] + mau2[2] + mau3[2])*0.25f;
      mangMau[diaChi+3] = (mau0[3] + mau1[3] + mau2[3] + mau3[3])*0.25f;
      
      diaChi += 4;
      soDiem++;
   }
}


#pragma mark ---- Tô Màu
- (void)toMau:(float *)mau choLapLai:(unsigned int)lapLai vaGioiHanLapLai:(unsigned int)gioiHanLapLai; {
  
   if( lapLai == gioiHanLapLai ) {
      mau[0] = mauTap[0];
      mau[1] = mauTap[1];
      mau[2] = mauTap[2];
      mau[3] = mauTap[3];
   }
   else {
      // ---- tính phần số
      float phanSo = (float)lapLai/(float)chuTrinhMau;

      // ---- tính phần số mũ (áp dụng hàm số)
      float phanSoMu = powf(phanSo, mu);
      
      // ---- thừa/dư
      float thua = phanSoMu - floorf(phanSoMu);
      
      // ---- dịch màu
      float soPhanDich = (float)dich/(float)chuTrinhMau;
      thua += soPhanDich;
      if( thua > 1.0f )
         thua -= 1.0f;
   
      // ---- đoán màu
      unsigned int doanMau = thua/cachGiuaMau;
      unsigned int diaChiMau = doanMau << 2;
      // ----
      float soPhanMau = thua/cachGiuaMau;
      float cach = soPhanMau - doanMau;
      
      mau[0] = (1.0f - cach)*danhSachMau[diaChiMau] + cach*danhSachMau[diaChiMau+4];
      mau[1] = (1.0f - cach)*danhSachMau[diaChiMau+1] + cach*danhSachMau[diaChiMau+5];
      mau[2] = (1.0f - cach)*danhSachMau[diaChiMau+2] + cach*danhSachMau[diaChiMau+6];
      mau[3] = (1.0f - cach)*danhSachMau[diaChiMau+3] + cach*danhSachMau[diaChiMau+7];
   }
}

/* Chưa thử !!! */
- (void)toMauMin:(float *)mau choLapLai:(unsigned int)lapLai vaGioiHanLapLai:(unsigned int)gioiHanLapLai
     viTriThoatX:(float)viTriThoatX y:(float)viTriThoatY banKinhThoat:(float)banKinhThoat; {
   
   if( lapLai == gioiHanLapLai ) {
      mau[0] = mauTap[0];
      mau[1] = mauTap[1];
      mau[2] = mauTap[2];
      mau[3] = mauTap[3];
   }
   else {
      // ----
      float banKinhDiem = sqrtf( viTriThoatX*viTriThoatX + viTriThoatY*viTriThoatY );
      float giua = logf(banKinhDiem)/logf(banKinhThoat);

      // ---- tính phần số
      float phanSo = (lapLai + giua)/(float)chuTrinhMau;
      
      // ---- tính phần số mũ (áp dụng hàm số)
      float phanSoMu = powf(phanSo, mu);
      
      // ---- thừa
      float thua = phanSoMu - floorf(phanSoMu);
      
      // ---- dịch màu
      float soPhanDich = (float)dich/(float)chuTrinhMau;
      thua += soPhanDich;
      if( thua > 1.0f )
         thua -= 1.0f;
      
      // ---- đoán màu
      unsigned int doanMau = thua/cachGiuaMau;
      unsigned int diaChiMau = doanMau << 2;
      // ----
      float soPhanMau = thua/cachGiuaMau;
      float cach = soPhanMau - doanMau;
      
      mau[0] = (1.0f - cach)*danhSachMau[diaChiMau] + cach*danhSachMau[diaChiMau+4];
      mau[1] = (1.0f - cach)*danhSachMau[diaChiMau+1] + cach*danhSachMau[diaChiMau+5];
      mau[2] = (1.0f - cach)*danhSachMau[diaChiMau+2] + cach*danhSachMau[diaChiMau+6];
      mau[3] = (1.0f - cach)*danhSachMau[diaChiMau+3] + cach*danhSachMau[diaChiMau+7];
   }
}


#pragma mark ---- Tô Màu Lại
+ (void)toMauLai:(ToMau *)toMau choThongTinPhanDang:(ThongTinPhanDang *)thongTinPhanDang; {
   
   unsigned int diaChi = 0;  // địa chỉ
   unsigned int diaChiCuoi = [thongTinPhanDang soLuongDiem] << 2;  // địa chỉ cho điểm cuối
   unsigned int soDiem = 0;   // số điểm đang tô màu
   
   unsigned int *mangSoLapLai = [thongTinPhanDang mangSoLapLai];
   float *mangMau = [thongTinPhanDang mangMau];
   unsigned int soLapLaiToiDa = [thongTinPhanDang soLapLaiToiDa];
   
   // ---- tô màu
   float mau[4] = {1.0f, 1.0f, 1.0f, 1.0f};
   
   while( diaChi < diaChiCuoi) {
      [toMau toMau:mau choLapLai:mangSoLapLai[soDiem] vaGioiHanLapLai:soLapLaiToiDa];
      mangMau[diaChi] = mau[0];
      mangMau[diaChi+1] = mau[1];
      mangMau[diaChi+2] = mau[2];
      mangMau[diaChi+3] = mau[3];
      diaChi += 4;
      soDiem++;
   }
   
}

#pragma mark ---- Chép
+ (void)chepToMauNguon:(ToMau *)toMauNguon toMauDich:(ToMau *)toMauDich; {

   // ---- chép danh sách màu
   unsigned short soLuongMau = [toMauNguon soLuongMau] << 2; // nhân 4 vì mỗi màu có 4 thành phần 
   float *danhSachMauNguon = [toMauNguon danhSachMau];
   float *danhSachMauDich = [toMauDich danhSachMau];
   
   unsigned short chiSo = 0;
   while( chiSo < soLuongMau ) {
      danhSachMauDich[chiSo] = danhSachMauNguon[chiSo];
      danhSachMauDich[chiSo+1] = danhSachMauNguon[chiSo+1];
      danhSachMauDich[chiSo+2] = danhSachMauNguon[chiSo+2];
      danhSachMauDich[chiSo+3] = danhSachMauNguon[chiSo+3];
      chiSo += 4;
   }
   
   // ---- chèp các đặc điểm khác
   [toMauDich setSoLapLaiToiDa:soLuongMau];
   [toMauDich setChuTrinhMau:[toMauNguon chuTrinhMau]];
   [toMauDich setMu:[toMauNguon mu]];
   [toMauDich setDich:[toMauNguon dich]];
   [toMauDich setSoLapLaiToiDa:[toMauNguon soLapLaiToiDa]];
}

#pragma mark ---- Vẽ Lại
- (void)veLaiVoiMangMau:(float *)mangMau vaMangSoLuongLapLai:(unsigned int *)mangSoLuongLapLai soLuongDiem:(unsigned int)soLuongDiem vaGioiHanLapLai:(unsigned int)gioiHanLapLai; {

   unsigned int diaChi = 0;
   unsigned int diaChiMau = 0;
   while( diaChi < soLuongDiem ) {
      float mau[4];
      [self toMau:mau choLapLai:mangSoLuongLapLai[diaChi] vaGioiHanLapLai:gioiHanLapLai];

      mangMau[diaChiMau] = mau[0];
      mangMau[diaChiMau+1] = mau[1];
      mangMau[diaChiMau+2] = mau[2];
      mangMau[diaChiMau+3] = mau[3];

      diaChiMau += 4;
      diaChi++;
   }
}

#pragma mark ---- Nâng Cấp Màu
- (void)thayMau:(float *)mau chiSo:(unsigned char)soMau; {
   
   unsigned short diaChi = soMau << 2;

   danhSachMau[diaChi] = mau[0];
   danhSachMau[diaChi+1] = mau[1];
   danhSachMau[diaChi+2] = mau[2];
   danhSachMau[diaChi+3] = mau[3];
}

- (void)thayMauTapHop:(float *)mau; {

   mauTap[0] = mau[0];
   mauTap[1] = mau[1];
   mauTap[2] = mau[2];
   mauTap[3] = mau[3];
}
// #pragma mark ---- Đổi Màu
/*- (void)doiRGB:(float *)rgb thanhHSL:(float *)hsl {

   // ---- thành phần tìm nhỏ nhất
   float nhoNhat = rgb[0];
   if( rgb[1] < nhoNhat )
      nhoNhat = rgb[1];
   if( rgb[2] < nhoNhat )
      nhoNhat = rgb[2];
   
   // ---- thành phần lớn nhất
   float lonNhat = rgb[0];
   if( rgb[1] > lonNhat )
      lonNhat = rgb[1];
   if( rgb[2] > lonNhat )
      lonNhat = rgb[2];

   hsl[0] = (nhoNhat + lonNhat)*0.5f;
   hsl[1] = hsl[0];
   hsl[2] = hsl[0];
   
   // ---- màu xám
   if( nhoNhat == lonNhat ){
      hsl[0] = 0.0f;
      hsl[1] = 0.0f;
   }
   else {
      float cach = lonNhat - nhoNhat;
      
      hsl[1] = hsl[2] > 0.5f ? cach / (2.0f - lonNhat - nhoNhat) : cach / (lonNhat + nhoNhat);

      if( rgb[0] == lonNhat )
         hsl[0] = (rgb[1] - rgb[2]) / cach + (rgb[1] < rgb[2] ? 6.0f : 0.0f);
      else if( rgb[1] == lonNhat )
         hsl[0] = (rgb[2] - rgb[0]) / cach + 2.0f;
      else
         hsl[0] = (rgb[0] - rgb[1]) /cach + 4.0f;

      hsl[0] /= 6.0f;
   }
}

- (void)doiHSL:(float *)hsl thanhRGB:(float *)rgb {

   if(hsl[1] == 0){  // màu xám
      rgb[0] = hsl[2];
      rgb[1] = hsl[2];
      rgb[2] = hsl[2];
   }
   else {
      float q = hsl[2] < 0.5f ? hsl[2] * (1.0f + hsl[1]) : hsl[1] + hsl[2] - hsl[1]*hsl[2];
      float p = 2.0f * hsl[2] - q;

      rgb[0] = [self tinhMauChoP:p q:q t:hsl[0] + 0.333333f];
      rgb[1] = [self tinhMauChoP:p q:q t:hsl[0]];
      rgb[2] = [self tinhMauChoP:p q:q t:hsl[0] - 0.333333f];
   }
   
}

- (float)tinhMauChoP:(float)p q:(float)q t:(float)t; {

   if(t < 0)
      t += 1;
   if(t > 1)
      t -= 1;
   if(t < 0.166667f)
      return p + (q - p) * 6.0f * t;

   if(t < 0.5f)
      return q;
   if(t < 0.666667f)
      return p + (q - p) * (0.666667 - t) * 6.0f;
   return p;
}
*/

- (void)datKhong; {
   // ---- xóa hết màu
   soLuongMau = 0;
   
   float mau0[] = {1.000000f, 1.000000f, 1.000000f, 1.0f};
   [self chenMau:mau0 taiChiSo:0];
   float mau1[] = {0.000000f, 0.000000f, 0.000000f, 1.0f};
   [self chenMau:mau1 taiChiSo:1];
}

- (void)datVuTruong; {
   // ---- xóa hết màu
   soLuongMau = 0;

   float mau0[] = {0.000000f, 0.152941f, 0.152941f, 1.0f};
   [self chenMau:mau0 taiChiSo:0];
   float mau1[] = {0.215686f, 0.215686f, 0.686275f, 1.0f};
   [self chenMau:mau1 taiChiSo:1];
   float mau2[] = {0.286275f, 0.168627f, 0.494118f, 1.0f};
   [self chenMau:mau2 taiChiSo:2];
   float mau3[] = {0.152941f, 0.058824f, 0.149020f, 1.0f};
   [self chenMau:mau3 taiChiSo:3];
   float mau4[] = {0.694118f, 0.098039f, 0.309804f, 1.0f};
   [self chenMau:mau4 taiChiSo:4];
   float mau5[] = {1.000000f, 0.000000f, 0.000000f, 1.0f};
   [self chenMau:mau5 taiChiSo:5];
   float mau6[] = {0.725490f, 0.301961f, 0.090196f, 1.0f};
   [self chenMau:mau6 taiChiSo:6];
   float mau7[] = {0.141176f, 0.145098f, 0.054902f, 1.0f};
   [self chenMau:mau7 taiChiSo:7];
   float mau8[] = {0.341176f, 0.537255f, 0.113725f, 1.0f};
   [self chenMau:mau8 taiChiSo:8];
   float mau9[] = {0.000000f, 1.000000f, 0.000000f, 1.0f};
   [self chenMau:mau9 taiChiSo:9];
   float mau10[] = {0.137255f, 0.615686f, 0.572549f, 1.0f};
   [self chenMau:mau10 taiChiSo:10];
   float mau11[] = {0.074510f, 0.074510f, 0.152941f, 1.0f};
   [self chenMau:mau11 taiChiSo:11];
   float mau12[] = {0.380392f, 0.098039f, 0.541176f, 1.0f};
   [self chenMau:mau12 taiChiSo:12];
   float mau13[] = {0.764706f, 0.000000f, 0.756863f, 1.0f};
   [self chenMau:mau13 taiChiSo:13];
   float mau14[] = {0.596078f, 0.078431f, 0.450980f, 1.0f};
   [self chenMau:mau14 taiChiSo:14];
   float mau15[] = {0.152941f, 0.074510f, 0.074510f, 1.0f};
   [self chenMau:mau15 taiChiSo:15];
   float mau16[] = {0.674510f, 0.498039f, 0.105882f, 1.0f};
   [self chenMau:mau16 taiChiSo:16];
   float mau17[] = {0.901961f, 0.917647f, 0.000000f, 1.0f};
   [self chenMau:mau17 taiChiSo:17];
   float mau18[] = {0.000000f, 0.498039f, 0.047059f, 1.0f};
   [self chenMau:mau18 taiChiSo:18];
   float mau19[] = {0.000000f, 0.152941f, 0.152941f, 1.0f};
   [self chenMau:mau19 taiChiSo:19];
}

- (void)datMuaDong; {
   // ---- xóa hết màu
   soLuongMau = 0;

   float mau0[] = {0.000000f, 0.000000f, 0.200000f, 1.0f};
   [self chenMau:mau0 taiChiSo:0];
   float mau1[] = {0.300000f, 0.300000f, 0.700000f, 1.0f};
   [self chenMau:mau1 taiChiSo:1];
   float mau2[] = {1.000000f, 1.000000f, 1.000000f, 1.0f};
   [self chenMau:mau2 taiChiSo:2];
   float mau3[] = {0.300000f, 0.300000f, 0.700000f, 1.0f};
   [self chenMau:mau3 taiChiSo:3];
   float mau4[] = {0.000000f, 0.000000f, 0.200000f, 1.0f};
   [self chenMau:mau4 taiChiSo:4];
}


- (void)datGiangSinh; { //
   // ---- xóa hết màu
   soLuongMau = 0;
   
   float mau0[] = {0.000000f, 0.200000f, 0.000000f, 1.0f};
   [self chenMau:mau0 taiChiSo:0];
   float mau1[] = {0.300000f, 0.900000f, 0.250000f, 1.0f};
   [self chenMau:mau1 taiChiSo:1];
   float mau2[] = {1.000000f, 1.00000f, 1.000000f, 1.0f};
   [self chenMau:mau2 taiChiSo:2];
   float mau3[] = {1.000000f, 0.500000f, 0.500000f, 1.0f};
   [self chenMau:mau3 taiChiSo:3];
   float mau4[] = {1.000000f, 0.000000f, 0.100000f, 1.0f};
   [self chenMau:mau4 taiChiSo:4];
   float mau5[] = {0.500000f, 0.000000f, 0.050000f, 1.0f};
   [self chenMau:mau5 taiChiSo:5];
   float mau6[] = {1.000000f, 1.000000f, 1.000000f, 1.0f};
   [self chenMau:mau6 taiChiSo:6];
   float mau7[] = {0.000000f, 0.200000f, 0.000000f, 1.0f};
   [self chenMau:mau7 taiChiSo:7];
}

- (void)datHoaHongVaXanh; {  // hoa hồng và xanh
   // ---- xóa hết màu
   soLuongMau = 0;
   
   float mau0[] = {0.000000f, 0.700000f, 1.000000f, 1.0f};
   [self chenMau:mau0 taiChiSo:0];
   float mau1[] = {0.800000f, 0.900000f, 1.00000f, 1.0f};
   [self chenMau:mau1 taiChiSo:1];
   float mau2[] = {0.970000f, 0.700000f, 1.000000f, 1.0f};
   [self chenMau:mau2 taiChiSo:2];
   float mau3[] = {1.000000f, 0.450000f, 0.750000f, 1.0f};
   [self chenMau:mau3 taiChiSo:3];
   float mau4[] = {1.000000f, 0.700000f, 0.7500000f, 1.0f};
   [self chenMau:mau4 taiChiSo:4];
   float mau5[] = {0.430000f, 0.320000f, 0.650000f, 1.0f};
   [self chenMau:mau5 taiChiSo:5];
   float mau6[] = {0.000000f, 0.700000f, 1.000000f, 1.0f};
   [self chenMau:mau6 taiChiSo:6];
}


- (void)datSaMac; {  // sa mạc
   // ---- xóa hết màu
   soLuongMau = 0;

   float mau0[] = {1.000000f, 1.00000f, 0.700000f, 1.0f};
   [self chenMau:mau0 taiChiSo:0];
   float mau1[] = {1.000000f, 0.95000f, 0.900000f, 1.0f};
   [self chenMau:mau1 taiChiSo:2];
   float mau2[] = {1.000000f, 0.800000f, 0.500000f, 1.0f};
   [self chenMau:mau2 taiChiSo:3];
   float mau3[] = {1.000000f, 0.700000f, 0.650000f, 1.0f};
   [self chenMau:mau3 taiChiSo:4];
   float mau4[] = {0.800000f, 0.150000f, 0.200000f, 1.0f};
   [self chenMau:mau4 taiChiSo:5];
   float mau5[] = {0.500000f, 0.150000f, 0.200000f, 1.0f};
   [self chenMau:mau5 taiChiSo:6];
   float mau6[] = {0.500000f, 0.150000f, 0.600000f, 1.0f};
   [self chenMau:mau6 taiChiSo:7];
   float mau7[] = {1.000000f, 0.800000f, 0.100000f, 1.0f};
   [self chenMau:mau7 taiChiSo:8];
   float mau8[] = {1.000000f, 1.000000f, 0.700000f, 1.0f};
   [self chenMau:mau8 taiChiSo:9];
}


- (void)datBauTroiSaMac; {  // bầu trời sa mạc
   // ---- xóa hết màu
   soLuongMau = 0;
   
   float mau0[] = {0.000000f, 0.400000f, 1.000000f, 1.0f};
   [self chenMau:mau0 taiChiSo:0];
   float mau1[] = {0.300000f, 0.800000f, 1.000000f, 1.0f};
   [self chenMau:mau1 taiChiSo:1];
   float mau2[] = {1.000000f, 0.95000f, 0.900000f, 1.0f};
   [self chenMau:mau2 taiChiSo:2];
   float mau3[] = {1.000000f, 0.800000f, 0.500000f, 1.0f};
   [self chenMau:mau3 taiChiSo:3];
   float mau4[] = {1.000000f, 0.700000f, 0.650000f, 1.0f};
   [self chenMau:mau4 taiChiSo:4];
   float mau5[] = {0.800000f, 0.150000f, 0.200000f, 1.0f};
   [self chenMau:mau5 taiChiSo:5];
   float mau6[] = {0.500000f, 0.150000f, 0.200000f, 1.0f};
   [self chenMau:mau6 taiChiSo:6];
   float mau7[] = {0.500000f, 0.150000f, 0.600000f, 1.0f};
   [self chenMau:mau7 taiChiSo:7];
   float mau8[] = {1.000000f, 0.800000f, 0.100000f, 1.0f};
   [self chenMau:mau8 taiChiSo:8];
   float mau9[] = {1.000000f, 1.000000f, 0.700000f, 1.0f};
   [self chenMau:mau9 taiChiSo:9];
   float mau10[] = {0.000000f, 0.400000f, 1.000000f, 1.0f};
   [self chenMau:mau10 taiChiSo:10];
}


- (void)datThaiDuong; {  // thải dương
   // ---- xóa hết màu
   soLuongMau = 0;
   
   float mau0[] = {0.000000f, 0.000000f, 0.500000f, 1.0f};
   [self chenMau:mau0 taiChiSo:0];
   float mau1[] = {0.000000f, 0.400000f, 0.900000f, 1.0f};
   [self chenMau:mau1 taiChiSo:1];
   float mau2[] = {0.800000f, 1.00000f, 1.000000f, 1.0f};
   [self chenMau:mau2 taiChiSo:2];
   float mau3[] = {0.000000f, 0.700000f, 0.850000f, 1.0f};
   [self chenMau:mau3 taiChiSo:3];
   float mau4[] = {0.000000f, 0.850000f, 0.850000f, 1.0f};
   [self chenMau:mau4 taiChiSo:4];
   float mau5[] = {0.650000f, 1.000000f, 1.000000f, 1.0f};
   [self chenMau:mau5 taiChiSo:5];
   float mau6[] = {0.000000f, 0.000000f, 0.500000f, 1.0f};
   [self chenMau:mau6 taiChiSo:6];

}

- (void)datSoCoLa; {  // sô cô la
   // ---- xóa hết màu
   soLuongMau = 0;
   
   float mau0[] = {1.000000f, 1.000000f, 0.900000f, 1.0f};
   [self chenMau:mau0 taiChiSo:0];
   float mau1[] = {0.400000f, 0.10000f, 0.000000f, 1.0f};
   [self chenMau:mau1 taiChiSo:1];
   float mau2[] = {0.250000f, 0.10000f, 0.000000f, 1.0f};
   [self chenMau:mau2 taiChiSo:2];
   float mau3[] = {0.700000f, 0.500000f, 0.300000f, 1.0f};
   [self chenMau:mau3 taiChiSo:3];
   float mau4[] = {0.600000f, 0.300000f, 0.200000f, 1.0f};
   [self chenMau:mau4 taiChiSo:4];
   float mau5[] = {0.950000f, 0.700000f, 0.400000f, 1.0f};
   [self chenMau:mau5 taiChiSo:5];
   float mau6[] = {1.000000f, 0.750000f, 0.800000f, 1.0f};
   [self chenMau:mau6 taiChiSo:6];
   float mau7[] = {1.000000f, 1.000000f, 0.900000f, 1.0f};
   [self chenMau:mau7 taiChiSo:7];
}

- (void)datSoCoLaDeo; {  // sô cô la
   // ---- xóa hết màu
   soLuongMau = 0;
   
   float mau0[] = {1.000000f, 0.750000f, 0.550000f, 1.0f};
   [self chenMau:mau0 taiChiSo:0];
   float mau1[] = {0.400000f, 0.00000f, 0.000000f, 1.0f};
   [self chenMau:mau1 taiChiSo:1];
   float mau2[] = {1.00000f, 0.55000f, 0.000000f, 1.0f};
   [self chenMau:mau2 taiChiSo:2];
   float mau3[] = {0.700000f, 0.500000f, 0.300000f, 1.0f};
   [self chenMau:mau3 taiChiSo:3];
   float mau4[] = {0.600000f, 0.230000f, 0.000000f, 1.0f};
   [self chenMau:mau4 taiChiSo:4];
   float mau5[] = {1.000000f, 0.750000f, 0.550000, 1.0f};
   [self chenMau:mau5 taiChiSo:5];
}

- (void)datCauVong; {  //  cầu vòng
   // ---- xóa hết màu
   soLuongMau = 0;
   
   float mau0[] = {1.000000f, 0.000000f, 0.000000f, 1.0f};
   [self chenMau:mau0 taiChiSo:0];
   float mau1[] = {1.000000f, 0.500000f, 0.000000f, 1.0f};
   [self chenMau:mau1 taiChiSo:1];
   float mau2[] = {1.000000f, 1.000000f, 0.000000f, 1.0f};
   [self chenMau:mau2 taiChiSo:2];
   float mau3[] = {0.500000f, 1.000000f, 0.000000f, 1.0f};
   [self chenMau:mau3 taiChiSo:3];
   float mau4[] = {0.000000f, 1.000000f, 0.000000f, 1.0f};
   [self chenMau:mau4 taiChiSo:4];
   float mau5[] = {0.000000f, 1.000000f, 0.500000f, 1.0f};
   [self chenMau:mau5 taiChiSo:5];
   float mau6[] = {0.000000f, 1.000000f, 1.000000f, 1.0f};
   [self chenMau:mau6 taiChiSo:6];
   float mau7[] = {0.000000f, 0.500000f, 1.000000f, 1.0f};
   [self chenMau:mau7 taiChiSo:7];
   float mau8[] = {0.000000f, 0.000000f, 1.000000f, 1.0f};
   [self chenMau:mau8 taiChiSo:8];
   float mau9[] = {0.500000f, 0.000000f, 1.000000f, 1.0f};
   [self chenMau:mau9 taiChiSo:9];
   float mau10[] = {1.000000f, 0.000000f, 1.000000f, 1.0f};
   [self chenMau:mau10 taiChiSo:10];
   float mau11[] = {1.000000f, 0.000000f, 0.500000f, 1.0f};
   [self chenMau:mau11 taiChiSo:11];
   float mau12[] = {1.000000f, 0.000000f, 0.000000f, 1.0f};
   [self chenMau:mau12 taiChiSo:12];
}

- (void)datCauVong2; {  //  cầu vòng 2
   // ---- xóa hết màu
   soLuongMau = 0;
   float mau0[] = {0.000000f, 0.000000f, 0.000000f, 1.0f};
   [self chenMau:mau0 taiChiSo:0];
   float mau1[] = {1.000000f, 0.000000f, 0.200000f, 1.0f};
   [self chenMau:mau1 taiChiSo:1];
   float mau2[] = {1.000000f, 0.500000f, 0.000000f, 1.0f};
   [self chenMau:mau2 taiChiSo:2];
   float mau3[] = {1.000000f, 1.000000f, 0.000000f, 1.0f};
   [self chenMau:mau3 taiChiSo:3];
   float mau4[] = {0.500000f, 1.000000f, 0.000000f, 1.0f};
   [self chenMau:mau4 taiChiSo:4];
   float mau5[] = {0.000000f, 1.000000f, 0.000000f, 1.0f};
   [self chenMau:mau5 taiChiSo:5];
   float mau6[] = {0.000000f, 1.000000f, 0.500000f, 1.0f};
   [self chenMau:mau6 taiChiSo:6];
   float mau7[] = {0.000000f, 1.000000f, 1.000000f, 1.0f};
   [self chenMau:mau7 taiChiSo:7];
   float mau8[] = {0.000000f, 0.500000f, 1.000000f, 1.0f};
   [self chenMau:mau8 taiChiSo:8];
   float mau9[] = {0.000000f, 0.000000f, 1.000000f, 1.0f};
   [self chenMau:mau9 taiChiSo:9];
   float mau10[] = {0.500000f, 0.000000f, 0.700000f, 1.0f};
   [self chenMau:mau10 taiChiSo:10];
   float mau11[] = {0.000000f, 0.000000f, 0.000000f, 1.0f};
   [self chenMau:mau11 taiChiSo:11];
}


- (void)datVatDen; {  // vật đen
   // ---- xóa hết màu
   soLuongMau = 0;
   
   float mau0[] = {0.000000f, 0.000000f, 0.000000f, 1.0f};
   [self chenMau:mau0 taiChiSo:0];
   float mau1[] = {0.980000f, 0.150000f, 0.000000f, 1.0f};
   [self chenMau:mau1 taiChiSo:1];
   float mau2[] = {1.000000f, 0.650000f, 0.000000f, 1.0f};
   [self chenMau:mau2 taiChiSo:2];
   float mau3[] = {1.000000f, 1.000000f, 1.000000f, 1.0f};
   [self chenMau:mau3 taiChiSo:3];
   float mau4[] = {0.800000f, 0.850000f, 1.000000f, 1.0f};
   [self chenMau:mau4 taiChiSo:4];
   float mau5[] = {0.300000f, 0.050000f, 0.000000f, 1.0f};
   [self chenMau:mau5 taiChiSo:5];
}

- (void)datTuyet; {  // vật tuyết
   // ---- xóa hết màu
   soLuongMau = 0;
   
   float mau0[] = {1.000000f, 1.000000f, 1.000000f, 1.0f};
   [self chenMau:mau0 taiChiSo:0];
   float mau1[] = {0.748720f, 0.773096f, 0.834034f, 1.0f};
   [self chenMau:mau1 taiChiSo:1];
   float mau2[] = {1.000000f, 1.000000f, 1.000000f, 1.0f};
   [self chenMau:mau2 taiChiSo:2];
   float mau3[] = {0.846222f, 0.800000f, 0.921785f, 1.0f};
   [self chenMau:mau3 taiChiSo:3];
   float mau4[] = {0.855972f, 0.804784f, 0.921785f, 1.0f};
   [self chenMau:mau4 taiChiSo:4];
   float mau5[] = {0.400000f, 0.400000f, 0.400000f, 1.0f};
   [self chenMau:mau5 taiChiSo:5];
   float mau6[] = {1.000000f, 1.000000f, 1.000000f, 1.0f};
   [self chenMau:mau6 taiChiSo:6];
}

- (void)datPhimXua; {  // vật phim xưa
   // ---- xóa hết màu
   soLuongMau = 0;
   
   float mau0[] = {0.200000f, 0.200000f, 0.200000f, 1.0f};
   [self chenMau:mau0 taiChiSo:0];
   float mau1[] = {0.300000f, 0.300000f, 0.300000f, 1.0f};
   [self chenMau:mau1 taiChiSo:1];
   float mau2[] = {0.500000f, 0.500000f, 0.500000f, 1.0f};
   [self chenMau:mau2 taiChiSo:2];
   float mau3[] = {0.950000f, 0.950000f, 0.950000f, 1.0f};
   [self chenMau:mau3 taiChiSo:3];
   float mau4[] = {0.800000f, 0.800000f, 0.800000f, 1.0f};
   [self chenMau:mau4 taiChiSo:4];
   float mau5[] = {0.400000f, 0.400000f, 0.400000f, 1.0f};
   [self chenMau:mau5 taiChiSo:5];
   float mau6[] = {0.800000f, 0.800000f, 0.800000f, 1.0f};
   [self chenMau:mau6 taiChiSo:6];
   float mau7[] = {0.250000f, 0.250000f, 0.250000f, 1.0f};
   [self chenMau:mau7 taiChiSo:7];
   float mau8[] = {0.200000f, 0.200000f, 0.200000f, 1.0f};
   [self chenMau:mau8 taiChiSo:8];
}


- (void)datKimLoai; {  // vật kim loại
   // ---- xóa hết màu
   soLuongMau = 0;
   
   float mau0[] = {0.965661f, 0.958349f, 0.800000f, 1.0f};
   [self chenMau:mau0 taiChiSo:0];
   float mau1[] = {0.963224f, 0.760908f, 0.0003961f, 1.0f};
   [self chenMau:mau1 taiChiSo:1];
   float mau2[] = {0.495216f, 0.331901f, 0.0003961f, 1.0f};
   [self chenMau:mau2 taiChiSo:2];
   float mau3[] = {1.000000f, 1.000000f, 1.000000f, 1.0f};
   [self chenMau:mau3 taiChiSo:3];
   float mau4[] = {0.894973f, 0.617093f, 0.483029f, 1.0f};
   [self chenMau:mau4 taiChiSo:4];
   float mau5[] = {0.548842f, 0.353839f, 0.224650f, 1.0f};
   [self chenMau:mau5 taiChiSo:5];
   float mau6[] = {1.000000f, 1.000000f, 1.000000f, 1.0f};
   [self chenMau:mau6 taiChiSo:6];
   float mau7[] = {0.800000f, 0.800000f, 0.843784f, 1.0f};
   [self chenMau:mau7 taiChiSo:7];
   float mau8[] = {0.370902f, 0.366027f, 0.456216f, 1.0f};
   [self chenMau:mau8 taiChiSo:8];
   float mau9[] = {0.965661f, 0.958349f, 0.800000f, 1.0f};
   [self chenMau:mau9 taiChiSo:9];
}

- (void)datRauCau; {  // vật rau câu
   // ---- xóa hết màu
   soLuongMau = 0;
   
   float mau0[] = {0.868160f, 0.819409f, 0.741408f, 1.0f};
   [self chenMau:mau0 taiChiSo:0];
   float mau1[] = {0.500000f, 0.353839f, 0.231962f, 1.0f};
   [self chenMau:mau1 taiChiSo:1];
   float mau2[] = {1.000000f, 1.000000f, 1.000000f, 1.0f};
   [self chenMau:mau2 taiChiSo:2];
   float mau3[] = {0.800000f, 0.631718f, 0.663406f, 1.0f};
   [self chenMau:mau3 taiChiSo:3];
   float mau4[] = {0.800000f, 0.283151f, 0.663406f, 1.0f};
   [self chenMau:mau4 taiChiSo:4];
   float mau5[] = {0.982724f, 0.885222f, 0.938848f, 1.0f};
   [self chenMau:mau5 taiChiSo:5];
   float mau6[] = {0.721907f, 0.585405f, 0.877910f, 1.0f};
   [self chenMau:mau6 taiChiSo:6];
   float mau7[] = {0.721907f, 0.205149f, 0.877910f, 1.0f};
   [self chenMau:mau7 taiChiSo:7];
   float mau8[] = {0.921785f, 0.899848f, 0.968099f, 1.0f};
   [self chenMau:mau8 taiChiSo:8];
   float mau9[] = {0.502529f, 0.795034f, 0.405027f, 1.0f};
   [self chenMau:mau9 taiChiSo:9];
   float mau10[] = {0.319714f, 0.607343f, 0.261213f, 1.0f};
   [self chenMau:mau10 taiChiSo:10];
   float mau11[] = {0.868160f, 0.819409f, 0.741408f, 1.0f};
   [self chenMau:mau11 taiChiSo:11];
}

- (void)datNeon; {  // neon
   // ---- xóa hết màu
   soLuongMau = 0;
   
   float mau0[] = {0.000000f, 0.000000f, 0.000000f, 1.0f};
   [self chenMau:mau0 taiChiSo:0];
   float mau1[] = {0.000000f, 0.000000f, 0.000000f, 1.0f};
   [self chenMau:mau1 taiChiSo:1];
   float mau2[] = {1.000000f, 0.000000f, 0.000000f, 1.0f};
   [self chenMau:mau2 taiChiSo:2];
   float mau3[] = {0.000000f, 0.000000f, 0.000000f, 1.0f};
   [self chenMau:mau3 taiChiSo:3];
   float mau4[] = {0.000000f, 0.000000f, 0.000000f, 1.0f};
   [self chenMau:mau4 taiChiSo:4];
   float mau5[] = {0.700000f, 0.000000f, 0.700000f, 1.0f};
   [self chenMau:mau5 taiChiSo:5];
   float mau6[] = {0.000000f, 0.000000f, 0.000000f, 1.0f};
   [self chenMau:mau6 taiChiSo:6];
   float mau7[] = {0.000000f, 0.000000f, 0.000000f, 1.0f};
   [self chenMau:mau7 taiChiSo:7];
   float mau8[] = {0.000000f, 0.300000f, 1.000000f, 1.0f};
   [self chenMau:mau8 taiChiSo:8];
   float mau9[] = {0.000000f, 0.000000f, 0.000000f, 1.0f};
   [self chenMau:mau9 taiChiSo:9];
   float mau10[] = {0.000000f, 0.000000f, 0.000000f, 1.0f};
   [self chenMau:mau10 taiChiSo:10];
   float mau11[] = {1.00000f, 0.400000f, 0.200000f, 1.0f};
   [self chenMau:mau11 taiChiSo:11];
   float mau12[] = {0.000000f, 0.000000f, 0.000000f, 1.0f};
   [self chenMau:mau12 taiChiSo:12];
}

- (void)datKeoBong; {  // kẹo bông
   // ---- xóa hết màu
   soLuongMau = 0;
   
   float mau0[] = {0.800000f, 0.920000f, 1.000000f, 1.0f};
   [self chenMau:mau0 taiChiSo:0];
   float mau1[] = {1.000000f, 0.600000f, 0.750000f, 1.0f};
   [self chenMau:mau1 taiChiSo:1];
   float mau2[] = {1.000000f, 1.000000f, 1.000000f, 1.0f};
   [self chenMau:mau2 taiChiSo:2];
   float mau3[] = {0.700000f, 1.00000f, 0.650000f, 1.0f};
   [self chenMau:mau3 taiChiSo:3];
   float mau4[] = {0.800000f, 0.920000f, 1.000000f, 1.0f};
   [self chenMau:mau4 taiChiSo:4];
}

- (void)datHoangGia; {  // kẹo bông
   // ---- xóa hết màu
   soLuongMau = 0;
   
   float mau0[] = {1.000000f, 0.920000f, 0.000000f, 1.0f};
   [self chenMau:mau0 taiChiSo:0];
   float mau1[] = {0.650000f, 0.450000f, 0.000000f, 1.0f};
   [self chenMau:mau1 taiChiSo:1];
   float mau2[] = {0.900000f, 0.000000f, 0.250000f, 1.0f};
   [self chenMau:mau2 taiChiSo:2];
   float mau3[] = {0.150000f, 0.000000f, 0.050000f, 1.0f};
   [self chenMau:mau3 taiChiSo:3];
   float mau4[] = {0.200000f, 0.000000f, 0.350000f, 1.0f};
   [self chenMau:mau4 taiChiSo:4];
   float mau5[] = {0.400000f, 0.000000f, 0.450000f, 1.0f};
   [self chenMau:mau5 taiChiSo:5];
   float mau6[] = {0.000000f, 0.000000f, 0.000000f, 1.0f};
   [self chenMau:mau6 taiChiSo:6];
   float mau7[] = {0.000000f, 0.000000f, 0.700000f, 1.0f};
   [self chenMau:mau7 taiChiSo:7];
   float mau8[] = {0.000000f, 0.400000f, 1.000000f, 1.0f};
   [self chenMau:mau8 taiChiSo:8];
   float mau9[] = {0.000000f, 0.600000f, 0.500000f, 1.0f};
   [self chenMau:mau9 taiChiSo:9];
   float mau10[] = {1.000000f, 0.920000f, 0.000000f, 1.0f};
   [self chenMau:mau10 taiChiSo:10];
}

- (void)datSilic; {
   // ---- xóa hết màu
   soLuongMau = 0;
   
   float mau0[] = {1.000000f, 1.000000f, 1.000000f, 1.0f};
   [self chenMau:mau0 taiChiSo:0];
   float mau1[] = {0.000000f, 0.000000f, 0.000000f, 1.0f};
   [self chenMau:mau1 taiChiSo:1];
   float mau2[] = {0.341000f, 0.314000f, 0.098000f, 1.0f};
   [self chenMau:mau2 taiChiSo:2];
   float mau3[] = {0.992000f, 1.000000f, 0.992000f, 1.0f};
   [self chenMau:mau3 taiChiSo:3];
   float mau4[] = {0.094100f, 0.176000f, 0.325000f, 1.0f};
   [self chenMau:mau4 taiChiSo:4];
   float mau5[] = {0.012000f, 0.000000f, 0.027000f, 1.0f};
   [self chenMau:mau5 taiChiSo:5];
   float mau6[] = {0.420000f, 0.235000f, 0.059000f, 1.0f};
   [self chenMau:mau6 taiChiSo:6];
   float mau7[] = {0.984000f, 0.988000f, 0.914000f, 1.0f};
   [self chenMau:mau7 taiChiSo:7];
   float mau8[] = {0.031000f, 0.298000f, 0.690000f, 1.0f};
   [self chenMau:mau8 taiChiSo:8];
   float mau9[] = {0.020000f, 0.035000f, 0.215000f, 1.0f};
   [self chenMau:mau9 taiChiSo:9];
   float mau10[] = {0.502000f, 0.184000f, 0.016000f, 1.0f};
   [self chenMau:mau10 taiChiSo:10];
   float mau11[] = {0.969000f, 0.957000f, 0.678000f, 1.0f};
   [self chenMau:mau11 taiChiSo:11];
   float mau12[] = {0.039000f, 0.541000f, 0.992000f, 1.0f};
   [self chenMau:mau12 taiChiSo:12];
   float mau13[] = {0.094000f, 0.059000f, 0.380000f, 1.0f};
   [self chenMau:mau13 taiChiSo:13];
   float mau14[] = {0.627000f, 0.157000f, 0.008000f, 1.0f};
   [self chenMau:mau14 taiChiSo:14];
   float mau15[] = {0.886000f, 0.914000f, 0.471000f, 1.0f};
   [self chenMau:mau15 taiChiSo:15];
   float mau16[] = {0.055000f, 0.675000f, 0.976000f, 1.0f};
   [self chenMau:mau16 taiChiSo:16];
   float mau17[] = {0.137000f, 0.078000f, 0.627000f, 1.0f};
   [self chenMau:mau17 taiChiSo:17];
   float mau18[] = {0.757000f, 0.114000f, 0.125000f, 1.0f};
   [self chenMau:mau18 taiChiSo:18];
   float mau19[] = {0.800000f, 0.914000f, 0.270000f, 1.0f};
   [self chenMau:mau19 taiChiSo:19];
   float mau20[] = {0.129000f, 0.824000f, 0.878000f, 1.0f};
   [self chenMau:mau20 taiChiSo:20];
   float mau21[] = {0.176000f, 0.0980000f, 0.7060000f, 1.0f};
   [self chenMau:mau21 taiChiSo:21];
   float mau22[] = {0.831000f, 0.106000f, 0.275000f, 1.0f};
   [self chenMau:mau22 taiChiSo:22];
   float mau23[] = {0.863000f, 0.8350000f, 0.172000f, 1.0f};
   [self chenMau:mau23 taiChiSo:23];
   float mau24[] = {0.216000f, 0.937000f, 0.490000f, 1.0f};
   [self chenMau:mau24 taiChiSo:24];
}

- (void)datQuan; {  // kẹo quần
   // ---- xóa hết màu
   soLuongMau = 0;
   
   float mau0[] = {0.851000f, 0.800000f, 0.620000f, 1.0f};
   [self chenMau:mau0 taiChiSo:0];
   float mau1[] = {0.400000f, 0.149000f, 0.145000f, 1.0f};
   [self chenMau:mau1 taiChiSo:1];
   float mau2[] = {0.400000f, 0.000000f, 0.439000f, 1.0f};
   [self chenMau:mau2 taiChiSo:2];
   float mau3[] = {1.000000f, 0.482000f, 0.000000f, 1.0f};
   [self chenMau:mau3 taiChiSo:3];
   float mau4[] = {0.851000f, 0.800000f, 0.620000f, 1.0f};
   [self chenMau:mau4 taiChiSo:4];
}


#pragma mark ---- Thay Danh Sách Màu
- (void)thayDanhSachMau:(float *)danhSachMauMoi soLuongMau:(unsigned char)soLuongMauMoi; {
   
   if( soLuongMauMoi > 1 ) {
      soLuongMau = 0;
      while( soLuongMau < soLuongMauMoi ) {
         unsigned int diaChiMau = soLuongMau << 2;
         danhSachMau[diaChiMau] = danhSachMauMoi[diaChiMau];
         danhSachMau[diaChiMau+1] = danhSachMauMoi[diaChiMau+1];
         danhSachMau[diaChiMau+2] = danhSachMauMoi[diaChiMau+2];
         danhSachMau[diaChiMau+3] = danhSachMauMoi[diaChiMau+3];
         soLuongMau++;
      }
   }
   
   // ---- nâng cấp cách giữa màu
   cachGiuaMau = 1.0f/(soLuongMau - 1);
}

#pragma mark ---- Biến
@synthesize danhSachMau;

- (float *)mauTapHop; {
   return mauTap;
}

@synthesize soLuongMau;
@synthesize chuTrinhMau;
@synthesize mu;
@synthesize dich;
@synthesize soLapLaiToiDa;

#pragma mark ---- Thả
- (void)dealloc; {
   if( danhSachMau )
      free( danhSachMau );
}

@end
