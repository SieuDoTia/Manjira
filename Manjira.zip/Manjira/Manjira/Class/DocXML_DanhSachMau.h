//
//  DocXML_DanhSachMau.h
//  Manjira
//
//  Created by 小小 on 16/2/2560.
//

#import <Foundation/Foundation.h>
@class ToMau;


@interface DocXML_DanhSachMau : NSObject <NSXMLParserDelegate> {
   
   NSXMLParser *modelParser;
   
   unsigned char soLuongMau;   // số lượng màu
   float danhSachMau[4*256];   // danh sách màu
   float mauTapHop[4];         // màu tập hợp
   float cachGiuaMau[255];     // cách giữa mảu - CHƯA XÀI
   
   BOOL saiLam;                // sai lầm
}

- (unsigned char)docVoiURL:(NSURL *)URL_tapTin;

// ---- của NSXMLParser, phải dùng các tên này
- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI
 qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict;

- (void)parser:(NSXMLParser *)parser parseErrorOccurred:(NSError *)parseError;

@property (readonly) unsigned char soLuongMau;
- (float *)danhSachMau;
- (float *)mauTapHop;

@property (readonly) BOOL saiLam;

@end
