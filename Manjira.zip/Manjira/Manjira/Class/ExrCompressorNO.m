//
//  ExCompressorNO.m
//  Test13
//
//  Created by 小小 on 27/6/2555.
//  Copyright (c) 2555 BE __MyCompanyName__. All rights reserved.
//

#import "ExrCompressorNO.h"
#import "ExrBangThanhPhan.h"
#import "ExrKenh.h"
#import "ImfConstants.h"

@implementation ExrCompressorNO


#pragma mark ---- Lưu
//                       kênh        kênh         kênh
// một hàng +----------+-----------+----------+ .....
// một hàng +----------+-----------+----------+ .....
+ (void)luuDuLieuAnh:(NSMutableData *)duLieuAnh voiBangThanhPhanHang:(ExrBangThanhPhan *)bangThanhPhan vaMangKenh:(NSMutableArray *)mangKenh rong:(unsigned int)rong cao:(unsigned int)cao soHangDau:(unsigned int)soHangDau; {
   
   // ---- tính bề vài cho mỗi kênh trong một hàng, bề dài của một điểm ảnh, địa chỉ cho kênh trong hàng
   // hàng chẵn  +-- kênh 0, nhịp 1 --+-- kênh 1, nhịp 2 --+------ kênh 2, nhịp 1 ------+  v.v.
   // hàng lẹ    +-- kênh 0, nhịp 1 --+------ kênh 2 nhịp 1 ------+  v.v.
   
   // ---- kênh chẵn/lẹ không giống nếu nhịp ≠ 1
   unsigned int beDaiMotHangChan = 0;
   unsigned int beDaiMotHangLe = 0;
   unsigned short soKenh = 0;
   unsigned short soLuongKenh = [mangKenh count];

   unsigned int *beDaiKenhTrongThanhPhan = malloc( sizeof( unsigned int )*soLuongKenh);

   while( soKenh < soLuongKenh) {
      ExrKenh *kenh = [mangKenh objectAtIndex:soKenh];
      unsigned char nhip = [kenh nhipX];

      unsigned int beDaiKieuDuLieu = [kenh beDaiKieuDuLieu];
   
      beDaiKenhTrongThanhPhan[soKenh] = beDaiKieuDuLieu*rong/nhip;
      
      if( nhip == 1 ) {
         beDaiMotHangChan += beDaiKenhTrongThanhPhan[soKenh];
         beDaiMotHangLe += beDaiKenhTrongThanhPhan[soKenh];
      }
      else
         beDaiMotHangChan += beDaiKenhTrongThanhPhan[soKenh];

//      NSLog( @"ExrNO: %d dai %d daiK %d", soKenh, beDaiKieuDuLieu, beDaiKenhTrongThanhPhan[soKenh] );
      soKenh++;
   }

   // ==== BẢNG THÀNH PHẦN, một thành phần cho mỗi hàng

   // ---- tính địa chỉ cho thành phần đầu tiên (sau bảng địa chỉ thành phần)
   // số lượng thàng phần = bề cao ảnh, mỗi số trong bảng thành phần là unsigned long (8 byte)
   unsigned long diaChiChoThanhPhan = (cao << 3) + [duLieuAnh length];  // một thành phần cho mỗi hàng
   
   unsigned int soHang = 0;
   while( soHang < cao ) {
      // ---- dữ liệu hàng này bắt đầu tại đây
      [duLieuAnh appendBytes:&diaChiChoThanhPhan length:8];
      
      // ---- cho hàng tiếp sau hàng này
      if( soHang & 0x01 )
         diaChiChoThanhPhan += beDaiMotHangLe + 8;
      else 
         diaChiChoThanhPhan += beDaiMotHangChan + 8;

      soHang++;
   }

   // ==== GOM THẢNH PHẦN
   // ---- đệm dữ liệu cho một thành phần
   unsigned char *demDuLieuChoMotHang = malloc( beDaiMotHangChan );  // bề dài hàng chẵn ≥ bề dài hàng chẵn lẹ

   soHang = 0;

   while( soHang < cao ) {

      // ---- số hàng
      [duLieuAnh appendBytes:&soHangDau length:4];
      // ---- bề dài hàng
      if( soHang & 0x01 )
         [duLieuAnh appendBytes:&beDaiMotHangLe length:4];
      else
         [duLieuAnh appendBytes:&beDaiMotHangChan length:4];

      // ---- gom dữ liệu cho mỗi kênh
      soKenh = 0;
      // ---- địa chỉ trong đệm cho thành phần đang gom; ặt lại = 0 khi bắt đầu gom thành phần mới
      unsigned int diaChiTrongDemThanhPhan = 0;
   
      while ( soKenh < soLuongKenh ) {

         ExrKenh *kenh = [mangKenh objectAtIndex:soKenh];
         // ---- rút dữ liệu từ kênh ảnh và bỏ vào dòng dữ liệu
         if( [kenh nhipX] == 1 ) {

            [kenh rutDuLieu:&(demDuLieuChoMotHang[diaChiTrongDemThanhPhan]) beDaiDem:beDaiKenhTrongThanhPhan[soKenh] tuCot:0 hang:soHang];
            diaChiTrongDemThanhPhan += beDaiKenhTrongThanhPhan[soKenh];
         }
         else if( !(soHang & 0x01) ) {   // nếu nhịp = 2 chỉ hàng chẵn có dữ liệu
            [kenh rutDuLieu:&(demDuLieuChoMotHang[diaChiTrongDemThanhPhan]) beDaiDem:beDaiKenhTrongThanhPhan[soKenh] tuCot:0 hang:soHang];
            diaChiTrongDemThanhPhan += beDaiKenhTrongThanhPhan[soKenh];
         }

         soKenh++;
      }

      // ---- lưu giữ liệu
      [duLieuAnh appendBytes:demDuLieuChoMotHang length:diaChiTrongDemThanhPhan];

      soHang++;
      soHangDau++;
   }
   
   // ---- thả trí nhớ
   free( demDuLieuChoMotHang );
   free( beDaiKenhTrongThanhPhan );
}


// ------------------------------------ Ô CHỮ NHẬT -------------------------------------
//                       kênh        kênh         kênh
// một hàng ô chữ nhật +----------+-----------+----------+ .....
// một hàng ô chữ nhật +----------+-----------+----------+ .....
+ (void)luuDuLieuAnh:(NSMutableData *)duLieuAnh voiBangThanhPhanGach:(ExrBangThanhPhan *)bangThanhPhan
          vaMangKenh:(NSMutableArray *)mangKenh rongAnh:(unsigned int)rongAnh caoAnh:(unsigned int)caoAnh
            rongGach:(unsigned int)rongGach caoGach:(unsigned int)caoGach; {

   // ---- tính bề vài cho mỗi kênh trong một hàng gạch, bề dài của một điểm ảnh, địa chỉ cho kênh trong hàng gạch
   unsigned int beDaiMotDiemAnh = 0;
   unsigned short soKenh = 0;
   unsigned short soLuongKenh = [mangKenh count];
   unsigned int diaChiKenhTrongDiemAnh[256];
   unsigned int beDaiDuLieuTrongDiemAnh[256];
   
   while( soKenh < soLuongKenh) {
      ExrKenh *kenh = [mangKenh objectAtIndex:soKenh];
      unsigned int beDaiKieuDuLieu = [kenh beDaiKieuDuLieu];

      if( soKenh == 0 )
         diaChiKenhTrongDiemAnh[0] = 0;
      else
         diaChiKenhTrongDiemAnh[soKenh] = beDaiDuLieuTrongDiemAnh[soKenh-1] + diaChiKenhTrongDiemAnh[soKenh-1];  // dùng bề dài dữ liệu từ điểm ảnh trước
      
      beDaiMotDiemAnh += beDaiKieuDuLieu;
      beDaiDuLieuTrongDiemAnh[soKenh] = beDaiKieuDuLieu;
      //      NSLog( @"ExrNO: %d dai %d, dC %d daiK %d", soKenh, beDaiKieuDuLieu, diaChiKenhTrongDem[soKenh], beDaiDuLieuTuCacKenh[soKenh] );
      soKenh++;
   }
   
   // ==== làm được bàng thành phần, một thành phần cho mỗi hàng
   // ---- tính bề dài của một hàng (byte)
//   unsigned long beDaiMotHang = beDaiMotDiemAnh*rongGach;
   
   // ---- tính số lượng gạch
   unsigned int soLuongGachX = rongAnh/rongGach;
   if( rongAnh % rongGach )
      soLuongGachX++;
   
   unsigned int soLuongGachY = caoAnh/caoGach;
   if( caoAnh % caoGach )
      soLuongGachY++;
   
   // ---- tính số lượng gạch
   unsigned soLuongGach = soLuongGachX*soLuongGachY;

   // ---- tính địa chỉ cho thành phần đầu tiên (sau bảng địa chỉ thành phần)
   unsigned long diaChiChoBang = (soLuongGach << 3) + [duLieuAnh length];  // một phần tử cho mỗi hàng

   unsigned int soCotGach = 0;
   unsigned int soHangGach = 0;
   unsigned int soGach = 0;

   while( soGach < soLuongGach ) {
      [duLieuAnh appendBytes:&diaChiChoBang length:8];
      unsigned short soLuongCotGach = rongGach;
      unsigned short soLuongHangGach = caoGach;
      unsigned int viTriGachX = soCotGach*rongGach;
      unsigned int viTriGachY = soHangGach*caoGach;
      
      if( rongAnh - viTriGachX < soLuongCotGach )
         soLuongCotGach = rongAnh - viTriGachX;
      
      if( caoAnh - viTriGachY < soLuongHangGach )
         soLuongHangGach = caoAnh - viTriGachY;

      diaChiChoBang += beDaiMotDiemAnh*soLuongCotGach*soLuongHangGach + 20;
   
      // ---- nếu số lượng cột cho gạch này không bằng rộng gạch bình thường nghĩa là gạch cuối của hàng này
      soCotGach++;
      if( soCotGach == soLuongGachX ) {
         soCotGach = 0;
         soHangGach++;
      }
      soGach++;
   }

   unsigned char *demDuLieuTuCacKenh = malloc( rongGach*caoGach*beDaiMotDiemAnh );

   soCotGach = 0;
   soHangGach = 0;
   soGach = 0;

   while( soGach < soLuongGach ) {
      // ---- vị trí gạch x
      [duLieuAnh appendBytes:&soCotGach length:4];
      // ---- vị trí gạch y
      [duLieuAnh appendBytes:&soHangGach length:4];

//      NSLog( @"ExrNO: soGach %d (%d; %d)", soGach, soCotGach, soHangGach );
      // ---- sự rõ hướng x
      unsigned int suRo = 0;   // hai hướng bằng 0
      [duLieuAnh appendBytes:&suRo length:4];
      // ---- sự rõ hướng y
      [duLieuAnh appendBytes:&suRo length:4];

      // ---- tính bề dài hàng cho gạch (gạch ở phía phải có thể nhỏ hơn rongGach)
      unsigned short soLuongCotGach = rongGach;
      unsigned short soLuongHangGach = caoGach;
      unsigned int viTriGachX = soCotGach*rongGach;
      unsigned int viTriGachY = soHangGach*caoGach;
      
      if( rongAnh - viTriGachX < soLuongCotGach )
         soLuongCotGach = rongAnh - viTriGachX;
      
      if( caoAnh - viTriGachY < soLuongHangGach )
         soLuongHangGach = caoAnh - viTriGachY;

      // ---- lưu bề dài dữ liệu
      unsigned int beDaiDuLieuGach = (unsigned int)soLuongCotGach*soLuongHangGach*beDaiMotDiemAnh;
      [duLieuAnh appendBytes:&beDaiDuLieuGach length:4];
      // ---- tính bề dài một hàng
      unsigned int beDaiMotHang = beDaiMotDiemAnh*soLuongCotGach;
      // ---- gồm dữ liệu cho hết hảng của gạch
      soKenh = 0;
      while ( soKenh < soLuongKenh ) {
         ExrKenh *kenh = [mangKenh objectAtIndex:soKenh];
         unsigned int diaChiKenhTrongDemKhongNen = soLuongCotGach*diaChiKenhTrongDiemAnh[soKenh];
         unsigned int beDaiDuLieuTuKenh = soLuongCotGach*[kenh beDaiKieuDuLieu];
         unsigned int soHang = 0;

         while( soHang < soLuongHangGach ) {
         // ---- rút dữ liệu từ một hàng một lược của kênh ảnh và bỏ vào đệm dữ liệu
            [kenh rutDuLieu:&(demDuLieuTuCacKenh[diaChiKenhTrongDemKhongNen + soHang*beDaiMotHang]) beDaiDem:beDaiDuLieuTuKenh tuCot:soCotGach*rongGach hang:soHangGach*caoGach + soHang];

            soHang++;
         }

         soKenh++;
      }

/*      unsigned int hang = 0;
      while ( hang < soLuongHangGach ) {
         unsigned int cot = 0;
         while ( cot < beDaiMotHang ) {
            if( !(cot % 4) )
               printf( " ");
            printf( "%02x", demDuLieuTuCacKenh[cot + beDaiMotHang*hang] );

            cot++;
         }
         printf( "\n" );
         hang++;
      }*/

      // ---- lưu giữ liệu
      [duLieuAnh appendBytes:demDuLieuTuCacKenh length:beDaiDuLieuGach];

      // ---- nếu số lượng cột cho gạch này không bằng rộng gạch bình thường nghĩa là gạch cuối của hàng này
      soCotGach++;
      if( soCotGach == soLuongGachX ) {
         soCotGach = 0;
         soHangGach++;
      }
      
      soGach++;
   }
   
   // ---- thả trí nhớ
//   free( diaChiKenhTrongDiemAnh );
   free( demDuLieuTuCacKenh );
//   free( beDaiDuLieuTrongDiemAnh );
}

#pragma mark ---- Đọc
//                       kênh        kênh         kênh
// một hàng ô chữ nhật +----------+-----------+----------+ .....
// một hàng ô chữ nhật +----------+-----------+----------+ .....
+ (void)docDuLieuAnh:(NSData *)duLieuAnh voiBangThanhPhan:(ExrBangThanhPhan *)thongTinBangThanhPhan
          vaMangKenh:(NSMutableArray *)mangKenh rong:(unsigned int)rong cao:(unsigned int)cao; {

   // ---- mảng số hàng cho những thành phần
//   int *mangSoHangThanhPhan = [thongTinBangThanhPhan mangSoHangThanhPhan];
   // ---- danh sách địa chỉ thành phần trong tập tin
   unsigned long *mangDiaChiDuLieuThanhPhan = [thongTinBangThanhPhan mangDiaChiDuLieuThanhPhan];
   // ---- mảng bề dài dư liệu thành phần
   unsigned int *mangBeDaiThanhPhan = [thongTinBangThanhPhan mangBeDaiThanhPhan];
   // ---- số lượng thành phần
   unsigned int soLuongThanhPhan = [thongTinBangThanhPhan baoNhieuThanhPhan];
   // ---- thành phần lớn nhất cho làm đệm giữ nó
   unsigned int thanhPhanLonNhat = [thongTinBangThanhPhan thanhPhanLonNhat];
   // ---- đệm thành phần
   unsigned char *demThanhPhan = malloc( thanhPhanLonNhat );

   // ---- thông tin kênh
   unsigned short soLuongKenh = (unsigned short)[mangKenh count];
   unsigned int *beDaiKenhTrongMotHang = malloc( soLuongKenh * sizeof( unsigned int ) );

   unsigned char soKenh = 0; // chỉ số kênh

   while( soKenh < soLuongKenh ) {
      // ---- tính bề dài của kênh trong mỗi hàng không nén
      ExrKenh *kenh = [mangKenh objectAtIndex:soKenh];
      unsigned char nhip = [kenh nhipX];

      beDaiKenhTrongMotHang[soKenh] = [kenh beDaiKieuDuLieu]*rong/nhip;
      soKenh++;
   }

   unsigned int soThanhPhan = 0;

   while( soThanhPhan < soLuongThanhPhan ) {
      // ---- đọc thành phần
      NSRange range;  // vaCham
      range.location = mangDiaChiDuLieuThanhPhan[soThanhPhan];
      range.length = mangBeDaiThanhPhan[soThanhPhan];
      [duLieuAnh getBytes:demThanhPhan range:range];

      unsigned int diaChiKenhTrongThanhPhan = 0;
      
      // --- giữ dư liệu cho mỗi kệnh
      unsigned char soKenh = 0;
      while( soKenh < soLuongKenh ) {
         ExrKenh *kenh = [mangKenh objectAtIndex:soKenh];

         // ---- chép dữ liệu trong kênh
         if( [kenh nhipX] == 1 ) {
            [kenh boDuLieu:&(demThanhPhan[diaChiKenhTrongThanhPhan])
                  beDaiDem:beDaiKenhTrongMotHang[soKenh] taiCot:0 hang:soThanhPhan];
            diaChiKenhTrongThanhPhan += beDaiKenhTrongMotHang[soKenh];
         }
         else if( !(soThanhPhan & 0x01) ) {  // nếu nhịp = 2 chỉ hàng chẵn có dữ liệu
            [kenh boDuLieu:&(demThanhPhan[diaChiKenhTrongThanhPhan])
                  beDaiDem:beDaiKenhTrongMotHang[soKenh] taiCot:0 hang:soThanhPhan];
            diaChiKenhTrongThanhPhan += beDaiKenhTrongMotHang[soKenh];
         }

         soKenh++;
      }
      soThanhPhan++;
   }
/*
   ExrKenh *kenh = [mangKenh objectAtIndex:0];
   NSLog( @"%@", [kenh ten] );
   [kenh inDuLieuKenhVoiPrintf];

   kenh = [mangKenh objectAtIndex:1];
   NSLog( @"%@", [kenh ten] );
   [kenh inDuLieuKenhVoiPrintf];

   kenh = [mangKenh objectAtIndex:2];
   NSLog( @"%@", [kenh ten] );
   [kenh inDuLieuKenhVoiPrintf];

   kenh = [mangKenh objectAtIndex:3];
   NSLog( @"%@", [kenh ten] );
   [kenh inDuLieuKenhVoiPrintf]; */

   // ---- bỏ đệm
   free( demThanhPhan );
}

// --------------------------------- ĐIỂM ẢNH SÂU -------------------------------------
// cần nhịp x và nhịp y
/*
+ (void)docDuLieuDiemAnhSau:(NSData *)duLieuAnh voiBangThanhPhan:(ExrBangThanhPhan *)thongTinBangThanhPhan
          vaMangKenh:(NSMutableArray *)mangKenh rong:(unsigned int)rong cao:(unsigned int)cao; {
   
   // ---- mảng số hàng cho những thành phần
   int *mangSoHangThanhPhan = [thongTinBangThanhPhan mangSoHangThanhPhan];
   // ---- danh sách địa chỉ thành phần trong tập tin
   unsigned long *mangDiaChiDuLieuThanhPhan = [thongTinBangThanhPhan mangDiaChiDuLieuThanhPhan];
   // ---- mảng bề dài dư liệu thành phần
   unsigned int *mangBeDaiThanhPhan = [thongTinBangThanhPhan mangBeDaiThanhPhan];
   // ---- bao nhiều thành phần
   unsigned int baoNhieuThanhPhan = [thongTinBangThanhPhan baoNhieuThanhPhan];
   // ---- thành phần lớn nhất cho làm đệm giữ nó
   unsigned int thanhPhanLonNhat = [thongTinBangThanhPhan thanhPhanLonNhat];
   // ---- đệm thành phần
   unsigned char *demThanhPhan = malloc( thanhPhanLonNhat );
   
   // ---- thông tin kênh
   unsigned int beDaiKenhTrongMotHangKhongNen[EXR_GIOI_HAN_KENH];
   unsigned int diaChiKenhTrongMotHangKhongNen[EXR_GIOI_HAN_KENH];
   
   unsigned short baoNhieuKenh = [mangKenh count];
   unsigned char chiSoKenh = 0; // chỉ số kênh
   if( baoNhieuKenh > EXR_GIOI_HAN_KENH )
      baoNhieuKenh = EXR_GIOI_HAN_KENH;    // ---- chương trình này không cho hơn EXR_GIOI_HAN_KENH
   
   while( chiSoKenh < baoNhieuKenh ) {
      // ---- tính bề dài của kênh trong mỗi hàng không nén
      ExrKenh *kenh = [mangKenh objectAtIndex:chiSoKenh];
      
      beDaiKenhTrongMotHangKhongNen[chiSoKenh] = [kenh beDaiKieuDuLieu]*rong;
      
      // ---- địa chỉ của kênh trong một hàng
      if( chiSoKenh == 0 ) {
         diaChiKenhTrongMotHangKhongNen[chiSoKenh] = 0;
      }
      else {
         diaChiKenhTrongMotHangKhongNen[chiSoKenh] = diaChiKenhTrongMotHangKhongNen[chiSoKenh-1] + beDaiKenhTrongMotHangKhongNen[chiSoKenh-1];
      }
      
      chiSoKenh++;
   }
   
   
   unsigned int soThanhPhan = 0;  // cũng bằng số hàng
   
   while( soThanhPhan < baoNhieuThanhPhan ) {
      // ---- đọc thành phần
      NSRange range;  // vaCham
      range.location = mangDiaChiDuLieuThanhPhan[soThanhPhan];
      range.length = mangBeDaiThanhPhan[soThanhPhan];
      [duLieuAnh getBytes:demThanhPhan range:range];
      
      // --- giữ dư liệu cho mỗi kệnh
      unsigned char chiSoKenh = 0;
      while( chiSoKenh < baoNhieuKenh ) {
         ExrKenh *kenh = [mangKenh objectAtIndex:chiSoKenh];
         
         // ---- chép dữ liệu trong kênh
         [kenh boDuLieu:&(demThanhPhan[diaChiKenhTrongMotHangKhongNen[chiSoKenh]]) beDaiDem:beDaiKenhTrongMotHangKhongNen[chiSoKenh]
                 taiCot:0 hang:soThanhPhan];
         chiSoKenh++;
      }
      soThanhPhan++;
   }
   
   // ---- bỏ đệm
   free( demThanhPhan );
}
*/

// ------------------------------------ Ô CHỮ NHẬT -------------------------------------
//                       kênh        kênh         kênh
// một hàng ô chữ nhật +----------+-----------+----------+ .....
// một hàng ô chữ nhật +----------+-----------+----------+ .....

+ (void)docDuLieuAnh:(NSData *)duLieuAnh voiBangThanhPhanGach:(ExrBangThanhPhan *)thongTinBangThanhPhan
          vaMangKenh:(NSMutableArray *)mangKenh rongHinh:(unsigned int)rongHinh caoHinh:(unsigned int)caoHinh
            rongGach:(unsigned int)rongGach caoGach:(unsigned int)caoGach; {

   // ---- mảng số hàng cho những thành phần
//   int *mangSoHangThanhPhan = [thongTinBangThanhPhan mangSoHangThanhPhan];
   // ---- danh sách địa chỉ thành phần trong tập tin
   unsigned long *mangDiaChiDuLieuThanhPhan = [thongTinBangThanhPhan mangDiaChiDuLieuThanhPhan];
   // ---- mảng bề dài dư liệu thành phần
   unsigned int *mangBeDaiThanhPhan = [thongTinBangThanhPhan mangBeDaiThanhPhan];
   // ---- bao nhiều thành phần
   unsigned int baoNhieuThanhPhan = [thongTinBangThanhPhan baoNhieuThanhPhan];
   // ---- thành phần lớn nhất cho làm đệm giữ nó
   unsigned int thanhPhanLonNhat = [thongTinBangThanhPhan thanhPhanLonNhat];
   
   // ---- cho gạch
   unsigned int *mangSoGach = [thongTinBangThanhPhan mangSoGach];
//   unsigned int *mangSuRo = [thongTinBangThanhPhan mangSuRo];
   
   // ---- đệm thành phần
   unsigned char *demThanhPhan = malloc( thanhPhanLonNhat );
   
   // ---- thông tin kênh
   unsigned int beDaiKenhTrongMotDiemAnh[EXR_GIOI_HAN_KENH];
   unsigned int diaChiKenhTrongMotDiemAnh[EXR_GIOI_HAN_KENH];
   unsigned int beDaiMotDiemAnh = 0;

   unsigned short baoNhieuKenh = [mangKenh count];
   unsigned char chiSoKenh = 0; // chỉ số kênh
   if( baoNhieuKenh > EXR_GIOI_HAN_KENH )
      baoNhieuKenh = EXR_GIOI_HAN_KENH;    // ---- chương trình này không cho hơn 16 kênh
   
   while( chiSoKenh < baoNhieuKenh ) {
      // ---- tính bề dài của kênh trong mỗi hàng không nén
      ExrKenh *kenh = [mangKenh objectAtIndex:chiSoKenh];
      
      beDaiKenhTrongMotDiemAnh[chiSoKenh] = [kenh beDaiKieuDuLieu];
      beDaiMotDiemAnh += [kenh beDaiKieuDuLieu];

      // ---- địa chỉ của kênh trong một hàng
      if( chiSoKenh == 0 ) {
         diaChiKenhTrongMotDiemAnh[chiSoKenh] = 0;
      }
      else {
         diaChiKenhTrongMotDiemAnh[chiSoKenh] = diaChiKenhTrongMotDiemAnh[chiSoKenh-1] + beDaiKenhTrongMotDiemAnh[chiSoKenh];
      }
      
      chiSoKenh++;
   }
   
   
   unsigned int soThanhPhan = 0;  // cũng bằng số hàng
   
   while( soThanhPhan < baoNhieuThanhPhan ) {
      
      // ---- tính vị trí gạch
      unsigned int viTriGachX = rongGach*mangSoGach[soThanhPhan << 1];
      unsigned int viTriGachY = caoGach*mangSoGach[(soThanhPhan << 1)+1];
      
      // ---- đọc thành phần
      NSRange range;  // vaCham
      range.location = mangDiaChiDuLieuThanhPhan[soThanhPhan];
      range.length = mangBeDaiThanhPhan[soThanhPhan];
      [duLieuAnh getBytes:demThanhPhan range:range];

      // ---- xem nếu gạch ở phía dưới hình, gạch đó có lẻ không cao bằng gạch bình thường 
      unsigned int soHangCuoi = caoGach;
      if( caoHinh - viTriGachY < caoGach ) {
         soHangCuoi = caoHinh - viTriGachY;
      }
      
      // ---- xem nếu gạch ở phía phải, gạch đó có lẻ không cao bằng gạch bình thường
      unsigned int beRongGach = rongGach;
      if( rongHinh - viTriGachX < rongGach )
         beRongGach = rongHinh - viTriGachX;

      unsigned int beDaiMotHang = beDaiMotDiemAnh*beRongGach;
         
      // --- giữ dư liệu cho mỗi kệnh
      unsigned char chiSoKenh = 0;
      while( chiSoKenh < baoNhieuKenh ) {
         ExrKenh *kenh = [mangKenh objectAtIndex:chiSoKenh];

         // ---- tính địa chỉ và bề dài kenh tron đệm không nén
         unsigned int beDaiDuLieuKenhTrongDemKhongNen = beRongGach*beDaiKenhTrongMotDiemAnh[chiSoKenh];
         unsigned int diaChiKenhTrongDemKhongNen = beRongGach*diaChiKenhTrongMotDiemAnh[chiSoKenh];
         // ----
         unsigned int soHang = 0;
         while( soHang < soHangCuoi ) {
            // ---- chép dữ liệu trong kênh
            [kenh boDuLieu:&(demThanhPhan[diaChiKenhTrongDemKhongNen + soHang*beDaiMotHang]) beDaiDem:beDaiDuLieuKenhTrongDemKhongNen
                    taiCot:viTriGachX hang:viTriGachY+soHang];
            soHang++;
         }
         
         chiSoKenh++;
      }
      soThanhPhan++;
   }
   
   /*
    ExrKenh *kenh = [mangKenh objectAtIndex:0];
    NSLog( @"%@", [kenh ten] );
    [kenh inDuLieuKenhVoiPrintf];
    
    kenh = [mangKenh objectAtIndex:1];
    NSLog( @"%@", [kenh ten] );
    [kenh inDuLieuKenhVoiPrintf];
    
    kenh = [mangKenh objectAtIndex:2];
    NSLog( @"%@", [kenh ten] );
    [kenh inDuLieuKenhVoiPrintf];
    
    kenh = [mangKenh objectAtIndex:3];
    NSLog( @"%@", [kenh ten] );
    [kenh inDuLieuKenhVoiPrintf]; */

   // ---- bỏ đệm
   free( demThanhPhan );
}



@end
