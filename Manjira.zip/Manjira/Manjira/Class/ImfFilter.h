//
//  ImfFilter.h
//  Test13
//
//  Created by 小小 on 1/7/2555.
//

#import <Foundation/Foundation.h>

@interface ImfFilter : NSObject

+ (void)filterDataInBuffer:(unsigned char *)buffer withLength:(unsigned int)length
    andPutInFilteredBuffer:(unsigned char *)filteredBuffer;

/* không xài */
//+ (void)unfilterDataInBuffer:(unsigned char *)buffer withLength:(unsigned int)length
//    andPutInUnfilteredBuffer:(unsigned char *)unfilteredBuffer;

@end
