//
//  ManChonThuTapTin.m
//  Manjira
//
//  Created by 小小 on 20/12/2556.
//  Copyright (c) 2556 BE 星凤. All rights reserved.
//

#import "ManChonThuTapTin.h"

@implementation ManChonThuTapTin


- (id)initWithFrame:(NSRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code here.
    }
    
    return self;
}

- (void)awakeFromNib; {
   
}

- (void)drawRect:(NSRect)dirtyRect
{
    // Drawing code here.
}

- (IBAction)doiThuTapTin:(id)sender; {
   
   NSButtonCell *nutChon = [sender selectedCell];
   thuTapTin = (unsigned char)[nutChon tag];
}


@synthesize thuTapTin;

@end
