//
//  LuuEXR.m
//  Manjira
//
//  Created by 小小 on 18/12/2556.
//

#import "LuuEXR.h"
#import "ImfFilter.h"
#import "zlib.h"

@implementation LuuEXR

+ (void)luuEXRHalf_voiURL:(NSURL *)URL_tapTin beRong:(unsigned int)beRong beCao:(unsigned int)beCao
                 vaKenhDo:(unsigned char *)kenhDo kenhLuc:(unsigned char *)kenhLuc kenhXanh:(unsigned char *)kenhXanh
                  kenhDuc:(unsigned char *)kenhDuc; {

   // ---- ký hiệu tấp tin EXR
   unsigned int kyHieuTapTin = 0x01312f76;  // ngược cho intel;
   NSMutableData *dongDuLieu = [NSMutableData dataWithBytes:&kyHieuTapTin length:4];
   
   // ---- phiên bản 2 (chỉ phiên bản 2 được phát hành)
   unsigned int phienBan = 0x02;
   [dongDuLieu appendBytes:&phienBan length:4];

   // ---- bốn kênh A B G R kiểu  half
   unsigned char tuaKenh[20];
   tuaKenh[0] = 'c';
   tuaKenh[1] = 'h';
   tuaKenh[2] = 'a';
   tuaKenh[3] = 'n';
   tuaKenh[4] = 'n';
   tuaKenh[5] = 'e';
   tuaKenh[6] = 'l';
   tuaKenh[7] = 's';
   tuaKenh[8] = 0x00;
   tuaKenh[9] = 'c';
   tuaKenh[10] = 'h';
   tuaKenh[11] = 'l';
   tuaKenh[12] = 'i';
   tuaKenh[13] = 's';
   tuaKenh[14] = 't';
   tuaKenh[15] = 0x00;
   tuaKenh[16] = 73;   // bề dài cho 4 kênh, tên các kênh dài một chữ cái ASCII
   tuaKenh[17] = 0x00;
   tuaKenh[18] = 0x00;
   tuaKenh[19] = 0x00;
   [dongDuLieu appendBytes:tuaKenh length:20];
   
   unsigned char kenh[18];
   kenh[0] = 'A';
   kenh[1] = 0x00;

   kenh[2] = 0x01;  // kiểu dữ liệu 0x01 nghỉa là half
   kenh[3] = 0x00;
   kenh[4] = 0x00;
   kenh[5] = 0x00;

   kenh[6] = 0x00;   // chỉ xài cho phương pháp nén B44, ở đây không xài
   kenh[7] = 0x00;
   kenh[8] = 0x00;
   kenh[9] = 0x00;

   kenh[10] = 0x01;  // nhịp x
   kenh[11] = 0x00;
   kenh[12] = 0x00;
   kenh[13] = 0x00;

   kenh[14] = 0x01;  // nhịp y
   kenh[15] = 0x00;
   kenh[16] = 0x00;
   kenh[17] = 0x00;
   [dongDuLieu appendBytes:kenh length:18];

   kenh[0] = 'B';
   [dongDuLieu appendBytes:kenh length:18];

   kenh[0] = 'G';
   [dongDuLieu appendBytes:kenh length:18];
   
   kenh[0] = 'R';
   [dongDuLieu appendBytes:kenh length:18];
   
   unsigned char ketTuc = 0x00;
   [dongDuLieu appendBytes:&ketTuc length:1];

   // ---- nén
   unsigned char nen[29];
   nen[0] = 'c';
   nen[1] = 'o';
   nen[2] = 'm';
   nen[3] = 'p';
   nen[4] = 'r';
   nen[5] = 'e';
   nen[6] = 's';
   nen[7] = 's';
   nen[8] = 'i';
   nen[9] = 'o';
   nen[10] = 'n';
   nen[11] = 0x00;
   nen[12] = 'c';
   nen[13] = 'o';
   nen[14] = 'm';
   nen[15] = 'p';
   nen[16] = 'r';
   nen[17] = 'e';
   nen[18] = 's';
   nen[19] = 's';
   nen[20] = 'i';
   nen[21] = 'o';
   nen[22] = 'n';
   nen[23] = 0x00;
   nen[24] = 0x01;
   nen[25] = 0x00;
   nen[26] = 0x00;
   nen[27] = 0x00;

   nen[28] = 0x03;  // cho ZIP (16 hàng chung)
   [dongDuLieu appendBytes:nen length:29];
   
   // ---- cửa sổ dữ liệu
   beRong--;  // số cột cuối
   beCao--;   // số hàng cuối
   unsigned char cuaSoDuLieu[37];
   cuaSoDuLieu[0] = 'd';
   cuaSoDuLieu[1] = 'a';
   cuaSoDuLieu[2] = 't';
   cuaSoDuLieu[3] = 'a';
   cuaSoDuLieu[4] = 'W';
   cuaSoDuLieu[5] = 'i';
   cuaSoDuLieu[6] = 'n';
   cuaSoDuLieu[7] = 'd';
   cuaSoDuLieu[8] = 'o';
   cuaSoDuLieu[9] = 'w';
   cuaSoDuLieu[10] = 0x00;
   cuaSoDuLieu[11] = 'b';
   cuaSoDuLieu[12] = 'o';
   cuaSoDuLieu[13] = 'x';
   cuaSoDuLieu[14] = '2';
   cuaSoDuLieu[15] = 'i';
   cuaSoDuLieu[16] = 0x00;
   cuaSoDuLieu[17] = 16;
   cuaSoDuLieu[18] = 0x00;
   cuaSoDuLieu[19] = 0x00;
   cuaSoDuLieu[20] = 0x00;

   // ---- góc x
   cuaSoDuLieu[21] = 0x00;
   cuaSoDuLieu[22] = 0x00;
   cuaSoDuLieu[23] = 0x00;
   cuaSoDuLieu[24] = 0x00;
   // ---- góc y
   cuaSoDuLieu[25] = 0x00;
   cuaSoDuLieu[26] = 0x00;
   cuaSoDuLieu[27] = 0x00;
   cuaSoDuLieu[28] = 0x00;
   // ---- cột cuối
   cuaSoDuLieu[29] = beRong & 0xff;
   cuaSoDuLieu[30] = (beRong >> 8) & 0xff;
   cuaSoDuLieu[31] = 0x00;
   cuaSoDuLieu[32] = 0x00;
   // ---- hàng cuối
   cuaSoDuLieu[33] = beCao & 0xff;
   cuaSoDuLieu[34] = (beCao >> 8) & 0xff;
   cuaSoDuLieu[35] = 0x00;
   cuaSoDuLieu[36] = 0x00;
   
   [dongDuLieu appendBytes:cuaSoDuLieu length:37];
   
   // ---- cửa sổ chiếu
   unsigned char cuaSoChieu[40];
   cuaSoChieu[0] = 'd';
   cuaSoChieu[1] = 'i';
   cuaSoChieu[2] = 's';
   cuaSoChieu[3] = 'p';
   cuaSoChieu[4] = 'l';
   cuaSoChieu[5] = 'a';
   cuaSoChieu[6] = 'y';
   cuaSoChieu[7] = 'W';
   cuaSoChieu[8] = 'i';
   cuaSoChieu[9] = 'n';
   cuaSoChieu[10] = 'd';
   cuaSoChieu[11] = 'o';
   cuaSoChieu[12] = 'w';
   cuaSoChieu[13] = 0x00;
   cuaSoChieu[14] = 'b';
   cuaSoChieu[15] = 'o';
   cuaSoChieu[16] = 'x';
   cuaSoChieu[17] = '2';
   cuaSoChieu[18] = 'i';
   cuaSoChieu[19] = 0x00;
   cuaSoChieu[20] = 16;
   cuaSoChieu[21] = 0x00;
   cuaSoChieu[22] = 0x00;
   cuaSoChieu[23] = 0x00;
   
   cuaSoChieu[24] = 0x00;
   cuaSoChieu[25] = 0x00;
   cuaSoChieu[26] = 0x00;
   cuaSoChieu[27] = 0x00;
   
   cuaSoChieu[28] = 0x00;
   cuaSoChieu[29] = 0x00;
   cuaSoChieu[30] = 0x00;
   cuaSoChieu[31] = 0x00;

   cuaSoChieu[32] = beRong & 0xff;
   cuaSoChieu[33] = (beRong >> 8) & 0xff;
   cuaSoChieu[34] = 0x00;
   cuaSoChieu[35] = 0x00;
   
   cuaSoChieu[36] = beCao & 0xff;
   cuaSoChieu[37] = (beCao >> 8) & 0xff;
   cuaSoChieu[38] = 0x00;
   cuaSoChieu[39] = 0x00;
   
   [dongDuLieu appendBytes:cuaSoChieu length:40];
   
   // ---- trở lại giá trị gốc
   beRong++;
   beCao++;

   // ---- thứ tự hàng
   unsigned char thuTuHang[25];
   thuTuHang[0] = 'l';
   thuTuHang[1] = 'i';
   thuTuHang[2] = 'n';
   thuTuHang[3] = 'e';
   thuTuHang[4] = 'O';
   thuTuHang[5] = 'r';
   thuTuHang[6] = 'd';
   thuTuHang[7] = 'e';
   thuTuHang[8] = 'r';
   thuTuHang[9] = 0x00;
   thuTuHang[10] = 'l';
   thuTuHang[11] = 'i';
   thuTuHang[12] = 'n';
   thuTuHang[13] = 'e';
   thuTuHang[14] = 'O';
   thuTuHang[15] = 'r';
   thuTuHang[16] = 'd';
   thuTuHang[17] = 'e';
   thuTuHang[18] = 'r';
   thuTuHang[19] = 0x00;
   
   thuTuHang[20] = 1;
   thuTuHang[21] = 0x00;
   thuTuHang[22] = 0x00;
   thuTuHang[23] = 0x00;

   thuTuHang[24] = 0x00;  // từ nhỏ tới lớn
   
   [dongDuLieu appendBytes:thuTuHang length:25];

   // ---- tỉ số cạnh điểm ảnh
   unsigned char tiSoCanhDiemAnh[31];
   tiSoCanhDiemAnh[0] = 'p';
   tiSoCanhDiemAnh[1] = 'i';
   tiSoCanhDiemAnh[2] = 'x';
   tiSoCanhDiemAnh[3] = 'e';
   tiSoCanhDiemAnh[4] = 'l';
   tiSoCanhDiemAnh[5] = 'A';
   tiSoCanhDiemAnh[6] = 's';
   tiSoCanhDiemAnh[7] = 'p';
   tiSoCanhDiemAnh[8] = 'e';
   tiSoCanhDiemAnh[9] = 'c';
   tiSoCanhDiemAnh[10] = 't';
   tiSoCanhDiemAnh[11] = 'R';
   tiSoCanhDiemAnh[12] = 'a';
   tiSoCanhDiemAnh[13] = 't';
   tiSoCanhDiemAnh[14] = 'i';
   tiSoCanhDiemAnh[15] = 'o';
   tiSoCanhDiemAnh[16] = 0x00;
   tiSoCanhDiemAnh[17] = 'f';
   tiSoCanhDiemAnh[18] = 'l';
   tiSoCanhDiemAnh[19] = 'o';
   tiSoCanhDiemAnh[20] = 'a';
   tiSoCanhDiemAnh[21] = 't';
   tiSoCanhDiemAnh[22] = 0x00;

   tiSoCanhDiemAnh[23] = 4;
   tiSoCanhDiemAnh[24] = 0x00;
   tiSoCanhDiemAnh[25] = 0x00;
   tiSoCanhDiemAnh[26] = 0x00;

   tiSoCanhDiemAnh[27] = 0x00;
   tiSoCanhDiemAnh[28] = 0x00;
   tiSoCanhDiemAnh[29] = 0x80;
   tiSoCanhDiemAnh[30] = 0x3f;

   [dongDuLieu appendBytes:tiSoCanhDiemAnh length:31];
   
   // ---- trung tâm cửa sổ màn
   unsigned char trungTamCuaSoMan[35];
   trungTamCuaSoMan[0] = 's';
   trungTamCuaSoMan[1] = 'c';
   trungTamCuaSoMan[2] = 'r';
   trungTamCuaSoMan[3] = 'e';
   trungTamCuaSoMan[4] = 'e';
   trungTamCuaSoMan[5] = 'n';
   trungTamCuaSoMan[6] = 'W';
   trungTamCuaSoMan[7] = 'i';
   trungTamCuaSoMan[8] = 'n';
   trungTamCuaSoMan[9] = 'd';
   trungTamCuaSoMan[10] = 'o';
   trungTamCuaSoMan[11] = 'w';
   trungTamCuaSoMan[12] = 'C';
   trungTamCuaSoMan[13] = 'e';
   trungTamCuaSoMan[14] = 'n';
   trungTamCuaSoMan[15] = 't';
   trungTamCuaSoMan[16] = 'e';
   trungTamCuaSoMan[17] = 'r';
   trungTamCuaSoMan[18] = 0x00;
   trungTamCuaSoMan[19] = 'v';
   trungTamCuaSoMan[20] = '2';
   trungTamCuaSoMan[21] = 'f';
   trungTamCuaSoMan[22] = 0x00;

   trungTamCuaSoMan[23] = 8;
   trungTamCuaSoMan[24] = 0x00;
   trungTamCuaSoMan[25] = 0x00;
   trungTamCuaSoMan[26] = 0x00;
   // ---- tọa độ x (tung độ)
   trungTamCuaSoMan[27] = 0x00;
   trungTamCuaSoMan[28] = 0x00;
   trungTamCuaSoMan[29] = 0x00;
   trungTamCuaSoMan[30] = 0x00;
   // ---- tọa độ y (hoành độ)
   trungTamCuaSoMan[31] = 0x00;
   trungTamCuaSoMan[32] = 0x00;
   trungTamCuaSoMan[33] = 0x00;
   trungTamCuaSoMan[34] = 0x00;

   [dongDuLieu appendBytes:trungTamCuaSoMan length:35];

   // ---- bề rộng cửa sổ màn
   unsigned char beRongCuaSoMan[32];
   beRongCuaSoMan[0] = 's';
   beRongCuaSoMan[1] = 'c';
   beRongCuaSoMan[2] = 'r';
   beRongCuaSoMan[3] = 'e';
   beRongCuaSoMan[4] = 'e';
   beRongCuaSoMan[5] = 'n';
   beRongCuaSoMan[6] = 'W';
   beRongCuaSoMan[7] = 'i';
   beRongCuaSoMan[8] = 'n';
   beRongCuaSoMan[9] = 'd';
   beRongCuaSoMan[10] = 'o';
   beRongCuaSoMan[11] = 'w';
   beRongCuaSoMan[12] = 'W';
   beRongCuaSoMan[13] = 'i';
   beRongCuaSoMan[14] = 'd';
   beRongCuaSoMan[15] = 't';
   beRongCuaSoMan[16] = 'h';
   beRongCuaSoMan[17] = 0x00;
   beRongCuaSoMan[18] = 'f';
   beRongCuaSoMan[19] = 'l';
   beRongCuaSoMan[20] = 'o';
   beRongCuaSoMan[21] = 'a';
   beRongCuaSoMan[22] = 't';
   beRongCuaSoMan[23] = 0x00;

   beRongCuaSoMan[24] = 4;
   beRongCuaSoMan[25] = 0x00;
   beRongCuaSoMan[26] = 0x00;
   beRongCuaSoMan[27] = 0x00;
   
   beRongCuaSoMan[28] = 0x00;
   beRongCuaSoMan[29] = 0x00;
   beRongCuaSoMan[30] = 0x80;
   beRongCuaSoMan[31] = 0x3f;

   [dongDuLieu appendBytes:beRongCuaSoMan length:32];
   
   // ---- kết thúc bản đặc điểm
   [dongDuLieu appendBytes:&ketTuc length:1];
   
   // ==== Làm bảng địa chỉ thành phần song song với thành phần
   // ---- tính số lượng thành phần cho biết bề dài địa chỉ bảng thành phần
   unsigned int soLuongThanhPhan = beCao >> 4;   // cho tập tin ZIP mỗi thành phần cao 16 hàng
   // ---- xem nếu có một thành phần thừa (không đủ 16 hàng)
   if( !((soLuongThanhPhan << 4) == beCao) )
      soLuongThanhPhan++;
   
   // ---- giữ địa chỉ cho đầu bảng thành phần
   unsigned long int diaChiBangThanhPhan = [dongDuLieu length];

   // ---- chứa chỗ cho bảng thành phần (chưa biết dịa chỉ các thành phần, chưa nén nó)
   unsigned int soThanhPhan = 0;
   unsigned long int diaChiThanhPhan = 0;
   while ( soThanhPhan < soLuongThanhPhan ) {
      [dongDuLieu appendBytes:&diaChiThanhPhan length:8];
      soThanhPhan++;
   }
   
   // ---- các thành phần (kiểu hàng)

   // ---- bề dài thành phần chưa nén
   unsigned int beDaiThanhPhan_chuaNen = beRong << 7;  //  unsigned short (2), bốn kênh (4), số hàng một thành phần (16)
   // ---- bề dài một hàng từ một kênh chưa nén
   unsigned int beDaiDuLieu_motHangKenh = beRong << 1; //  unsigned short (2)
   
   // ----
   unsigned char *duLieuThanhPhan = malloc( beDaiThanhPhan_chuaNen );
   unsigned char *duLieuThanhPhanLoc = malloc( beDaiThanhPhan_chuaNen );
   unsigned char *duLieuThanhPhanNen = malloc( beDaiThanhPhan_chuaNen << 1);
   // ---- bắt đầu từ trên đi dưới, phải lật ngược
   unsigned int diaChiTrongKenh = beRong*(beCao - 1) << 1;   // địa chỉ trong các kênh rút dữ liệu

   soThanhPhan = 0;
   int soHang = 0;
   while( soThanhPhan < soLuongThanhPhan ) {
   
      // ==== soạn thành phần
      unsigned int soLuongHangChep = beCao - soHang;
      if( soLuongHangChep > 16 )
         soLuongHangChep = 16;
      
      unsigned int diaChiSoan = 0;   // địa chỉ cho soạn dữ liệu từ kênh

      unsigned char soHangChep = 0;
      while ( soHangChep < soLuongHangChep ) {
//         NSLog( @"LuuEXR: soTP %d  soHang %d  soHangChep %d", soThanhPhan, soHang, soHangChep );
//         NSLog( @"LuuEXR: diaChiTrongKenh %d  diaChiSoanp %d", diaChiTrongKenh, diaChiSoan );
         // ----
         memcpy(&(duLieuThanhPhan[diaChiSoan]), &(kenhDuc[diaChiTrongKenh]), beDaiDuLieu_motHangKenh);
         diaChiSoan += beDaiDuLieu_motHangKenh;
         
         // ----
         memcpy(&(duLieuThanhPhan[diaChiSoan]), &(kenhXanh[diaChiTrongKenh]), beDaiDuLieu_motHangKenh);
         diaChiSoan += beDaiDuLieu_motHangKenh;
         
         // ----
         memcpy(&(duLieuThanhPhan[diaChiSoan]), &(kenhLuc[diaChiTrongKenh]), beDaiDuLieu_motHangKenh);
         diaChiSoan += beDaiDuLieu_motHangKenh;

         // ----
         memcpy(&(duLieuThanhPhan[diaChiSoan]), &(kenhDo[diaChiTrongKenh]), beDaiDuLieu_motHangKenh);
         diaChiSoan += beDaiDuLieu_motHangKenh;

         soHangChep++;
         // ---- trở ngược một hàng, phải lật ngược ảnh cho EXR
         diaChiTrongKenh -= beDaiDuLieu_motHangKenh;
      }

      // ---- bề dài thàng phần cuối có thể nhỏ hơn beDaiThanhPhan_chuaNen 
      [ImfFilter filterDataInBuffer:duLieuThanhPhan withLength:diaChiSoan andPutInFilteredBuffer:duLieuThanhPhanLoc];
      
      // ---- nén thành phần
      unsigned int beDaiDuLieuNen = (unsigned int)[LuuEXR compressChunk:duLieuThanhPhanLoc withLength:diaChiSoan andPutInBuffer:duLieuThanhPhanNen withLength:beDaiThanhPhan_chuaNen << 1];

      // ---- luư địa chỉ trong bảng thành phần
      diaChiThanhPhan = [dongDuLieu length];
      NSRange tam;
      tam.location = diaChiBangThanhPhan;
      tam.length = 8;
      [dongDuLieu replaceBytesInRange:tam withBytes:&diaChiThanhPhan];
      diaChiBangThanhPhan += 8; // phần tử tiếp trong bảng
      
      // ---- lưu địa chỉ trong bảnh thành phần
      [dongDuLieu appendBytes:&soHang length:4];

      // ---- bề dài dữ liệu
      [dongDuLieu appendBytes:&beDaiDuLieuNen length:4];
      
      // ---- lưu dữ liệu
      [dongDuLieu appendBytes:duLieuThanhPhanNen length:beDaiDuLieuNen];
      // ---- dữ liệu có 16 hàng trong một bó
      soHang += 16;
      soThanhPhan++;
   }
   
   // ---- lưu tập tin
   [dongDuLieu writeToURL:URL_tapTin atomically:YES];
   
   free( duLieuThanhPhan );
   free( duLieuThanhPhanLoc );
   free( duLieuThanhPhanNen );
}


+ (void)luuEXRFloat_voiURL:(NSURL *)URL_tapTin beRong:(unsigned int)beRong beCao:(unsigned int)beCao
                 vaKenhDo:(unsigned char *)kenhDo kenhLuc:(unsigned char *)kenhLuc kenhXanh:(unsigned char *)kenhXanh
                  kenhDuc:(unsigned char *)kenhDuc; {
   
   // ---- ký hiệu tấp tin EXR
   unsigned int kyHieuTapTin = 0x01312f76;  // ngược cho intel;
   NSMutableData *dongDuLieu = [NSMutableData dataWithBytes:&kyHieuTapTin length:4];
   
   // ---- phiên bản 2 (chỉ phiên bản 2 được phát hành)
   unsigned int phienBan = 0x02;
   [dongDuLieu appendBytes:&phienBan length:4];
   
   // ---- bốn kênh A B G R kiểu  half
   unsigned char tuaKenh[20];
   tuaKenh[0] = 'c';
   tuaKenh[1] = 'h';
   tuaKenh[2] = 'a';
   tuaKenh[3] = 'n';
   tuaKenh[4] = 'n';
   tuaKenh[5] = 'e';
   tuaKenh[6] = 'l';
   tuaKenh[7] = 's';
   tuaKenh[8] = 0x00;
   tuaKenh[9] = 'c';
   tuaKenh[10] = 'h';
   tuaKenh[11] = 'l';
   tuaKenh[12] = 'i';
   tuaKenh[13] = 's';
   tuaKenh[14] = 't';
   tuaKenh[15] = 0x00;
   tuaKenh[16] = 73;   // bề dài cho 4 kênh, tên các kênh dài một chữ cái ASCII
   tuaKenh[17] = 0x00;
   tuaKenh[18] = 0x00;
   tuaKenh[19] = 0x00;
   [dongDuLieu appendBytes:tuaKenh length:20];
   
   unsigned char kenh[18];
   kenh[0] = 'A';
   kenh[1] = 0x00;
   
   kenh[2] = 0x02;  // kiểu dữ liệu 0x01 nghỉa là float
   kenh[3] = 0x00;
   kenh[4] = 0x00;
   kenh[5] = 0x00;
   
   kenh[6] = 0x00;   // chỉ xài cho phương pháp nén B44, ở đây không xài
   kenh[7] = 0x00;
   kenh[8] = 0x00;
   kenh[9] = 0x00;
   
   kenh[10] = 0x01;  // nhịp x
   kenh[11] = 0x00;
   kenh[12] = 0x00;
   kenh[13] = 0x00;
   
   kenh[14] = 0x01;  // nhịp y
   kenh[15] = 0x00;
   kenh[16] = 0x00;
   kenh[17] = 0x00;
   [dongDuLieu appendBytes:kenh length:18];
   
   kenh[0] = 'B';
   [dongDuLieu appendBytes:kenh length:18];
   
   kenh[0] = 'G';
   [dongDuLieu appendBytes:kenh length:18];
   
   kenh[0] = 'R';
   [dongDuLieu appendBytes:kenh length:18];
   
   unsigned char ketTuc = 0x00;
   [dongDuLieu appendBytes:&ketTuc length:1];
   
   // ---- nén
   unsigned char nen[29];
   nen[0] = 'c';
   nen[1] = 'o';
   nen[2] = 'm';
   nen[3] = 'p';
   nen[4] = 'r';
   nen[5] = 'e';
   nen[6] = 's';
   nen[7] = 's';
   nen[8] = 'i';
   nen[9] = 'o';
   nen[10] = 'n';
   nen[11] = 0x00;
   nen[12] = 'c';
   nen[13] = 'o';
   nen[14] = 'm';
   nen[15] = 'p';
   nen[16] = 'r';
   nen[17] = 'e';
   nen[18] = 's';
   nen[19] = 's';
   nen[20] = 'i';
   nen[21] = 'o';
   nen[22] = 'n';
   nen[23] = 0x00;
   nen[24] = 0x01;
   nen[25] = 0x00;
   nen[26] = 0x00;
   nen[27] = 0x00;
   
   nen[28] = 0x03;  // cho ZIP (16 hàng chung)
   [dongDuLieu appendBytes:nen length:29];
   
   // ---- cửa sổ dữ liệu
   beRong--;  // số cột cuối
   beCao--;   // số hàng cuối
   unsigned char cuaSoDuLieu[37];
   cuaSoDuLieu[0] = 'd';
   cuaSoDuLieu[1] = 'a';
   cuaSoDuLieu[2] = 't';
   cuaSoDuLieu[3] = 'a';
   cuaSoDuLieu[4] = 'W';
   cuaSoDuLieu[5] = 'i';
   cuaSoDuLieu[6] = 'n';
   cuaSoDuLieu[7] = 'd';
   cuaSoDuLieu[8] = 'o';
   cuaSoDuLieu[9] = 'w';
   cuaSoDuLieu[10] = 0x00;
   cuaSoDuLieu[11] = 'b';
   cuaSoDuLieu[12] = 'o';
   cuaSoDuLieu[13] = 'x';
   cuaSoDuLieu[14] = '2';
   cuaSoDuLieu[15] = 'i';
   cuaSoDuLieu[16] = 0x00;
   cuaSoDuLieu[17] = 16;
   cuaSoDuLieu[18] = 0x00;
   cuaSoDuLieu[19] = 0x00;
   cuaSoDuLieu[20] = 0x00;
   
   // ---- góc x
   cuaSoDuLieu[21] = 0x00;
   cuaSoDuLieu[22] = 0x00;
   cuaSoDuLieu[23] = 0x00;
   cuaSoDuLieu[24] = 0x00;
   // ---- góc y
   cuaSoDuLieu[25] = 0x00;
   cuaSoDuLieu[26] = 0x00;
   cuaSoDuLieu[27] = 0x00;
   cuaSoDuLieu[28] = 0x00;
   // ---- cột cuối
   cuaSoDuLieu[29] = beRong & 0xff;
   cuaSoDuLieu[30] = (beRong >> 8) & 0xff;
   cuaSoDuLieu[31] = 0x00;
   cuaSoDuLieu[32] = 0x00;
   // ---- hàng cuối
   cuaSoDuLieu[33] = beCao & 0xff;
   cuaSoDuLieu[34] = (beCao >> 8) & 0xff;
   cuaSoDuLieu[35] = 0x00;
   cuaSoDuLieu[36] = 0x00;
   
   [dongDuLieu appendBytes:cuaSoDuLieu length:37];
   
   // ---- cửa sổ chiếu
   unsigned char cuaSoChieu[40];
   cuaSoChieu[0] = 'd';
   cuaSoChieu[1] = 'i';
   cuaSoChieu[2] = 's';
   cuaSoChieu[3] = 'p';
   cuaSoChieu[4] = 'l';
   cuaSoChieu[5] = 'a';
   cuaSoChieu[6] = 'y';
   cuaSoChieu[7] = 'W';
   cuaSoChieu[8] = 'i';
   cuaSoChieu[9] = 'n';
   cuaSoChieu[10] = 'd';
   cuaSoChieu[11] = 'o';
   cuaSoChieu[12] = 'w';
   cuaSoChieu[13] = 0x00;
   cuaSoChieu[14] = 'b';
   cuaSoChieu[15] = 'o';
   cuaSoChieu[16] = 'x';
   cuaSoChieu[17] = '2';
   cuaSoChieu[18] = 'i';
   cuaSoChieu[19] = 0x00;
   cuaSoChieu[20] = 16;
   cuaSoChieu[21] = 0x00;
   cuaSoChieu[22] = 0x00;
   cuaSoChieu[23] = 0x00;
   
   cuaSoChieu[24] = 0x00;
   cuaSoChieu[25] = 0x00;
   cuaSoChieu[26] = 0x00;
   cuaSoChieu[27] = 0x00;
   
   cuaSoChieu[28] = 0x00;
   cuaSoChieu[29] = 0x00;
   cuaSoChieu[30] = 0x00;
   cuaSoChieu[31] = 0x00;
   
   cuaSoChieu[32] = beRong & 0xff;
   cuaSoChieu[33] = (beRong >> 8) & 0xff;
   cuaSoChieu[34] = 0x00;
   cuaSoChieu[35] = 0x00;
   
   cuaSoChieu[36] = beCao & 0xff;
   cuaSoChieu[37] = (beCao >> 8) & 0xff;
   cuaSoChieu[38] = 0x00;
   cuaSoChieu[39] = 0x00;
   
   [dongDuLieu appendBytes:cuaSoChieu length:40];
   
   // ---- trở lại giá trị gốc
   beRong++;
   beCao++;
   
   // ---- thứ tự hàng
   unsigned char thuTuHang[25];
   thuTuHang[0] = 'l';
   thuTuHang[1] = 'i';
   thuTuHang[2] = 'n';
   thuTuHang[3] = 'e';
   thuTuHang[4] = 'O';
   thuTuHang[5] = 'r';
   thuTuHang[6] = 'd';
   thuTuHang[7] = 'e';
   thuTuHang[8] = 'r';
   thuTuHang[9] = 0x00;
   thuTuHang[10] = 'l';
   thuTuHang[11] = 'i';
   thuTuHang[12] = 'n';
   thuTuHang[13] = 'e';
   thuTuHang[14] = 'O';
   thuTuHang[15] = 'r';
   thuTuHang[16] = 'd';
   thuTuHang[17] = 'e';
   thuTuHang[18] = 'r';
   thuTuHang[19] = 0x00;
   
   thuTuHang[20] = 1;
   thuTuHang[21] = 0x00;
   thuTuHang[22] = 0x00;
   thuTuHang[23] = 0x00;
   
   thuTuHang[24] = 0x00;  // từ nhỏ tới lớn
   
   [dongDuLieu appendBytes:thuTuHang length:25];
   
   // ---- tỉ số cạnh điểm ảnh
   unsigned char tiSoCanhDiemAnh[31];
   tiSoCanhDiemAnh[0] = 'p';
   tiSoCanhDiemAnh[1] = 'i';
   tiSoCanhDiemAnh[2] = 'x';
   tiSoCanhDiemAnh[3] = 'e';
   tiSoCanhDiemAnh[4] = 'l';
   tiSoCanhDiemAnh[5] = 'A';
   tiSoCanhDiemAnh[6] = 's';
   tiSoCanhDiemAnh[7] = 'p';
   tiSoCanhDiemAnh[8] = 'e';
   tiSoCanhDiemAnh[9] = 'c';
   tiSoCanhDiemAnh[10] = 't';
   tiSoCanhDiemAnh[11] = 'R';
   tiSoCanhDiemAnh[12] = 'a';
   tiSoCanhDiemAnh[13] = 't';
   tiSoCanhDiemAnh[14] = 'i';
   tiSoCanhDiemAnh[15] = 'o';
   tiSoCanhDiemAnh[16] = 0x00;
   tiSoCanhDiemAnh[17] = 'f';
   tiSoCanhDiemAnh[18] = 'l';
   tiSoCanhDiemAnh[19] = 'o';
   tiSoCanhDiemAnh[20] = 'a';
   tiSoCanhDiemAnh[21] = 't';
   tiSoCanhDiemAnh[22] = 0x00;
   
   tiSoCanhDiemAnh[23] = 4;
   tiSoCanhDiemAnh[24] = 0x00;
   tiSoCanhDiemAnh[25] = 0x00;
   tiSoCanhDiemAnh[26] = 0x00;
   
   tiSoCanhDiemAnh[27] = 0x00;
   tiSoCanhDiemAnh[28] = 0x00;
   tiSoCanhDiemAnh[29] = 0x80;
   tiSoCanhDiemAnh[30] = 0x3f;
   
   [dongDuLieu appendBytes:tiSoCanhDiemAnh length:31];
   
   // ---- trung tâm cửa sổ màn
   unsigned char trungTamCuaSoMan[35];
   trungTamCuaSoMan[0] = 's';
   trungTamCuaSoMan[1] = 'c';
   trungTamCuaSoMan[2] = 'r';
   trungTamCuaSoMan[3] = 'e';
   trungTamCuaSoMan[4] = 'e';
   trungTamCuaSoMan[5] = 'n';
   trungTamCuaSoMan[6] = 'W';
   trungTamCuaSoMan[7] = 'i';
   trungTamCuaSoMan[8] = 'n';
   trungTamCuaSoMan[9] = 'd';
   trungTamCuaSoMan[10] = 'o';
   trungTamCuaSoMan[11] = 'w';
   trungTamCuaSoMan[12] = 'C';
   trungTamCuaSoMan[13] = 'e';
   trungTamCuaSoMan[14] = 'n';
   trungTamCuaSoMan[15] = 't';
   trungTamCuaSoMan[16] = 'e';
   trungTamCuaSoMan[17] = 'r';
   trungTamCuaSoMan[18] = 0x00;
   trungTamCuaSoMan[19] = 'v';
   trungTamCuaSoMan[20] = '2';
   trungTamCuaSoMan[21] = 'f';
   trungTamCuaSoMan[22] = 0x00;
   
   trungTamCuaSoMan[23] = 8;
   trungTamCuaSoMan[24] = 0x00;
   trungTamCuaSoMan[25] = 0x00;
   trungTamCuaSoMan[26] = 0x00;
   // ---- tọa độ x (tung độ)
   trungTamCuaSoMan[27] = 0x00;
   trungTamCuaSoMan[28] = 0x00;
   trungTamCuaSoMan[29] = 0x00;
   trungTamCuaSoMan[30] = 0x00;
   // ---- tọa độ y (hoành độ)
   trungTamCuaSoMan[31] = 0x00;
   trungTamCuaSoMan[32] = 0x00;
   trungTamCuaSoMan[33] = 0x00;
   trungTamCuaSoMan[34] = 0x00;
   
   [dongDuLieu appendBytes:trungTamCuaSoMan length:35];
   
   // ---- bề rộng cửa sổ màn
   unsigned char beRongCuaSoMan[32];
   beRongCuaSoMan[0] = 's';
   beRongCuaSoMan[1] = 'c';
   beRongCuaSoMan[2] = 'r';
   beRongCuaSoMan[3] = 'e';
   beRongCuaSoMan[4] = 'e';
   beRongCuaSoMan[5] = 'n';
   beRongCuaSoMan[6] = 'W';
   beRongCuaSoMan[7] = 'i';
   beRongCuaSoMan[8] = 'n';
   beRongCuaSoMan[9] = 'd';
   beRongCuaSoMan[10] = 'o';
   beRongCuaSoMan[11] = 'w';
   beRongCuaSoMan[12] = 'W';
   beRongCuaSoMan[13] = 'i';
   beRongCuaSoMan[14] = 'd';
   beRongCuaSoMan[15] = 't';
   beRongCuaSoMan[16] = 'h';
   beRongCuaSoMan[17] = 0x00;
   beRongCuaSoMan[18] = 'f';
   beRongCuaSoMan[19] = 'l';
   beRongCuaSoMan[20] = 'o';
   beRongCuaSoMan[21] = 'a';
   beRongCuaSoMan[22] = 't';
   beRongCuaSoMan[23] = 0x00;
   
   beRongCuaSoMan[24] = 4;
   beRongCuaSoMan[25] = 0x00;
   beRongCuaSoMan[26] = 0x00;
   beRongCuaSoMan[27] = 0x00;
   
   beRongCuaSoMan[28] = 0x00;
   beRongCuaSoMan[29] = 0x00;
   beRongCuaSoMan[30] = 0x80;
   beRongCuaSoMan[31] = 0x3f;
   
   [dongDuLieu appendBytes:beRongCuaSoMan length:32];
   
   // ---- kết thúc bản đặc điểm
   [dongDuLieu appendBytes:&ketTuc length:1];
   
   // ==== Làm bảng địa chỉ thành phần song song với thành phần
   // ---- tính số lượng thành phần cho biết bề dài địa chỉ bảng thành phần
   unsigned int soLuongThanhPhan = beCao >> 4;   // cho tập tin ZIP mỗi thành phần cao 16 hàng
   // ---- xem nếu có một thành phần thừa (không đủ 16 hàng)
   if( !((soLuongThanhPhan << 4) == beCao) )
      soLuongThanhPhan++;
   
   // ---- giữ địa chỉ cho đầu bảng thành phần
   unsigned long int diaChiBangThanhPhan = [dongDuLieu length];
   
   // ---- chứa chỗ cho bảng thành phần (chưa biết dịa chỉ các thành phần, chưa nén nó)
   unsigned int soThanhPhan = 0;
   unsigned long int diaChiThanhPhan = 0;
   while ( soThanhPhan < soLuongThanhPhan ) {
      [dongDuLieu appendBytes:&diaChiThanhPhan length:8];
      soThanhPhan++;
   }
   
   // ---- các thành phần (kiểu hàng)
   
   // ---- bề dài thành phần chưa nén
   unsigned int beDaiThanhPhan_chuaNen = beRong << 8;  //  float (4), bốn kênh (4), số hàng một thành phần (16)
   // ---- bề dài một hàng từ một kênh chưa nén
   unsigned int beDaiDuLieu_motHangKenh = beRong << 2; //  float (4)
   
   // ----
   unsigned char *duLieuThanhPhan = malloc( beDaiThanhPhan_chuaNen );
   unsigned char *duLieuThanhPhanLoc = malloc( beDaiThanhPhan_chuaNen );
   unsigned char *duLieuThanhPhanNen = malloc( beDaiThanhPhan_chuaNen << 1);
   // ---- bắt đầu từ trên đi dưới, phải lật ngược
   unsigned int diaChiTrongKenh = beRong*(beCao - 1) << 2;   // địa chỉ trong các kênh rút dữ liệu
   
   soThanhPhan = 0;
   int soHang = 0;
   while( soThanhPhan < soLuongThanhPhan ) {
      
      // ==== soạn thành phần
      unsigned int soLuongHangChep = beCao - soHang;
      if( soLuongHangChep > 16 )
         soLuongHangChep = 16;
      
      unsigned int diaChiSoan = 0;   // địa chỉ cho soạn dữ liệu từ kênh
      
      unsigned char soHangChep = 0;
      while ( soHangChep < soLuongHangChep ) {
         //         NSLog( @"LuuEXR: soTP %d  soHang %d  soHangChep %d", soThanhPhan, soHang, soHangChep );
         //         NSLog( @"LuuEXR: diaChiTrongKenh %d  diaChiSoanp %d", diaChiTrongKenh, diaChiSoan );
         // ----
         memcpy(&(duLieuThanhPhan[diaChiSoan]), &(kenhDuc[diaChiTrongKenh]), beDaiDuLieu_motHangKenh);
         diaChiSoan += beDaiDuLieu_motHangKenh;
         
         // ----
         memcpy(&(duLieuThanhPhan[diaChiSoan]), &(kenhXanh[diaChiTrongKenh]), beDaiDuLieu_motHangKenh);
         diaChiSoan += beDaiDuLieu_motHangKenh;
         
         // ----
         memcpy(&(duLieuThanhPhan[diaChiSoan]), &(kenhLuc[diaChiTrongKenh]), beDaiDuLieu_motHangKenh);
         diaChiSoan += beDaiDuLieu_motHangKenh;
         
         // ----
         memcpy(&(duLieuThanhPhan[diaChiSoan]), &(kenhDo[diaChiTrongKenh]), beDaiDuLieu_motHangKenh);
         diaChiSoan += beDaiDuLieu_motHangKenh;
         
         soHangChep++;
         // ---- trở ngược một hàng, phải lật ngược ảnh cho EXR
         diaChiTrongKenh -= beDaiDuLieu_motHangKenh;
      }
      
      // ---- bề dài thàng phần cuối có thể nhỏ hơn beDaiThanhPhan_chuaNen
      [ImfFilter filterDataInBuffer:duLieuThanhPhan withLength:diaChiSoan andPutInFilteredBuffer:duLieuThanhPhanLoc];
      
      // ---- nén thành phần
      unsigned int beDaiDuLieuNen = (unsigned int)[LuuEXR compressChunk:duLieuThanhPhanLoc withLength:diaChiSoan andPutInBuffer:duLieuThanhPhanNen withLength:beDaiThanhPhan_chuaNen << 1];
      
      // ---- luư địa chỉ trong bảng thành phần
      diaChiThanhPhan = [dongDuLieu length];
      NSRange tam;
      tam.location = diaChiBangThanhPhan;
      tam.length = 8;
      [dongDuLieu replaceBytesInRange:tam withBytes:&diaChiThanhPhan];
      diaChiBangThanhPhan += 8; // phần tử tiếp trong bảng
      
      // ---- lưu địa chỉ trong bảnh thành phần
      [dongDuLieu appendBytes:&soHang length:4];
      
      // ---- bề dài dữ liệu
      [dongDuLieu appendBytes:&beDaiDuLieuNen length:4];
      
      // ---- lưu dữ liệu
      [dongDuLieu appendBytes:duLieuThanhPhanNen length:beDaiDuLieuNen];
      // ---- dữ liệu có 16 hàng trong một bó
      soHang += 16;
      soThanhPhan++;
   }
   
   // ---- lưu tập tin
   [dongDuLieu writeToURL:URL_tapTin atomically:YES];
   
   free( duLieuThanhPhan );
   free( duLieuThanhPhanLoc );
   free( duLieuThanhPhanNen );
}

#pragma mark ---- Nén Thành Phần
+ (unsigned long)compressChunk:(unsigned char *)in withLength:(unsigned int)inLength andPutInBuffer:(unsigned char *)out withLength:(unsigned int)outLength; {
   
   /*   unsigned int diaChi = 0;
    while ( diaChi < inLength ) {
    printf( "%02x ", in[diaChi] );
    diaChi++;
    } */
   
   int err;
   z_stream c_stream; // decompression stream data struct
   
   c_stream.zalloc = Z_NULL;
   c_stream.zfree = Z_NULL;
   c_stream.opaque = Z_NULL;
   //   c_stream.data_type = Z_BINARY;
   
   
   // ---- xem nếu chuẩn bị có sai lầm nào
   //   err = deflateInit2( &c_stream, Z_BEST_COMPRESSION, Z_DEFLATED, 15, 8, Z_DEFAULT_STRATEGY );
   err = deflateInit(&c_stream, Z_DEFAULT_COMPRESSION);
   
   if( err != Z_OK )
      NSLog( @"ExrZIP: compress: error deflateInit %d (%x) c_stream.avail_in %d", err, err, c_stream.avail_in );
   
   // ---- cho dữ liệu cần nén
   c_stream.next_in = in;
   c_stream.avail_in = inLength;
   
   // ---- dự đoán trí nhớ cần cho nén dữ liệu
   unsigned int beDaiDuDoan = (unsigned int)deflateBound(&c_stream, inLength );
   if( beDaiDuDoan > outLength )
      NSLog( @"ExrZIP: zlib compress beDaiDuDoan %d > outLength %d", beDaiDuDoan, outLength );
   
   // ---- cho địa chỉ trí nhớ để nén dữ liệu
   c_stream.next_out  = out;
   c_stream.avail_out = outLength;  // same length as in buffer
   err = deflate(&c_stream, Z_FINISH);
   
   if( err != Z_STREAM_END ) {
      if( err == Z_OK) {
         NSLog( @"ImfCompressorZIP: compress: Z_OK d_stream.avail_out %d d_stream.total_out %lu",
               c_stream.avail_out, c_stream.total_out );
      }
      else
         NSLog( @"ImfCompressorZIP: compress: error deflate %d (%x) d_stream.avail_out %d d_stream.total_out %lu",
               err, err, c_stream.avail_in, c_stream.total_in );
   }
   
   err = deflateEnd( &c_stream );
   if( err != Z_OK )
      NSLog( @"ExrZIP: compress: error deflateEnd %d (%x) c_stream.avail_out %d", err, err, c_stream.avail_out );
   return c_stream.total_out;
}


@end
