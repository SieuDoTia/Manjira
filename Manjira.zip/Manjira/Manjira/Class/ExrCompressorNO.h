//
//  ExrCompressorNO.h
//  Test13
//
//  Created by 小小 on 27/6/2555.
//  Copyright (c) 2555 BE __MyCompanyName__. All rights reserved.
//
#import <Foundation/Foundation.h>

@class ExrBangThanhPhan;

@interface ExrCompressorNO : NSObject

// ==== LƯU
// ---- hàng
+ (void)luuDuLieuAnh:(NSMutableData *)duLieuAnh voiBangThanhPhanHang:(ExrBangThanhPhan *)bangThanhPhan vaMangKenh:(NSMutableArray *)mangKenh rong:(unsigned int)rong cao:(unsigned int)cao soHangDau:(unsigned int)soHangDau;

// ---- ô chữ nhật
+ (void)luuDuLieuAnh:(NSMutableData *)duLieuAnh voiBangThanhPhanGach:(ExrBangThanhPhan *)bangThanhPhan
          vaMangKenh:(NSMutableArray *)mangKenh rongAnh:(unsigned int)rongAnh caoAnh:(unsigned int)caoAnh
            rongGach:(unsigned int)rongGach caoGach:(unsigned int)caoGach;

// ==== ĐỌC
// ---- hàng
+ (void)docDuLieuAnh:(NSData *)duLieuAnh voiBangThanhPhan:(ExrBangThanhPhan *)thongTinBangThanhPhan
          vaMangKenh:(NSMutableArray *)mangKenh rong:(unsigned int)rong cao:(unsigned int)cao;

// ---- ô chữ nhật
+ (void)docDuLieuAnh:(NSData *)duLieuAnh voiBangThanhPhanGach:(ExrBangThanhPhan *)thongTinBangThanhPhan
          vaMangKenh:(NSMutableArray *)mangKenh rongHinh:(unsigned int)rongHinh caoHinh:(unsigned int)caoHinh
            rongGach:(unsigned int)rongGach caoGach:(unsigned int)caoGach;

// ---- ĐIỂM ẢNH SÂU
//+ (void)docDuLieuDiemAnhSau:(NSData *)duLieuAnh voiBangThanhPhanGach:(ExrBangThanhPhan *)thongTinBangThanhPhan
//          vaMangKenh:(NSMutableArray *)mangKenh rongHinh:(unsigned int)rongHinh caoHinh:(unsigned int)caoHinh
//            rongGach:(unsigned int)rongGach caoGach:(unsigned int)caoGach;

@end
