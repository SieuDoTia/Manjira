//
//  ToMauPhanDang4x4.m
//  Manjira
//
//  Created by 小小 on 11/10/2557.
//

#import "ToMauPhanDang4x4.h"
#import "ThongTinPhanDang.h"
#import "ToMau.h"

@implementation ToMauPhanDang4x4

- (id)initChoSoHang:(unsigned short)_soHang soLuongHang:(unsigned short)_soLuongHang
              soCot:(unsigned short)_soCot soLuongCot:(unsigned short)_soLuongCot
              thongTinPhanDang:(ThongTinPhanDang *)_thongTinPhanDang; {
   
   self = [super init];

   if( self ) {
      thongTinPhanDang = _thongTinPhanDang;
      toMau = [_thongTinPhanDang toMau];
      
      soHang = _soHang;
      soLuongHang = _soLuongHang;
      
      soCot = _soCot;
      soLuongCot = _soLuongCot;
   }
   
   return self;
}


#pragma mark ---- Main
- (void)main; {
   
   if( ![self isCancelled] ) {
      [toMau to4x4VoiThongTin:thongTinPhanDang soHang:soHang soLuongHang:soLuongHang soCot:soCot soLuongCot:soLuongCot];
   }
}


@end
