//
//  CacKho.h
//  Manjira
//
//  Created by 小小 on 27/11/2556.
//

#import <Foundation/Foundation.h>


@interface CacKho : NSObject

+ (BOOL)choAnhTinhBeRong:(unsigned short *)beRongAnhTinh vaBeCao:(unsigned short *)beCaoAnhTinh
                   choSo:(unsigned char)soCoThuoc;

@end
