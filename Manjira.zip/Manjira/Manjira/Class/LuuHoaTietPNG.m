//
//  LuuHoaTietPNG.m
//  PhatHinhBaChieu
//
//  Created by 小小 on 17/3/2554.
//

#import "LuuHoaTietPNG.h"
#import "zlib.h"

#define kXAM         0x00   // xám
//#define kXAM_BANG   0x01   // xám bàng
//#define kRGB          0x02   // đỏ lục xanh
//#define kBANG_RGB  0x03   // bảng đỏ lục xanh
//#define kXAM_DUC        0x04   // xám đục
//#define kBANG_XAM_DUC  0x05   // bảng xám đục
#define kRGBO         0x06   // đỏ lục xanh đục
//#define kBANG_DUC      0x07   // bảng đục

#define kZLIB_MUC_NEN 6   // mức nén

#define kBE_DAI__THANH_PHAN_DAI_NHAT  16384  // bề dải thành phần IDAT lớn nhất

unsigned long crc_table[256];
   
   // cờ: đã tính bảng CRC chưa? Đầu tiên chưa tính.
int bang_crc_da_tinh = 0;

   // bảng cho tính mã CRC lẹ.
void tao_bang_crc(void) {
   unsigned long c;
   int n, k;
   
   for (n = 0; n < 256; n++) {
      c = (unsigned long) n;
      for (k = 0; k < 8; k++) {
         if (c & 1)
            c = 0xedb88320L ^ (c >> 1);  // 1110 1101 1011 1000 1000 0011 0010 0000
         else
            c = c >> 1;
      }
      crc_table[n] = c;
   }
   // ---- đặt đã tính rồi
   bang_crc_da_tinh = 1;
}

// Nâng cấp CRC đang chảy với byte trong buf[0..len-1]
// -- khi khởi động nên đặt toàn bộ mã CRC bằng bit 1, and the transmitted value
//	  is the 1s complement of the final running CRC (xem hàm crc() ở dưới)).
   
unsigned long nang_cap_crc(unsigned long crc, unsigned char *buf, int len) {

   unsigned long c = crc;
   int n;
   
   if (!bang_crc_da_tinh)
      tao_bang_crc();

   for (n = 0; n < len; n++) {
      c = crc_table[(c ^ buf[n]) & 0xff] ^ (c >> 8);
   }
     return c;
}
   
// Return the CRC of the bytes buf[0..len-1].
unsigned long crc(unsigned char *buf, int len) {
   return nang_cap_crc(0xffffffffL, buf, len) ^ 0xffffffffL;
}



@implementation LuuHoaTietPNG


// ======= THÀNH PHẦN ========
+ (void)kemThanhPhanIHDRChoDong:(NSMutableData *)dongTapTin beRong:(unsigned int)beRong
          beCao:(unsigned int)beCao loai:(unsigned char)loai
			 bitMoiKenh:(unsigned char)bitMoiKenh; {

   unsigned char thanh_phan_ihdr[25];
	 
   // ---- bề dài (số lượng byte) của dữ liệu thành phần
   thanh_phan_ihdr[0] = 0;
   thanh_phan_ihdr[1] = 0;
   thanh_phan_ihdr[2] = 0;
   thanh_phan_ihdr[3] = 13;
   // ---- mà thành phần
   thanh_phan_ihdr[4] = 'I';
   thanh_phan_ihdr[5] = 'H';
   thanh_phan_ihdr[6] = 'D';
   thanh_phan_ihdr[7] = 'R';
   // ---- bề rộng ảnh
   thanh_phan_ihdr[8] = (beRong & 0xff000000) >> 24;
   thanh_phan_ihdr[9] = (beRong & 0xff0000) >> 16;
   thanh_phan_ihdr[10] = (beRong & 0xff00) >> 8;
   thanh_phan_ihdr[11] = (beRong & 0xff);
   // ---- bề cao ảng
   thanh_phan_ihdr[12] = (beCao & 0xff000000) >> 24;
   thanh_phan_ihdr[13] = (beCao & 0xff0000) >> 16;
   thanh_phan_ihdr[14] = (beCao & 0xff00) >> 8;
   thanh_phan_ihdr[15] = (beCao & 0xff);
   // ---- số lượng bit cho mỗi kênh
   thanh_phan_ihdr[16] = bitMoiKenh;
   // ---- loại ảnh (RGB, RGBO, xám, v.v.)
   thanh_phan_ihdr[17] = loai;
   // ---- phương pháp nén
   thanh_phan_ihdr[18] = 0x00;  // chỉ có một phương pháp
   // ---- phương pháp lọc
   thanh_phan_ihdr[19] = 0x00;  // đổi theo dữ liệu hàng ảnh
   // ---- loại interlace
   thanh_phan_ihdr[20] = 0x00;  // không interlace
   
   // ---- tính mã kiểm tra
   unsigned int maKiemTra = (unsigned int)crc(&(thanh_phan_ihdr[4]), 17);
   thanh_phan_ihdr[21] = (maKiemTra & 0xff000000) >> 24;
   thanh_phan_ihdr[22] = (maKiemTra & 0xff0000) >> 16;
   thanh_phan_ihdr[23] = (maKiemTra & 0xff00) >> 8;
   thanh_phan_ihdr[24] = (maKiemTra & 0xff);
   
   [dongTapTin appendBytes:thanh_phan_ihdr length:25];
}

+ (void)kemThanhPhantIMEChoDong:(NSMutableData *)dongTapTin nam:(unsigned short)nam
         thang:(unsigned char)thang ngay:(unsigned char)ngay gio:(unsigned char)gio
			phut:(unsigned char)phut giay:(unsigned char)giay; {

   unsigned char thanhPhanThoiGian[19];  // chunk length, chunk type, chunk data, CRC
   // ---- bề dài (số lượng byte) của dữ liệu thành phần
   thanhPhanThoiGian[0] = 0;
   thanhPhanThoiGian[1] = 0;
   thanhPhanThoiGian[2] = 0;
   thanhPhanThoiGian[3] = 7;
   // ---- chunk type
   thanhPhanThoiGian[4] = 't';
   thanhPhanThoiGian[5] = 'I';
   thanhPhanThoiGian[6] = 'M';
   thanhPhanThoiGian[7] = 'E';
   // ---- năm
   thanhPhanThoiGian[8] = nam >> 8;
   thanhPhanThoiGian[9] = nam;
   // ---- tháng
   thanhPhanThoiGian[10] = thang;
   // ---- ngày
   thanhPhanThoiGian[11] = ngay;
   // ---- hour
   thanhPhanThoiGian[12] = giay;
   // ---- phút
   thanhPhanThoiGian[13] = phut;
   // ---- giây
   thanhPhanThoiGian[14] = giay;
   // ---- mã kiểm tra
   unsigned int maKiemTra = (unsigned int)crc(&(thanhPhanThoiGian[4]), 11);
   
   thanhPhanThoiGian[15] = (maKiemTra & 0xff000000) >> 24;
   thanhPhanThoiGian[16] = (maKiemTra & 0xff0000) >> 16;
   thanhPhanThoiGian[17] = (maKiemTra & 0xff00) >> 8;
   thanhPhanThoiGian[18] = (maKiemTra & 0xff);
   [dongTapTin appendBytes:thanhPhanThoiGian length:19];
}


+ (void)kemThanhPhanIENDChoDong:(NSMutableData *)dongTapTin; {

      unsigned char thanhPhan_iend[12];
      // ---- bề dài (số lượng byte) của dữ liệu thành phần (always zero)
      thanhPhan_iend[0] = 0;
      thanhPhan_iend[1] = 0;
      thanhPhan_iend[2] = 0;
      thanhPhan_iend[3] = 0;
      // ---- mã thàn phần (tên)
      thanhPhan_iend[4] = 'I';
      thanhPhan_iend[5] = 'E';
      thanhPhan_iend[6] = 'N';
      thanhPhan_iend[7] = 'D';

      thanhPhan_iend[8] = 0xae;
      thanhPhan_iend[9] = 0x42;
      thanhPhan_iend[10] = 0x60;
      thanhPhan_iend[11] = 0x82;

      [dongTapTin appendBytes:thanhPhan_iend length:12];
}


+ (void)kemThanhPhanIDATChoDong:(NSMutableData *)dongTapTin duLieuMauAnhNen:(unsigned char *)idat_chunkData
           beDaiDuLieuNen:(unsigned int)beDaiDuLieu; {

   unsigned int diaChiTrongDuLieu = 0;
   while ( diaChiTrongDuLieu < beDaiDuLieu ) {
      // ---- tên thành phần
      idat_chunkData[diaChiTrongDuLieu+4] = 'I';
      idat_chunkData[diaChiTrongDuLieu+5] = 'D';
      idat_chunkData[diaChiTrongDuLieu+6] = 'A';
      idat_chunkData[diaChiTrongDuLieu+7] = 'T';
      
      // ---- bề dài
      unsigned int beDai = 0;
      if( diaChiTrongDuLieu + kBE_DAI__THANH_PHAN_DAI_NHAT < beDaiDuLieu )
         beDai = kBE_DAI__THANH_PHAN_DAI_NHAT;
      else
         beDai = beDaiDuLieu - diaChiTrongDuLieu;
      
      idat_chunkData[diaChiTrongDuLieu] = (beDai >> 24) & 0xff;
      idat_chunkData[diaChiTrongDuLieu+1] = (beDai >> 16) & 0xff;
      idat_chunkData[diaChiTrongDuLieu+2] = (beDai >> 8) & 0xff;
      idat_chunkData[diaChiTrongDuLieu+3] = beDai & 0xff;
      
      [dongTapTin appendBytes:&(idat_chunkData[diaChiTrongDuLieu]) length:beDai+8];
      // ---- mã kiểm tra
		unsigned int maKiemTra = (unsigned int)crc( &(idat_chunkData[diaChiTrongDuLieu+4]), beDai+4 );
      unsigned char maKiemTraNguoc[4];
      maKiemTraNguoc[0] = (maKiemTra >> 24) & 0xff;
      maKiemTraNguoc[1] = (maKiemTra >> 16) & 0xff;
      maKiemTraNguoc[2] = (maKiemTra >> 8) & 0xff;
      maKiemTraNguoc[3] = maKiemTra & 0xff;
      
		[dongTapTin appendBytes:&maKiemTraNguoc length:4];
      
      diaChiTrongDuLieu += kBE_DAI__THANH_PHAN_DAI_NHAT;
   }

}


+ (void)kemThanhPhanzCHAChoDong:(NSMutableData *)dongTapTin duLieuSauNen:(unsigned char *)duLieuSauNen
           beDaiDuLieuNen:(unsigned int)beDaiDuLieuNen; {

      duLieuSauNen[0] = (beDaiDuLieuNen & 0xff000000) >> 24;
      duLieuSauNen[1] = (beDaiDuLieuNen & 0xff0000) >> 16;
      duLieuSauNen[2] = (beDaiDuLieuNen & 0xff00) >> 8;
      duLieuSauNen[3] = (beDaiDuLieuNen & 0xff);
        // ---- mã thành phần (tên)
      duLieuSauNen[4] = 'z';
      duLieuSauNen[5] = 'C';
      duLieuSauNen[6] = 'H';
      duLieuSauNen[7] = 'A';

      [dongTapTin appendBytes:duLieuSauNen length:beDaiDuLieuNen+8];
      // ---- mã kiểm tra
		unsigned int maKiemTra = (unsigned int)crc( &(duLieuSauNen[4]), beDaiDuLieuNen+4 );
		[dongTapTin appendBytes:&maKiemTra length:4];
}

// ===========================

+ (NSMutableData *)luuPNGVoiDuLieuIDAT:(unsigned char *)idat_chunkData
            beDaiDuLieuNen:(unsigned int)beDaiDuLieuNen
            beRong:(unsigned int )beRong beCao:(unsigned int )beCao
				bitMoiKenh:(unsigned char)bitMoiKenh loai:(unsigned char)loai; {

//   unsigned int maKiemTra;
   
   // ---- ký hiệu tấp tin PNG
   unsigned long int kyHieuTapTin = 0x0a1a0a0d474e5089;  // ngược cho intel;
   NSMutableData *dongDuLieuAnh = [NSMutableData dataWithBytes:&kyHieuTapTin length:8];

   // ---- kTHANH_PHAN__TYPE_IHDR
   [LuuHoaTietPNG kemThanhPhanIHDRChoDong:dongDuLieuAnh beRong:beRong beCao:beCao loai:loai bitMoiKenh:bitMoiKenh];
 
   // ---- kèm thông tin thời gian
   time_t thoiGian = time( NULL );
   struct tm *nganNay = localtime(&thoiGian);
   
   [LuuHoaTietPNG kemThanhPhantIMEChoDong:dongDuLieuAnh nam:nganNay->tm_year thang:nganNay->tm_mon ngay:nganNay->tm_mday gio:nganNay->tm_hour phut:nganNay->tm_min giay:nganNay->tm_sec];

   // ---- kLOAI_THANH_PHAN__IDAT    | + + + | + + + | + + kBE_DAI__THANH_PHAN_DAI_NHAT + + |
   [LuuHoaTietPNG kemThanhPhanIDATChoDong:dongDuLieuAnh duLieuMauAnhNen:idat_chunkData beDaiDuLieuNen:beDaiDuLieuNen];

   [LuuHoaTietPNG kemThanhPhanIENDChoDong:dongDuLieuAnh];
/*
   {
      // ---- add information to idat_chunkData
      // ---- bề dài (số lượng byte) của dữ liệu thành phần
      if( beDaiDuLieuNen > 8192 ) {
         idat_chunkData[0] = (beDaiDuLieuNen & 0xff000000) >> 24;
         idat_chunkData[1] = (beDaiDuLieuNen & 0xff0000) >> 16;
         idat_chunkData[2] = (beDaiDuLieuNen & 0xff00) >> 8;
         idat_chunkData[3] = (beDaiDuLieuNen & 0xff);
      }


      [dongDuLieuAnh appendBytes:idat_chunkData length:beDaiDuLieuNen+8];
		  // ---- crc
		maKiemTra = (unsigned int)crc( &(idat_chunkData[4]), beDaiDuLieuNen+4 );
		[dongDuLieuAnh appendBytes:&maKiemTra length:4];
   }
*/


//		[dongDuLieuAnh appendBytes:&maKiemTra length:4];
   NSLog( @"LuuHoaTietPNG" );
   return dongDuLieuAnh;
}


#pragma mark ---- Lọc Dữ Liệu Ảnh
// ---- LƯU Ý: nó lật ngược tậm ảnh 
+ (unsigned char *)locDuLieuAnh_32bit:(unsigned char *)duLieuAnh beRong:(unsigned short)beRong
                 beCao:(unsigned short)beCao beDaiDuLieuAnhLoc:(unsigned int *)beDaiDuLieuAnhLoc; {

   *beDaiDuLieuAnhLoc = (beRong*beCao << 2) + beCao;  // cần kèm một byte cho mỗi hàng (số bộ lọc cho hàng)
   unsigned char *duLieuAnhLoc = malloc( *beDaiDuLieuAnhLoc );

   unsigned short soHang = 0;  // số hàng
	unsigned int diaChiDuLieuLoc = 0;  // địa chỉ trong dữ liệu lọc
	unsigned int diaChiDuLieuAnh = beRong*(beCao - 1) << 2; // bắt đầu tại hàng cuối (lật ngược ảnh)
	unsigned char boLoc;   // số bộ lọc

	while( soHang < beCao ) {

      // ---- kiểm tra dữ liệu của mỗi hàng và quyết định dùng bộ lọc nào
      //           (không thể xài bộ lọc 2, 3, 4 cho hàng số 0, chỉ được xài loại 0 or 1)
      int tongSoBoLoc0 = 0;   // tổng số của mỗi byte trong hàng (cộng có dấu)
      int tongSoBoLoc1 = 0;   // tổng số sự khác của giữa byte này và 4 byte trước += b[n] - b[n-4]
      int tongSoBoLoc2 = 0;   // tổng số sự khác của giữa byte này và byte hàng trước += b[n] - b[n hàng trước]
      int tongSoBoLoc3 = 0;   //  += b[n] - (b[n hàng trước] + b[n-4])/2
      int tongSoBoLoc4 = 0;   // tổng số paeth
		
		if( soHang != 0 ) {  // chỉ dùng bộ lọc 0 cho hàng 0
          // ---- tổng số bộ lọc 0
         unsigned int soCot = 0;
         while( soCot < (beRong << 2) ) {  // nhân 4 vì có 4 byte cho một điềm ảnh
            tongSoBoLoc0 += (char)duLieuAnh[diaChiDuLieuAnh + soCot];
            tongSoBoLoc0 += (char)duLieuAnh[diaChiDuLieuAnh + soCot + 1];
            tongSoBoLoc0 += (char)duLieuAnh[diaChiDuLieuAnh + soCot + 2];
            tongSoBoLoc0 += (char)duLieuAnh[diaChiDuLieuAnh + soCot + 3];
            soCot += 4;
         }
			 // ---- tổng số bộ lọc 1
         tongSoBoLoc1 = (char)duLieuAnh[diaChiDuLieuAnh];
         tongSoBoLoc1 += (char)duLieuAnh[diaChiDuLieuAnh + 1];
         tongSoBoLoc1 += (char)duLieuAnh[diaChiDuLieuAnh + 2];
         tongSoBoLoc1 += (char)duLieuAnh[diaChiDuLieuAnh + 3];

		   soCot = 4;
			while( soCot < (beRong << 2) ) {
			   tongSoBoLoc1 += (char)((int)duLieuAnh[diaChiDuLieuAnh + soCot]
                    - (int)duLieuAnh[diaChiDuLieuAnh + soCot-4]) & 0xff;
			   tongSoBoLoc1 += (char)((int)duLieuAnh[diaChiDuLieuAnh + soCot+1]
				        - (int)duLieuAnh[diaChiDuLieuAnh + soCot-3]) & 0xff;
			   tongSoBoLoc1 += (char)((int)duLieuAnh[diaChiDuLieuAnh + soCot+2]
				        - (int)duLieuAnh[diaChiDuLieuAnh + soCot-2]) & 0xff;
			   tongSoBoLoc1 += (char)((int)duLieuAnh[diaChiDuLieuAnh + soCot+3]
				        - (int)duLieuAnh[diaChiDuLieuAnh + soCot-1]) & 0xff;
			   soCot += 4;
			};
         // ---- tổng số bộ lọc 2
		   unsigned int diaChiDuLieuAnhHangTruoc = diaChiDuLieuAnh + (beRong << 2);
		   soCot = 0;
			while( soCot < (beRong << 2) ) {
			   tongSoBoLoc2 += (char)((int)duLieuAnh[diaChiDuLieuAnh + soCot]
				        - (int)duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot]) & 0xff;
			   tongSoBoLoc2 += (char)((int)duLieuAnh[diaChiDuLieuAnh + soCot+1]
				        - (int)duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot+1]) & 0xff;
			   tongSoBoLoc2 += (char)((int)duLieuAnh[diaChiDuLieuAnh + soCot+2]
				        - (int)duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot+2]) & 0xff;
			   tongSoBoLoc2 += (char)((int)duLieuAnh[diaChiDuLieuAnh + soCot+3]
				        - (int)duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot+3]) & 0xff;
			   soCot += 4;
			};
         // ---- tổng số bộ lọc 3
		   diaChiDuLieuAnhHangTruoc = diaChiDuLieuAnh + (beRong << 2);
			// --- điểm ành đầu chỉ xài dữ liệu từ hàng ở trên (đừng xài >> 1 để chia 2, số nguyên có dấu)
         tongSoBoLoc3 = (char)((int)duLieuAnh[diaChiDuLieuAnh] - (int)(duLieuAnh[diaChiDuLieuAnhHangTruoc] / 2)) & 0xff;
         tongSoBoLoc3 += (char)((int)duLieuAnh[diaChiDuLieuAnh + 1] - (int)(duLieuAnh[diaChiDuLieuAnhHangTruoc+1] / 2)) & 0xff;
         tongSoBoLoc3 += (char)((int)duLieuAnh[diaChiDuLieuAnh + 2] - (int)(duLieuAnh[diaChiDuLieuAnhHangTruoc+2] / 2)) & 0xff;
         tongSoBoLoc3 += (char)((int)duLieuAnh[diaChiDuLieuAnh + 3] - (int)(duLieuAnh[diaChiDuLieuAnhHangTruoc+3] / 2)) & 0xff;

		   soCot = 4;
			while( soCot < (beRong << 2) ) {
			   tongSoBoLoc3 += (char)((int)duLieuAnh[diaChiDuLieuAnh + soCot] 
				                  - ((int)duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot] + (int)duLieuAnh[diaChiDuLieuAnh + soCot - 4]) / 2) & 0xff;
			   tongSoBoLoc3 += (char)((int)duLieuAnh[diaChiDuLieuAnh + soCot + 1]
				                  - ((int)duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot + 1] + (int)duLieuAnh[diaChiDuLieuAnh + soCot - 3]) / 2) & 0xff;
			   tongSoBoLoc3 += (char)((int)duLieuAnh[diaChiDuLieuAnh + soCot + 2]
				                  - ((int)duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot + 2] + (int)duLieuAnh[diaChiDuLieuAnh + soCot - 2]) / 2) & 0xff;
			   tongSoBoLoc3 += (char)((int)duLieuAnh[diaChiDuLieuAnh + soCot + 3]
				                  - ((int)duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot + 3] + (int)duLieuAnh[diaChiDuLieuAnh + soCot - 1]) / 2) & 0xff;
			   soCot += 4;
			}
         // ---- tổng số bộ lọc 4
		   diaChiDuLieuAnhHangTruoc = diaChiDuLieuAnh + (beRong << 2);
			// --- điểm ảnh đầu chỉ xài dữ liệu từ hàng ở trên
         tongSoBoLoc4 = (char)((int)duLieuAnh[diaChiDuLieuAnh] - (int)duLieuAnh[diaChiDuLieuAnhHangTruoc]) & 0xff;
         tongSoBoLoc4 += (char)((int)duLieuAnh[diaChiDuLieuAnh + 1] - (int)duLieuAnh[diaChiDuLieuAnhHangTruoc+1]) & 0xff;
         tongSoBoLoc4 += (char)((int)duLieuAnh[diaChiDuLieuAnh + 2] - (int)duLieuAnh[diaChiDuLieuAnhHangTruoc+2]) & 0xff;
         tongSoBoLoc4 += (char)((int)duLieuAnh[diaChiDuLieuAnh + 3] - (int)duLieuAnh[diaChiDuLieuAnhHangTruoc+3]) & 0xff;

		   soCot = 4;
			int a;
			int b;
			int c;
         // ---- dự đoán
			int duDoan;
			int duDoanA;
			int duDoanB;
			int duDoanC;

			while( soCot < (beRong << 2) ) {
			   a = duLieuAnh[diaChiDuLieuAnh + soCot - 4];
			   b = duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot];
			   c = duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot - 4];

            duDoan = b - c;
				duDoanC = a - c;
//				duDoanA = duDoan < 0 ? -duDoan : duDoan;
//				duDoanB = duDoanC < 0 ? -duDoanC : duDoanC;
//				duDoanC = (duDoan + duDoanC) < 0 ? -(duDoan + duDoanC) : duDoan + duDoanC;

				duDoanA = abs(duDoan);
				duDoanB = abs(duDoanC);
				duDoanC = abs(duDoan + duDoanC);

            duDoan = (duDoanA <= duDoanB && duDoanA <= duDoanC) ? a : (duDoanB <= duDoanC) ? b : c;

			   tongSoBoLoc4 += (char)((int)duLieuAnh[diaChiDuLieuAnh + soCot] - duDoan) & 0xff;
			   soCot ++;
         }

			// ---- giá trị tuyệt đối của việc cộng
			if( tongSoBoLoc0 < 0 )
			   tongSoBoLoc0 = -tongSoBoLoc0;
			if( tongSoBoLoc1 < 0 )
			   tongSoBoLoc1 = -tongSoBoLoc1;
			if( tongSoBoLoc2 < 0 )
			   tongSoBoLoc2 = -tongSoBoLoc2;
			if( tongSoBoLoc3 < 0 )
			   tongSoBoLoc3 = -tongSoBoLoc3;
			if( tongSoBoLoc4 < 0 )
			   tongSoBoLoc4 = -tongSoBoLoc4;

         // ---- tìm giá trị bộ lọc nào nhỏ nhất
			boLoc = 0;
			unsigned int boLocNhoNhat = tongSoBoLoc0;
			if( tongSoBoLoc1 < boLocNhoNhat ) {
			   boLoc = 1;
				boLocNhoNhat = tongSoBoLoc1;
         }
         if( tongSoBoLoc2 < boLocNhoNhat ) {
			   boLoc = 2;
				boLocNhoNhat = tongSoBoLoc2;
         }
         if( tongSoBoLoc3 < boLocNhoNhat ) {
			   boLoc = 3;
				boLocNhoNhat = tongSoBoLoc3;
         }
         if( tongSoBoLoc4 < boLocNhoNhat ) {
			   boLoc = 4;
         }
      }
      else {
         boLoc = 0;
		}
//      NSLog( @"LuuHoaTietPNG: locDuLieuAnh_32bitsố bộ lọc: %d", boLoc );
	   // ---- byte đầu là số bộ lọc (loại bộ lọc)
	   duLieuAnhLoc[diaChiDuLieuLoc] = boLoc;
		// ---- byte tiếp là byte đầu của dữ liệu lọc
		diaChiDuLieuLoc++;

      if( boLoc == 0 ) {  // ---- không lọc, chỉ chép dữ liệu
		   unsigned int soCot = 0;
			while( soCot < (beRong << 2) ) {
			   duLieuAnhLoc[diaChiDuLieuLoc + soCot] = duLieuAnh[diaChiDuLieuAnh + soCot];
			   duLieuAnhLoc[diaChiDuLieuLoc + soCot + 1] = duLieuAnh[diaChiDuLieuAnh + soCot + 1];
			   duLieuAnhLoc[diaChiDuLieuLoc + soCot + 2] = duLieuAnh[diaChiDuLieuAnh + soCot + 2];
			   duLieuAnhLoc[diaChiDuLieuLoc + soCot + 3] = duLieuAnh[diaChiDuLieuAnh + soCot + 3];
			   soCot += 4;
			}
      }
		else if( boLoc == 1 ) {  // ---- bộ lọc trừ
			// ---- chép dữ liệu điểm ảnh
         duLieuAnhLoc[diaChiDuLieuLoc] = duLieuAnh[diaChiDuLieuAnh];
         duLieuAnhLoc[diaChiDuLieuLoc + 1] = duLieuAnh[diaChiDuLieuAnh + 1];
         duLieuAnhLoc[diaChiDuLieuLoc + 2] = duLieuAnh[diaChiDuLieuAnh + 2];
         duLieuAnhLoc[diaChiDuLieuLoc + 3] = duLieuAnh[diaChiDuLieuAnh + 3];

		   unsigned int soCot = 4;
			while( soCot < (beRong << 2) ) {
			   duLieuAnhLoc[diaChiDuLieuLoc + soCot] = ((int)duLieuAnh[diaChiDuLieuAnh + soCot]
                    - (int)duLieuAnh[diaChiDuLieuAnh + soCot-4]) & 0xff;
			   duLieuAnhLoc[diaChiDuLieuLoc + soCot+1] = ((int)duLieuAnh[diaChiDuLieuAnh + soCot+1]
				        - (int)duLieuAnh[diaChiDuLieuAnh + soCot-3]) & 0xff;
			   duLieuAnhLoc[diaChiDuLieuLoc + soCot+2] = ((int)duLieuAnh[diaChiDuLieuAnh + soCot+2]
				        - (int)duLieuAnh[diaChiDuLieuAnh + soCot-2]) & 0xff;
			   duLieuAnhLoc[diaChiDuLieuLoc + soCot+3] = ((int)duLieuAnh[diaChiDuLieuAnh + soCot+3]
				        - (int)duLieuAnh[diaChiDuLieuAnh + soCot-1]) & 0xff;
			   soCot += 4;
			};
		}
		else if( boLoc == 2 ) {  // ---- bộ lọc lên
		   unsigned int diaChiDuLieuAnhHangTruoc = diaChiDuLieuAnh + (beRong << 2);
		   unsigned int soCot = 0;
			while( soCot < (beRong << 2) ) {
			   duLieuAnhLoc[diaChiDuLieuLoc + soCot] = ((int)duLieuAnh[diaChiDuLieuAnh + soCot]
				        - (int)duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot]) & 0xff;
			   duLieuAnhLoc[diaChiDuLieuLoc + soCot+1] = ((int)duLieuAnh[diaChiDuLieuAnh + soCot+1]
				        - (int)duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot+1]) & 0xff;
			   duLieuAnhLoc[diaChiDuLieuLoc + soCot+2] = ((int)duLieuAnh[diaChiDuLieuAnh + soCot+2]
				        - (int)duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot+2]) & 0xff;
			   duLieuAnhLoc[diaChiDuLieuLoc + soCot+3] = ((int)duLieuAnh[diaChiDuLieuAnh + soCot+3]
				        - (int)duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot+3]) & 0xff;
			   soCot += 4;
			};
		}
		else if( boLoc == 3 ) {  // ---- bộ lọc trung bình
		   unsigned int diaChiDuLieuAnhHangTruoc = diaChiDuLieuAnh + (beRong << 2);
			// --- điểm ành đầu chỉ xài dữ liệu từ hàng ở trên
         // LƯU Ý: đừng dùng >> 1 để chia 2, int có dấu)
         duLieuAnhLoc[diaChiDuLieuLoc] = ((int)duLieuAnh[diaChiDuLieuAnh] - (int)(duLieuAnh[diaChiDuLieuAnhHangTruoc] / 2)) & 0xff;
         duLieuAnhLoc[diaChiDuLieuLoc+1] = ((int)duLieuAnh[diaChiDuLieuAnh + 1] - (int)(duLieuAnh[diaChiDuLieuAnhHangTruoc+1] / 2)) & 0xff;
         duLieuAnhLoc[diaChiDuLieuLoc+2] = ((int)duLieuAnh[diaChiDuLieuAnh + 2] - (int)(duLieuAnh[diaChiDuLieuAnhHangTruoc+2] / 2)) & 0xff;
         duLieuAnhLoc[diaChiDuLieuLoc+3] = ((int)duLieuAnh[diaChiDuLieuAnh + 3] - (int)(duLieuAnh[diaChiDuLieuAnhHangTruoc+3] / 2)) & 0xff;

		   unsigned int soCot = 4;
			while( soCot < (beRong << 2) ) {
			   duLieuAnhLoc[diaChiDuLieuLoc + soCot] = ((int)duLieuAnh[diaChiDuLieuAnh + soCot] 
				                  - ((int)duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot] + (int)duLieuAnh[diaChiDuLieuAnh + soCot - 4]) / 2) & 0xff;
			   duLieuAnhLoc[diaChiDuLieuLoc + soCot + 1] = ((int)duLieuAnh[diaChiDuLieuAnh + soCot + 1]
				                  - ((int)duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot + 1] + (int)duLieuAnh[diaChiDuLieuAnh + soCot - 3]) / 2) & 0xff;
			   duLieuAnhLoc[diaChiDuLieuLoc + soCot + 2] = ((int)duLieuAnh[diaChiDuLieuAnh + soCot + 2]
				                  - ((int)duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot + 2] + (int)duLieuAnh[diaChiDuLieuAnh + soCot - 2]) / 2) & 0xff;
			   duLieuAnhLoc[diaChiDuLieuLoc + soCot + 3] = ((int)duLieuAnh[diaChiDuLieuAnh + soCot + 3]
				                  - ((int)duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot + 3] + (int)duLieuAnh[diaChiDuLieuAnh + soCot - 1]) / 2) & 0xff;
			   soCot += 4;
			}
      }
		else if( boLoc == 4 ) {  // ---- bộ lọc paeth
		   unsigned int diaChiDuLieuAnhHangTruoc = diaChiDuLieuAnh + (beRong << 2);
			// --- điểm ảnh đầu tiên của hàng chỉ xài dữ liệu từ điểm ảnh ở hàng trên
         duLieuAnhLoc[diaChiDuLieuLoc] = ((int)duLieuAnh[diaChiDuLieuAnh] - (int)duLieuAnh[diaChiDuLieuAnhHangTruoc]) & 0xff;
         duLieuAnhLoc[diaChiDuLieuLoc+1] = ((int)duLieuAnh[diaChiDuLieuAnh + 1] - (int)duLieuAnh[diaChiDuLieuAnhHangTruoc+1]) & 0xff;
         duLieuAnhLoc[diaChiDuLieuLoc+2] = ((int)duLieuAnh[diaChiDuLieuAnh + 2] - (int)duLieuAnh[diaChiDuLieuAnhHangTruoc+2]) & 0xff;
         duLieuAnhLoc[diaChiDuLieuLoc+3] = ((int)duLieuAnh[diaChiDuLieuAnh + 3] - (int)duLieuAnh[diaChiDuLieuAnhHangTruoc+3]) & 0xff;

		   unsigned int soCot = 4;
			int a;
			int b;
			int c;
			int duDoan;   // dự đoán
			int duDoanA;  // dự đoán A
			int duDoanB;  // dự đoán B
			int duDoanC;  // dự đoán C

			while( soCot < (beRong << 2) ) {
			   a = duLieuAnh[diaChiDuLieuAnh + soCot - 4];
			   b = duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot];
			   c = duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot - 4];

            duDoan = b - c;
				duDoanC = a - c;
//				duDoanA = duDoan < 0 ? -duDoan : duDoan;
//				duDoanB = duDoanC < 0 ? -duDoanC : duDoanC;
//				duDoanC = (duDoan + duDoanC) < 0 ? -(duDoan + duDoanC) : duDoan + duDoanC;

				duDoanA = abs(duDoan);
				duDoanB = abs(duDoanC);
				duDoanC = abs(duDoan + duDoanC);

            duDoan = (duDoanA <= duDoanB && duDoanA <= duDoanC) ? a : (duDoanB <= duDoanC) ? b : c;

			   duLieuAnhLoc[diaChiDuLieuLoc + soCot] = ((int)duLieuAnh[diaChiDuLieuAnh + soCot] - duDoan) & 0xff;
			   soCot++;
         }
		}
		else {   // ---- loại lọc không biết
		   ; 
		}
      // ---- chuần bị cho hàng tiếp
		soHang++;
		diaChiDuLieuLoc += (beRong << 2);
		diaChiDuLieuAnh -= (beRong << 2);
   }

   return duLieuAnhLoc;
}


// ---- LƯU Ý: nó lật ngược tậm ảnh
+ (unsigned char *)locDuLieuAnh_64bit:(unsigned char *)duLieuAnh beRong:(unsigned short)beRong
                                beCao:(unsigned short)beCao beDaiDuLieuAnhLoc:(unsigned int *)beDaiDuLieuAnhLoc; {
   
   *beDaiDuLieuAnhLoc = (beRong*beCao << 3) + beCao;  // cần kèm một byte cho mỗi hàng (số bộ lọc cho hàng)
   unsigned char *duLieuAnhLoc = malloc( *beDaiDuLieuAnhLoc );
   
   unsigned short soHang = 0;  // số hàng
	unsigned int diaChiDuLieuLoc = 0;  // địa chỉ trong dữ liệu lọc
	unsigned int diaChiDuLieuAnh = beRong*(beCao - 1) << 3; // bắt đầu tại hàng cuối (lật ngược ảnh)
	unsigned char boLoc;   // số bộ lọc
   
	while( soHang < beCao ) {
      
      // ---- kiểm tra dữ liệu của mỗi hàng và quyết định dùng bộ lọc nào
      //           (không thể xài bộ lọc 2, 3, 4 cho hàng số 0, chỉ được xài loại 0 or 1)
      int tongSoBoLoc0 = 0;   // tổng số của mỗi byte trong hàng (cộng có dấu)
      int tongSoBoLoc1 = 0;   // tổng số sự khác của giữa byte này và 4 byte trước += b[n] - b[n-8]
      int tongSoBoLoc2 = 0;   // tổng số sự khác của giữa byte này và byte hàng trước += b[n] - b[n hàng trước]
      int tongSoBoLoc3 = 0;   //  += b[n] - (b[n hàng trước] + b[n-8])/2
      int tongSoBoLoc4 = 0;   // tổng số paeth
		
		if( soHang != 0 ) {  // chỉ dùng bộ lọc 0 cho hàng 0
         // ---- tổng số bộ lọc 0
         unsigned int soCot = 0;
         while( soCot < (beRong << 3) ) {  // nhân 8 vì có 8 byte cho một điềm ảnh
            tongSoBoLoc0 += (char)duLieuAnh[diaChiDuLieuAnh + soCot];
            tongSoBoLoc0 += (char)duLieuAnh[diaChiDuLieuAnh + soCot + 1];
            tongSoBoLoc0 += (char)duLieuAnh[diaChiDuLieuAnh + soCot + 2];
            tongSoBoLoc0 += (char)duLieuAnh[diaChiDuLieuAnh + soCot + 3];
            soCot += 4;
         }
         // ---- tổng số bộ lọc 1
         tongSoBoLoc1 = (char)duLieuAnh[diaChiDuLieuAnh];
         tongSoBoLoc1 += (char)duLieuAnh[diaChiDuLieuAnh + 1];
         tongSoBoLoc1 += (char)duLieuAnh[diaChiDuLieuAnh + 2];
         tongSoBoLoc1 += (char)duLieuAnh[diaChiDuLieuAnh + 3];
         tongSoBoLoc1 += (char)duLieuAnh[diaChiDuLieuAnh + 4];
         tongSoBoLoc1 += (char)duLieuAnh[diaChiDuLieuAnh + 5];
         tongSoBoLoc1 += (char)duLieuAnh[diaChiDuLieuAnh + 6];
         tongSoBoLoc1 += (char)duLieuAnh[diaChiDuLieuAnh + 7];
   
		   soCot = 8;
			while( soCot < (beRong << 3) ) {
			   tongSoBoLoc1 += (char)((int)duLieuAnh[diaChiDuLieuAnh + soCot]
                                   - (int)duLieuAnh[diaChiDuLieuAnh + soCot-8]) & 0xff;
			   tongSoBoLoc1 += (char)((int)duLieuAnh[diaChiDuLieuAnh + soCot+1]
                                   - (int)duLieuAnh[diaChiDuLieuAnh + soCot-7]) & 0xff;
			   tongSoBoLoc1 += (char)((int)duLieuAnh[diaChiDuLieuAnh + soCot+2]
                                   - (int)duLieuAnh[diaChiDuLieuAnh + soCot-6]) & 0xff;
			   tongSoBoLoc1 += (char)((int)duLieuAnh[diaChiDuLieuAnh + soCot+3]
                                   - (int)duLieuAnh[diaChiDuLieuAnh + soCot-5]) & 0xff;
			   tongSoBoLoc1 += (char)((int)duLieuAnh[diaChiDuLieuAnh + soCot+4]
                                   - (int)duLieuAnh[diaChiDuLieuAnh + soCot-4]) & 0xff;
			   tongSoBoLoc1 += (char)((int)duLieuAnh[diaChiDuLieuAnh + soCot+5]
                                   - (int)duLieuAnh[diaChiDuLieuAnh + soCot-3]) & 0xff;
			   tongSoBoLoc1 += (char)((int)duLieuAnh[diaChiDuLieuAnh + soCot+6]
                                   - (int)duLieuAnh[diaChiDuLieuAnh + soCot-2]) & 0xff;
			   tongSoBoLoc1 += (char)((int)duLieuAnh[diaChiDuLieuAnh + soCot+7]
                                   - (int)duLieuAnh[diaChiDuLieuAnh + soCot-1]) & 0xff;
			   soCot += 8;
			};
         // ---- tổng số bộ lọc 2
		   unsigned int diaChiDuLieuAnhHangTruoc = diaChiDuLieuAnh + (beRong << 3);
		   soCot = 0;
			while( soCot < (beRong << 3) ) {
			   tongSoBoLoc2 += (char)((int)duLieuAnh[diaChiDuLieuAnh + soCot]
                                   - (int)duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot]) & 0xff;
			   tongSoBoLoc2 += (char)((int)duLieuAnh[diaChiDuLieuAnh + soCot+1]
                                   - (int)duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot+1]) & 0xff;
			   tongSoBoLoc2 += (char)((int)duLieuAnh[diaChiDuLieuAnh + soCot+2]
                                   - (int)duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot+2]) & 0xff;
			   tongSoBoLoc2 += (char)((int)duLieuAnh[diaChiDuLieuAnh + soCot+3]
                                   - (int)duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot+3]) & 0xff;
			   soCot += 4;
			};
         // ---- tổng số bộ lọc 3
		   diaChiDuLieuAnhHangTruoc = diaChiDuLieuAnh + (beRong << 3);
			// --- điểm ành đầu chỉ xài dữ liệu từ hàng ở trên (đừng xài >> 1 fđể chia 2,  int có dấu)
         tongSoBoLoc3 = (char)((int)duLieuAnh[diaChiDuLieuAnh] - (int)(duLieuAnh[diaChiDuLieuAnhHangTruoc] / 2)) & 0xff;
         tongSoBoLoc3 += (char)((int)duLieuAnh[diaChiDuLieuAnh + 1] - (int)(duLieuAnh[diaChiDuLieuAnhHangTruoc+1] / 2)) & 0xff;
         tongSoBoLoc3 += (char)((int)duLieuAnh[diaChiDuLieuAnh + 2] - (int)(duLieuAnh[diaChiDuLieuAnhHangTruoc+2] / 2)) & 0xff;
         tongSoBoLoc3 += (char)((int)duLieuAnh[diaChiDuLieuAnh + 3] - (int)(duLieuAnh[diaChiDuLieuAnhHangTruoc+3] / 2)) & 0xff;
         tongSoBoLoc3 += (char)((int)duLieuAnh[diaChiDuLieuAnh + 4] - (int)(duLieuAnh[diaChiDuLieuAnhHangTruoc+4] / 2)) & 0xff;
         tongSoBoLoc3 += (char)((int)duLieuAnh[diaChiDuLieuAnh + 5] - (int)(duLieuAnh[diaChiDuLieuAnhHangTruoc+5] / 2)) & 0xff;
         tongSoBoLoc3 += (char)((int)duLieuAnh[diaChiDuLieuAnh + 6] - (int)(duLieuAnh[diaChiDuLieuAnhHangTruoc+6] / 2)) & 0xff;
         tongSoBoLoc3 += (char)((int)duLieuAnh[diaChiDuLieuAnh + 7] - (int)(duLieuAnh[diaChiDuLieuAnhHangTruoc+7] / 2)) & 0xff;

		   soCot = 8;
			while( soCot < (beRong << 3) ) {
			   tongSoBoLoc3 += (char)((int)duLieuAnh[diaChiDuLieuAnh + soCot]
                                   - ((int)duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot] + (int)duLieuAnh[diaChiDuLieuAnh + soCot - 8]) / 2) & 0xff;
			   tongSoBoLoc3 += (char)((int)duLieuAnh[diaChiDuLieuAnh + soCot + 1]
                                   - ((int)duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot + 1] + (int)duLieuAnh[diaChiDuLieuAnh + soCot - 7]) / 2) & 0xff;
			   tongSoBoLoc3 += (char)((int)duLieuAnh[diaChiDuLieuAnh + soCot + 2]
                                   - ((int)duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot + 2] + (int)duLieuAnh[diaChiDuLieuAnh + soCot - 6]) / 2) & 0xff;
			   tongSoBoLoc3 += (char)((int)duLieuAnh[diaChiDuLieuAnh + soCot + 3]
                                   - ((int)duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot + 3] + (int)duLieuAnh[diaChiDuLieuAnh + soCot - 5]) / 2) & 0xff;
			   tongSoBoLoc3 += (char)((int)duLieuAnh[diaChiDuLieuAnh + soCot + 4]
                                   - ((int)duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot] + (int)duLieuAnh[diaChiDuLieuAnh + soCot - 4]) / 2) & 0xff;
			   tongSoBoLoc3 += (char)((int)duLieuAnh[diaChiDuLieuAnh + soCot + 5]
                                   - ((int)duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot + 1] + (int)duLieuAnh[diaChiDuLieuAnh + soCot - 3]) / 2) & 0xff;
			   tongSoBoLoc3 += (char)((int)duLieuAnh[diaChiDuLieuAnh + soCot + 6]
                                   - ((int)duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot + 2] + (int)duLieuAnh[diaChiDuLieuAnh + soCot - 2]) / 2) & 0xff;
			   tongSoBoLoc3 += (char)((int)duLieuAnh[diaChiDuLieuAnh + soCot + 7]
                                   - ((int)duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot + 3] + (int)duLieuAnh[diaChiDuLieuAnh + soCot - 1]) / 2) & 0xff;
			   soCot += 8;
			}
         // ---- tổng số bộ lọc 4
		   diaChiDuLieuAnhHangTruoc = diaChiDuLieuAnh + (beRong << 3);
			// --- điểm ảnh đầu chỉ xài dữ liệu từ hàng ở trên
         tongSoBoLoc4 = (char)((int)duLieuAnh[diaChiDuLieuAnh] - (int)duLieuAnh[diaChiDuLieuAnhHangTruoc]) & 0xff;
         tongSoBoLoc4 += (char)((int)duLieuAnh[diaChiDuLieuAnh + 1] - (int)duLieuAnh[diaChiDuLieuAnhHangTruoc+1]) & 0xff;
         tongSoBoLoc4 += (char)((int)duLieuAnh[diaChiDuLieuAnh + 2] - (int)duLieuAnh[diaChiDuLieuAnhHangTruoc+2]) & 0xff;
         tongSoBoLoc4 += (char)((int)duLieuAnh[diaChiDuLieuAnh + 3] - (int)duLieuAnh[diaChiDuLieuAnhHangTruoc+3]) & 0xff;
         tongSoBoLoc4 += (char)((int)duLieuAnh[diaChiDuLieuAnh + 4] - (int)duLieuAnh[diaChiDuLieuAnhHangTruoc+4]) & 0xff;
         tongSoBoLoc4 += (char)((int)duLieuAnh[diaChiDuLieuAnh + 5] - (int)duLieuAnh[diaChiDuLieuAnhHangTruoc+5]) & 0xff;
         tongSoBoLoc4 += (char)((int)duLieuAnh[diaChiDuLieuAnh + 6] - (int)duLieuAnh[diaChiDuLieuAnhHangTruoc+6]) & 0xff;
         tongSoBoLoc4 += (char)((int)duLieuAnh[diaChiDuLieuAnh + 7] - (int)duLieuAnh[diaChiDuLieuAnhHangTruoc+7]) & 0xff;
         
		   soCot = 8;
			int a;
			int b;
			int c;
			int duDoan;
			int duDoanA;
			int duDoanB;
			int duDoanC;
         
			while( soCot < (beRong << 3) ) {
			   a = duLieuAnh[diaChiDuLieuAnh + soCot - 8];
			   b = duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot];
			   c = duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot - 8];
            
            duDoan = b - c;
				duDoanC = a - c;
            //				duDoanA = duDoan < 0 ? -duDoan : duDoan;
            //				duDoanB = duDoanC < 0 ? -duDoanC : duDoanC;
            //				duDoanC = (duDoan + duDoanC) < 0 ? -(duDoan + duDoanC) : duDoan + duDoanC;
            
				duDoanA = abs(duDoan);
				duDoanB = abs(duDoanC);
				duDoanC = abs(duDoan + duDoanC);
            
            duDoan = (duDoanA <= duDoanB && duDoanA <= duDoanC) ? a : (duDoanB <= duDoanC) ? b : c;
            
			   tongSoBoLoc4 += (char)((int)duLieuAnh[diaChiDuLieuAnh + soCot] - duDoan) & 0xff;
			   soCot++;
         }

			// ---- giá trị tuyệt đối của việc cộng
			if( tongSoBoLoc0 < 0 )
			   tongSoBoLoc0 = -tongSoBoLoc0;
			if( tongSoBoLoc1 < 0 )
			   tongSoBoLoc1 = -tongSoBoLoc1;
			if( tongSoBoLoc2 < 0 )
			   tongSoBoLoc2 = -tongSoBoLoc2;
			if( tongSoBoLoc3 < 0 )
			   tongSoBoLoc3 = -tongSoBoLoc3;
			if( tongSoBoLoc4 < 0 )
			   tongSoBoLoc4 = -tongSoBoLoc4;
         
         // ---- tìm giá trị bộ lọc nào nhỏ nhất
			boLoc = 0;
			unsigned int boLocNhoNhat = tongSoBoLoc0;
			if( tongSoBoLoc1 < boLocNhoNhat ) {
			   boLoc = 1;
				boLocNhoNhat = tongSoBoLoc1;
         }
         if( tongSoBoLoc2 < boLocNhoNhat ) {
			   boLoc = 2;
				boLocNhoNhat = tongSoBoLoc2;
         }
         if( tongSoBoLoc3 < boLocNhoNhat ) {
			   boLoc = 3;
				boLocNhoNhat = tongSoBoLoc3;
         }
         if( tongSoBoLoc4 < boLocNhoNhat ) {
			   boLoc = 4;
         }
      }
      else {
         boLoc = 0;
		}

      //      NSLog( @"LuuHoaTietPNG: locDuLieuAnh_64bitsố bộ lọc: %d", boLoc );
	   // ---- byte đầu là số bộ lọc (loại bộ lọc)
	   duLieuAnhLoc[diaChiDuLieuLoc] = boLoc;
		// ---- byte tiếp là byte đầu của dữ liệu lọc
		diaChiDuLieuLoc++;
      
      if( boLoc == 0 ) {  // ---- không lọc, chỉ chép dữ liệu
		   unsigned int soCot = 0;
			while( soCot < (beRong << 3) ) {
			   duLieuAnhLoc[diaChiDuLieuLoc + soCot] = duLieuAnh[diaChiDuLieuAnh + soCot];
			   duLieuAnhLoc[diaChiDuLieuLoc + soCot + 1] = duLieuAnh[diaChiDuLieuAnh + soCot + 1];
			   duLieuAnhLoc[diaChiDuLieuLoc + soCot + 2] = duLieuAnh[diaChiDuLieuAnh + soCot + 2];
			   duLieuAnhLoc[diaChiDuLieuLoc + soCot + 3] = duLieuAnh[diaChiDuLieuAnh + soCot + 3];
			   duLieuAnhLoc[diaChiDuLieuLoc + soCot + 4] = duLieuAnh[diaChiDuLieuAnh + soCot + 4];
			   duLieuAnhLoc[diaChiDuLieuLoc + soCot + 5] = duLieuAnh[diaChiDuLieuAnh + soCot + 5];
			   duLieuAnhLoc[diaChiDuLieuLoc + soCot + 6] = duLieuAnh[diaChiDuLieuAnh + soCot + 6];
			   duLieuAnhLoc[diaChiDuLieuLoc + soCot + 7] = duLieuAnh[diaChiDuLieuAnh + soCot + 7];
			   soCot += 8;
			}
      }
		else if( boLoc == 1 ) {  // ---- bộ lọc trừ
			// ---- chép dữ liệu điểm ảnh
         duLieuAnhLoc[diaChiDuLieuLoc] = duLieuAnh[diaChiDuLieuAnh];
         duLieuAnhLoc[diaChiDuLieuLoc + 1] = duLieuAnh[diaChiDuLieuAnh + 1];
         duLieuAnhLoc[diaChiDuLieuLoc + 2] = duLieuAnh[diaChiDuLieuAnh + 2];
         duLieuAnhLoc[diaChiDuLieuLoc + 3] = duLieuAnh[diaChiDuLieuAnh + 3];
         duLieuAnhLoc[diaChiDuLieuLoc + 4] = duLieuAnh[diaChiDuLieuAnh + 4];
         duLieuAnhLoc[diaChiDuLieuLoc + 5] = duLieuAnh[diaChiDuLieuAnh + 5];
         duLieuAnhLoc[diaChiDuLieuLoc + 6] = duLieuAnh[diaChiDuLieuAnh + 6];
         duLieuAnhLoc[diaChiDuLieuLoc + 7] = duLieuAnh[diaChiDuLieuAnh + 7];
         
		   unsigned int soCot = 8;
			while( soCot < (beRong << 3) ) {
			   duLieuAnhLoc[diaChiDuLieuLoc + soCot] = ((int)duLieuAnh[diaChiDuLieuAnh + soCot]
                                                     - (int)duLieuAnh[diaChiDuLieuAnh + soCot-8]) & 0xff;
			   duLieuAnhLoc[diaChiDuLieuLoc + soCot+1] = ((int)duLieuAnh[diaChiDuLieuAnh + soCot+1]
                                                       - (int)duLieuAnh[diaChiDuLieuAnh + soCot-7]) & 0xff;
			   duLieuAnhLoc[diaChiDuLieuLoc + soCot+2] = ((int)duLieuAnh[diaChiDuLieuAnh + soCot+2]
                                                       - (int)duLieuAnh[diaChiDuLieuAnh + soCot-6]) & 0xff;
			   duLieuAnhLoc[diaChiDuLieuLoc + soCot+3] = ((int)duLieuAnh[diaChiDuLieuAnh + soCot+3]
                                                       - (int)duLieuAnh[diaChiDuLieuAnh + soCot-5]) & 0xff;
			   duLieuAnhLoc[diaChiDuLieuLoc + soCot+4] = ((int)duLieuAnh[diaChiDuLieuAnh + soCot+4]
                                                     - (int)duLieuAnh[diaChiDuLieuAnh + soCot-4]) & 0xff;
			   duLieuAnhLoc[diaChiDuLieuLoc + soCot+5] = ((int)duLieuAnh[diaChiDuLieuAnh + soCot+5]
                                                       - (int)duLieuAnh[diaChiDuLieuAnh + soCot-3]) & 0xff;
			   duLieuAnhLoc[diaChiDuLieuLoc + soCot+6] = ((int)duLieuAnh[diaChiDuLieuAnh + soCot+6]
                                                       - (int)duLieuAnh[diaChiDuLieuAnh + soCot-2]) & 0xff;
			   duLieuAnhLoc[diaChiDuLieuLoc + soCot+7] = ((int)duLieuAnh[diaChiDuLieuAnh + soCot+7]
                                                       - (int)duLieuAnh[diaChiDuLieuAnh + soCot-1]) & 0xff;

			   soCot += 8;
			};
		}
		else if( boLoc == 2 ) {  // ---- bộ lọc lên
		   unsigned int diaChiDuLieuAnhHangTruoc = diaChiDuLieuAnh + (beRong << 3);
		   unsigned int soCot = 0;
			while( soCot < (beRong << 3) ) {
			   duLieuAnhLoc[diaChiDuLieuLoc + soCot] = ((int)duLieuAnh[diaChiDuLieuAnh + soCot]
                                                       - (int)duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot]) & 0xff;
			   duLieuAnhLoc[diaChiDuLieuLoc + soCot+1] = ((int)duLieuAnh[diaChiDuLieuAnh + soCot+1]
                                                       - (int)duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot+1]) & 0xff;
			   duLieuAnhLoc[diaChiDuLieuLoc + soCot+2] = ((int)duLieuAnh[diaChiDuLieuAnh + soCot+2]
                                                       - (int)duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot+2]) & 0xff;
			   duLieuAnhLoc[diaChiDuLieuLoc + soCot+3] = ((int)duLieuAnh[diaChiDuLieuAnh + soCot+3]
                                                       - (int)duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot+3]) & 0xff;
			   duLieuAnhLoc[diaChiDuLieuLoc + soCot+4] = ((int)duLieuAnh[diaChiDuLieuAnh + soCot+4]
                                                       - (int)duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot+4]) & 0xff;
			   duLieuAnhLoc[diaChiDuLieuLoc + soCot+5] = ((int)duLieuAnh[diaChiDuLieuAnh + soCot+5]
                                                       - (int)duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot+5]) & 0xff;
			   duLieuAnhLoc[diaChiDuLieuLoc + soCot+6] = ((int)duLieuAnh[diaChiDuLieuAnh + soCot+6]
                                                       - (int)duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot+6]) & 0xff;
			   duLieuAnhLoc[diaChiDuLieuLoc + soCot+7] = ((int)duLieuAnh[diaChiDuLieuAnh + soCot+7]
                                                       - (int)duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot+7]) & 0xff;
			   soCot += 8;
			};
		}
		else if( boLoc == 3 ) {  // ---- bộ lọc trung bình
		   unsigned int diaChiDuLieuAnhHangTruoc = diaChiDuLieuAnh + (beRong << 3);
			// --- điểm ành đầu chỉ xài dữ liệu từ hàng ở trên
         // LƯU Ý: đừng dùng >> 1 để chia 2, int có dấu)
         duLieuAnhLoc[diaChiDuLieuLoc] = ((int)duLieuAnh[diaChiDuLieuAnh] - (int)(duLieuAnh[diaChiDuLieuAnhHangTruoc] / 2)) & 0xff;
         duLieuAnhLoc[diaChiDuLieuLoc+1] = ((int)duLieuAnh[diaChiDuLieuAnh+1] - (int)(duLieuAnh[diaChiDuLieuAnhHangTruoc+1] / 2)) & 0xff;
         duLieuAnhLoc[diaChiDuLieuLoc+2] = ((int)duLieuAnh[diaChiDuLieuAnh+2] - (int)(duLieuAnh[diaChiDuLieuAnhHangTruoc+2] / 2)) & 0xff;
         duLieuAnhLoc[diaChiDuLieuLoc+3] = ((int)duLieuAnh[diaChiDuLieuAnh+3] - (int)(duLieuAnh[diaChiDuLieuAnhHangTruoc+3] / 2)) & 0xff;
         duLieuAnhLoc[diaChiDuLieuLoc+4] = ((int)duLieuAnh[diaChiDuLieuAnh+4] - (int)(duLieuAnh[diaChiDuLieuAnhHangTruoc+4] / 2)) & 0xff;
         duLieuAnhLoc[diaChiDuLieuLoc+5] = ((int)duLieuAnh[diaChiDuLieuAnh+5] - (int)(duLieuAnh[diaChiDuLieuAnhHangTruoc+5] / 2)) & 0xff;
         duLieuAnhLoc[diaChiDuLieuLoc+6] = ((int)duLieuAnh[diaChiDuLieuAnh+6] - (int)(duLieuAnh[diaChiDuLieuAnhHangTruoc+6] / 2)) & 0xff;
         duLieuAnhLoc[diaChiDuLieuLoc+7] = ((int)duLieuAnh[diaChiDuLieuAnh+7] - (int)(duLieuAnh[diaChiDuLieuAnhHangTruoc+7] / 2)) & 0xff;
         
		   unsigned int soCot = 8;
			while( soCot < (beRong << 3) ) {
			   duLieuAnhLoc[diaChiDuLieuLoc + soCot] = ((int)duLieuAnh[diaChiDuLieuAnh + soCot]
                                                         - ((int)duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot] + (int)duLieuAnh[diaChiDuLieuAnh + soCot - 8]) / 2) & 0xff;
			   duLieuAnhLoc[diaChiDuLieuLoc + soCot + 1] = ((int)duLieuAnh[diaChiDuLieuAnh + soCot + 1]
                                                         - ((int)duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot + 1] + (int)duLieuAnh[diaChiDuLieuAnh + soCot - 7]) / 2) & 0xff;
			   duLieuAnhLoc[diaChiDuLieuLoc + soCot + 2] = ((int)duLieuAnh[diaChiDuLieuAnh + soCot + 2]
                                                         - ((int)duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot + 2] + (int)duLieuAnh[diaChiDuLieuAnh + soCot - 6]) / 2) & 0xff;
			   duLieuAnhLoc[diaChiDuLieuLoc + soCot + 3] = ((int)duLieuAnh[diaChiDuLieuAnh + soCot + 3]
                                                         - ((int)duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot + 3] + (int)duLieuAnh[diaChiDuLieuAnh + soCot - 5]) / 2) & 0xff;
			   duLieuAnhLoc[diaChiDuLieuLoc + soCot + 4] = ((int)duLieuAnh[diaChiDuLieuAnh + soCot + 4]
                                                         - ((int)duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot + 4] + (int)duLieuAnh[diaChiDuLieuAnh + soCot - 4]) / 2) & 0xff;
			   duLieuAnhLoc[diaChiDuLieuLoc + soCot + 5] = ((int)duLieuAnh[diaChiDuLieuAnh + soCot + 5]
                                                         - ((int)duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot + 5] + (int)duLieuAnh[diaChiDuLieuAnh + soCot - 3]) / 2) & 0xff;
			   duLieuAnhLoc[diaChiDuLieuLoc + soCot + 6] = ((int)duLieuAnh[diaChiDuLieuAnh + soCot + 6]
                                                         - ((int)duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot + 6] + (int)duLieuAnh[diaChiDuLieuAnh + soCot - 2]) / 2) & 0xff;
			   duLieuAnhLoc[diaChiDuLieuLoc + soCot + 7] = ((int)duLieuAnh[diaChiDuLieuAnh + soCot + 7]
                                                         - ((int)duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot + 7] + (int)duLieuAnh[diaChiDuLieuAnh + soCot - 1]) / 2) & 0xff;
			   soCot += 8;
			}
      }
		else if( boLoc == 4 ) {  // ---- bộ lọc paeth
		   unsigned int diaChiDuLieuAnhHangTruoc = diaChiDuLieuAnh + (beRong << 3);
			// --- điểm ảnh đầu tiên của hàng chỉ xài dữ liệu từ điểm ảnh ở hàng trên
         duLieuAnhLoc[diaChiDuLieuLoc] = ((int)duLieuAnh[diaChiDuLieuAnh] - (int)duLieuAnh[diaChiDuLieuAnhHangTruoc]) & 0xff;
         duLieuAnhLoc[diaChiDuLieuLoc+1] = ((int)duLieuAnh[diaChiDuLieuAnh + 1] - (int)duLieuAnh[diaChiDuLieuAnhHangTruoc+1]) & 0xff;
         duLieuAnhLoc[diaChiDuLieuLoc+2] = ((int)duLieuAnh[diaChiDuLieuAnh + 2] - (int)duLieuAnh[diaChiDuLieuAnhHangTruoc+2]) & 0xff;
         duLieuAnhLoc[diaChiDuLieuLoc+3] = ((int)duLieuAnh[diaChiDuLieuAnh + 3] - (int)duLieuAnh[diaChiDuLieuAnhHangTruoc+3]) & 0xff;
         duLieuAnhLoc[diaChiDuLieuLoc+4] = ((int)duLieuAnh[diaChiDuLieuAnh + 4] - (int)duLieuAnh[diaChiDuLieuAnhHangTruoc+4]) & 0xff;
         duLieuAnhLoc[diaChiDuLieuLoc+5] = ((int)duLieuAnh[diaChiDuLieuAnh + 5] - (int)duLieuAnh[diaChiDuLieuAnhHangTruoc+5]) & 0xff;
         duLieuAnhLoc[diaChiDuLieuLoc+6] = ((int)duLieuAnh[diaChiDuLieuAnh + 6] - (int)duLieuAnh[diaChiDuLieuAnhHangTruoc+6]) & 0xff;
         duLieuAnhLoc[diaChiDuLieuLoc+7] = ((int)duLieuAnh[diaChiDuLieuAnh + 7] - (int)duLieuAnh[diaChiDuLieuAnhHangTruoc+7]) & 0xff;
         
		   unsigned int soCot = 4;
			int a;
			int b;
			int c;
			int duDoan;   // dự đoán
			int duDoanA;  // dự đoán A
			int duDoanB;  // dự đoán B
			int duDoanC;  // dự đoán C
         
			while( soCot < (beRong << 3) ) {
			   a = duLieuAnh[diaChiDuLieuAnh + soCot - 8];
			   b = duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot];
			   c = duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot - 8];
            
            duDoan = b - c;
				duDoanC = a - c;
            //				duDoanA = duDoan < 0 ? -duDoan : duDoan;
            //				duDoanB = duDoanC < 0 ? -duDoanC : duDoanC;
            //				duDoanC = (duDoan + duDoanC) < 0 ? -(duDoan + duDoanC) : duDoan + duDoanC;
            
				duDoanA = abs(duDoan);
				duDoanB = abs(duDoanC);
				duDoanC = abs(duDoan + duDoanC);
            
            duDoan = (duDoanA <= duDoanB && duDoanA <= duDoanC) ? a : (duDoanB <= duDoanC) ? b : c;
            
			   duLieuAnhLoc[diaChiDuLieuLoc + soCot] = ((int)duLieuAnh[diaChiDuLieuAnh + soCot] - duDoan) & 0xff;
			   soCot++;
         }
		}
		else {   // ---- loại lọc không biết
		   ; 
		}
      // ---- chuần bị cho hàng tiếp
		soHang++;
		diaChiDuLieuLoc += (beRong << 3);
		diaChiDuLieuAnh -= (beRong << 3);
   }
   
   return duLieuAnhLoc;
}


// lật byte dữ liệu (16 bit) từ little endian thành big endian
+ (unsigned char *)locDuLieuAnh_xam16bit:(unsigned char *)duLieuAnh beRong:(unsigned short)beRong
                 beCao:(unsigned short)beCao beDaiDuLieuAnhLoc:(unsigned int *)beDaiDuLieuAnhLoc; {

   *beDaiDuLieuAnhLoc = (beRong*beCao << 1) + beCao;  // cần kèm một byte cho mỗi hàng (số bộ lọc cho hàng)
   unsigned char *duLieuAnhLoc = malloc( *beDaiDuLieuAnhLoc );

   unsigned short soHang = 0;  // số hàng
	unsigned int diaChiDuLieuLoc = 0;
	unsigned int diaChiDuLieuAnh = beRong*(beCao - 1) << 1;  // bắt đầu tại hàng cuối (lật ngược ảnh)
	unsigned char boLoc;  // bộ lọc
			
	while( soHang < beCao ) {

      // ---- kiểm tra dữ liệu của mỗi hàng và quyết định dùng bộ lọc nào
      int tongSoBoLoc0 = 0;
      int tongSoBoLoc1 = 0;
      int tongSoBoLoc2 = 0;
      int tongSoBoLoc3 = 0;
      int tongSoBoLoc4 = 0;
		
		if( soHang != 0 ) {   // chỉ dùng bộ lọc 0 cho hàng 0
          // ---- tổng số bộ lọc 0
         unsigned int soCot = 0;
         while( soCot < (beRong << 2) ) {
            tongSoBoLoc0 += (char)duLieuAnh[diaChiDuLieuAnh + soCot+1];
            tongSoBoLoc0 += (char)duLieuAnh[diaChiDuLieuAnh + soCot];
            soCot += 2;
         }
			 // ---- tổng số bộ lọc 1
         tongSoBoLoc1 += (char)duLieuAnh[diaChiDuLieuAnh+1];
         tongSoBoLoc1 += (char)duLieuAnh[diaChiDuLieuAnh];


		   soCot = 2;
			while( soCot < (beRong << 2) ) {
			   tongSoBoLoc1 += (char)((int)duLieuAnh[diaChiDuLieuAnh + soCot+1]
                    - (int)duLieuAnh[diaChiDuLieuAnh + soCot-1]) & 0xff;
			   tongSoBoLoc1 += (char)((int)duLieuAnh[diaChiDuLieuAnh + soCot]
				        - (int)duLieuAnh[diaChiDuLieuAnh + soCot-2]) & 0xff;
			   soCot += 2;
			};
          // ---- tổng số bộ lọc 2
		   unsigned int diaChiDuLieuAnhHangTruoc = diaChiDuLieuAnh + (beRong << 1);
		   soCot = 0;
			while( soCot < (beRong << 2) ) {
			   tongSoBoLoc2 += (char)((int)duLieuAnh[diaChiDuLieuAnh + soCot+1]
				        - (int)duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot+1]) & 0xff;
			   tongSoBoLoc2 += (char)((int)duLieuAnh[diaChiDuLieuAnh + soCot]
				        - (int)duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot]) & 0xff;
			   soCot += 2;
			};
          // ---- tổng số bộ lọc 3
		   diaChiDuLieuAnhHangTruoc = diaChiDuLieuAnh + (beRong << 1);
			// --- điểm ành đầu chỉ xài dữ liệu từ hàng ở trên (don't use >> 1 for dividing by 2, signed int value)
         tongSoBoLoc3 += (char)((int)duLieuAnh[diaChiDuLieuAnh] - (int)(duLieuAnh[diaChiDuLieuAnhHangTruoc] / 2)) & 0xff;
         tongSoBoLoc3 += (char)((int)duLieuAnh[diaChiDuLieuAnh + 1] - (int)(duLieuAnh[diaChiDuLieuAnhHangTruoc+1] / 2)) & 0xff;

		   soCot = 2;
			while( soCot < (beRong << 2) ) {
			   tongSoBoLoc3 += (char)((int)duLieuAnh[diaChiDuLieuAnh + soCot+1] 
				                  - ((int)duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot+1] + (int)duLieuAnh[diaChiDuLieuAnh + soCot - 1]) / 2) & 0xff;
			   tongSoBoLoc3 += (char)((int)duLieuAnh[diaChiDuLieuAnh + soCot]
				                  - ((int)duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot] + (int)duLieuAnh[diaChiDuLieuAnh + soCot - 2]) / 2) & 0xff;
			   soCot += 2;
			}
        // ---- tổng số bộ lọc 4
		   diaChiDuLieuAnhHangTruoc = diaChiDuLieuAnh + (beRong << 1);
			// --- điểm ành đầu chỉ xài dữ liệu từ hàng ở trên
         tongSoBoLoc4 += (char)((int)duLieuAnh[diaChiDuLieuAnh] - (int)duLieuAnh[diaChiDuLieuAnhHangTruoc]) & 0xff;
         tongSoBoLoc4 += (char)((int)duLieuAnh[diaChiDuLieuAnh + 1] - (int)duLieuAnh[diaChiDuLieuAnhHangTruoc+1]) & 0xff;

		   soCot = 2;
			int a;
			int b;
			int c;
			int duDoan;
			int duDoanA;
			int duDoanB;
			int duDoanC;

			while( soCot < (beRong << 2) ) {
			   a = duLieuAnh[diaChiDuLieuAnh + soCot - 2];
			   b = duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot];
			   c = duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot - 2];

            duDoan = b - c;
				duDoanC = a - c;
//				duDoanA = duDoan < 0 ? -duDoan : duDoan;
//				duDoanB = duDoanC < 0 ? -duDoanC : duDoanC;
//				duDoanC = (duDoan + duDoanC) < 0 ? -(duDoan + duDoanC) : duDoan + duDoanC;

				duDoanA = abs(duDoan);
				duDoanB = abs(duDoanC);
				duDoanC = abs(duDoan + duDoanC);

            duDoan = (duDoanA <= duDoanB && duDoanA <= duDoanC) ? a : (duDoanB <= duDoanC) ? b : c;

			   tongSoBoLoc4 += (char)((int)duLieuAnh[diaChiDuLieuAnh + soCot] - duDoan) & 0xff;
			   soCot ++;
         }

			// ---- giá trí tuyệt đối của việc cộng
			if( tongSoBoLoc0 < 0 )
			   tongSoBoLoc0 = -tongSoBoLoc0;
			if( tongSoBoLoc1 < 0 )
			   tongSoBoLoc1 = -tongSoBoLoc1;
			if( tongSoBoLoc2 < 0 )
			   tongSoBoLoc2 = -tongSoBoLoc2;
			if( tongSoBoLoc3 < 0 )
			   tongSoBoLoc3 = -tongSoBoLoc3;
			if( tongSoBoLoc4 < 0 )
			   tongSoBoLoc4 = -tongSoBoLoc4;

         // ----- tìm giá trị bộ lọc nào nhỏ nhất
			boLoc = 0;
			unsigned int boLocNhoNhat = tongSoBoLoc0; 
			if( tongSoBoLoc1 < boLocNhoNhat ) {
			   boLoc = 1;
				boLocNhoNhat = tongSoBoLoc1;
         }
         if( tongSoBoLoc2 < boLocNhoNhat ) {
			   boLoc = 2;
				boLocNhoNhat = tongSoBoLoc2;
         }
         if( tongSoBoLoc3 < boLocNhoNhat ) {
			   boLoc = 3;
				boLocNhoNhat = tongSoBoLoc3;
         }
         if( tongSoBoLoc4 < boLocNhoNhat ) {
			   boLoc = 4;
         }

      }
      else {
         boLoc = 0;
		}
//      NSLog( @"LuuHoaTietPNG: số bộ lọc %d", boLoc );

	   // ---- byte đầu là số bộ lọc (loại bộ lọc)
	   duLieuAnhLoc[diaChiDuLieuLoc] = boLoc;
		// ---- byte tiếp là byte đầu của dữ liệu lọc

		diaChiDuLieuLoc++;

      if( boLoc == 0 ) {  // ---- không lọc, chỉ chép dữ liệu ảnh
		   unsigned int soCot = 0;
			while( soCot < (beRong << 1) ) {
			   duLieuAnhLoc[diaChiDuLieuLoc + soCot] = duLieuAnh[diaChiDuLieuAnh + soCot + 1];
			   duLieuAnhLoc[diaChiDuLieuLoc + soCot + 1] = duLieuAnh[diaChiDuLieuAnh + soCot];
			   soCot += 2;
			}
      }
		else if( boLoc == 1 ) {  // ---- bộ lọc trừ
			// ---- copy first pixel data
         duLieuAnhLoc[diaChiDuLieuLoc] = duLieuAnh[diaChiDuLieuAnh + 1];
         duLieuAnhLoc[diaChiDuLieuLoc + 1] = duLieuAnh[diaChiDuLieuAnh];

		   unsigned int soCot = 2;
			while( soCot < (beRong << 1) ) {
			   duLieuAnhLoc[diaChiDuLieuLoc + soCot] = ((int)duLieuAnh[diaChiDuLieuAnh + soCot+1]
                    - (int)duLieuAnh[diaChiDuLieuAnh + soCot-1]) & 0xff;
			   duLieuAnhLoc[diaChiDuLieuLoc + soCot+1] = ((int)duLieuAnh[diaChiDuLieuAnh + soCot]
				        - (int)duLieuAnh[diaChiDuLieuAnh + soCot-2]) & 0xff;
			   soCot += 2;
			};
		}
		else if( boLoc == 2 ) {  // ---- bộ lọc trên
		   unsigned int diaChiDuLieuAnhHangTruoc = diaChiDuLieuAnh + (beRong << 1);
		   unsigned int soCot = 0;
			while( soCot < (beRong << 1) ) {
			   duLieuAnhLoc[diaChiDuLieuLoc + soCot] = ((int)duLieuAnh[diaChiDuLieuAnh + soCot+1]
				        - (int)duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot+1]) & 0xff;
			   duLieuAnhLoc[diaChiDuLieuLoc + soCot+1] = ((int)duLieuAnh[diaChiDuLieuAnh + soCot]
				        - (int)duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot]) & 0xff;
			   soCot += 2;
			};
		}
		else if( boLoc == 3 ) {  // ---- bộ lọc trung bình
		   unsigned int diaChiDuLieuAnhHangTruoc = diaChiDuLieuAnh + (beRong << 1);
			// --- điểm ành đầu chỉ xài dữ liệu từ hàng ở trên (đừng dùng >> 1 để chia 2, giá trị số nguyôn có dấu)
         duLieuAnhLoc[diaChiDuLieuLoc] = ((int)duLieuAnh[diaChiDuLieuAnh+1] - (int)(duLieuAnh[diaChiDuLieuAnhHangTruoc+1] / 2)) & 0xff;
         duLieuAnhLoc[diaChiDuLieuLoc+1] = ((int)duLieuAnh[diaChiDuLieuAnh] - (int)(duLieuAnh[diaChiDuLieuAnhHangTruoc] / 2)) & 0xff;

		   unsigned int soCot = 2;
			while( soCot < (beRong << 1) ) {
			   duLieuAnhLoc[diaChiDuLieuLoc + soCot] = ((int)duLieuAnh[diaChiDuLieuAnh + soCot+1] 
				                  - ((int)duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot+1] + (int)duLieuAnh[diaChiDuLieuAnh + soCot - 1]) / 2) & 0xff;
			   duLieuAnhLoc[diaChiDuLieuLoc + soCot + 1] = ((int)duLieuAnh[diaChiDuLieuAnh + soCot]
				                  - ((int)duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot] + (int)duLieuAnh[diaChiDuLieuAnh + soCot - 2]) / 2) & 0xff;
			   soCot += 2;
			}
      }
		else if( boLoc == 4 ) {  // ---- bộ lọc paeth
		   unsigned int diaChiDuLieuAnhHangTruoc = diaChiDuLieuAnh + (beRong << 1);
			// --- điểm ành đầu chỉ xài dữ liệu từ hàng ở trên
         duLieuAnhLoc[diaChiDuLieuLoc] = ((int)duLieuAnh[diaChiDuLieuAnh+1] - (int)duLieuAnh[diaChiDuLieuAnhHangTruoc+1]) & 0xff;
         duLieuAnhLoc[diaChiDuLieuLoc+1] = ((int)duLieuAnh[diaChiDuLieuAnh] - (int)duLieuAnh[diaChiDuLieuAnhHangTruoc]) & 0xff;

		   unsigned int soCot = 2;   // đật này = 4 để làm họa thuật lạ
			int a;
			int b;
			int c;
			int duDoan;
			int duDoanA;
			int duDoanB;
			int duDoanC;

			while( soCot < (beRong << 1) ) {
			   a = duLieuAnh[diaChiDuLieuAnh + soCot - 1];            // - 2
			   b = duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot+1];   // + 0
			   c = duLieuAnh[diaChiDuLieuAnhHangTruoc + soCot - 1]; // - 2

            duDoan = b - c;
				duDoanC = a - c;
//				duDoanA = duDoan < 0 ? -duDoan : duDoan;
//				duDoanB = duDoanC < 0 ? -duDoanC : duDoanC;
//				duDoanC = (duDoan + duDoanC) < 0 ? -(duDoan + duDoanC) : duDoan + duDoanC;

				duDoanA = abs(duDoan);
				duDoanB = abs(duDoanC);
				duDoanC = abs(duDoan + duDoanC);

            duDoan = (duDoanA <= duDoanB && duDoanA <= duDoanC) ? a : (duDoanB <= duDoanC) ? b : c;

			   duLieuAnhLoc[diaChiDuLieuLoc + soCot] = ((int)duLieuAnh[diaChiDuLieuAnh + soCot+1] - duDoan) & 0xff; //+1  abs art
			   soCot ++;
         }
		}
		else {   // ---- sai lầm, không biết loại bộ lọc
		   ; 
		}
      // ---- đến hàng tiếp theo
		soHang++;
		diaChiDuLieuLoc += (beRong << 1);
		diaChiDuLieuAnh -= (beRong << 1);
   }

   return duLieuAnhLoc;
}


#pragma mark ---- Lưu Ảnh PNG
+ (void)luuBGRO_PNG_voiURL:(NSURL *)urlTapTin duLieuAnh:(unsigned char *)duLieuAnh
                    beRong:(unsigned int)beRong beCao:(unsigned int)beCao soLuongBit:(unsigned char)soLuongBit; {

   // ---- lọc các hàng ảnh
   unsigned int beDaiDuLieuAnhLoc;
   unsigned char *duLieuAnhLoc = NULL;
   if( soLuongBit == 32 )
      duLieuAnhLoc = [self locDuLieuAnh_32bit:duLieuAnh beRong:beRong beCao:beCao
	                             beDaiDuLieuAnhLoc:&beDaiDuLieuAnhLoc];
   else if( soLuongBit == 64 )
      duLieuAnhLoc = [self locDuLieuAnh_64bit:duLieuAnh beRong:beRong beCao:beCao
                            beDaiDuLieuAnhLoc:&beDaiDuLieuAnhLoc];
   else
      NSLog( @"LuuHoaTietPNG: luuBRO: số lượng bit %d không hợp lệ, chọn 32 hay 64", soLuongBit );

   if( duLieuAnhLoc ) {
      // ---- dùng zlib để nén dữ liệu
      int err;
      z_stream c_stream; // struct cho nén dữ liệu

      c_stream.zalloc = (alloc_func)0;
      c_stream.zfree = (free_func)0;
      c_stream.opaque = (voidpf)0;

       // ---- xem nếu chuẩn bị có sai lầm nào
      err = deflateInit(&c_stream, kZLIB_MUC_NEN);

	   if( err != Z_OK ) {
	      NSLog( @"LuuTapTinPNG: WritePNG: SAI LẦM deflateInit %d (%x) c_stream.avail_in %d", err, err, c_stream.avail_out );
      }

      // ---- cho dữ liệu cần nén
      c_stream.next_in = duLieuAnhLoc;
      c_stream.avail_in = beDaiDuLieuAnhLoc;

      // ---- dự đoán trí nhớ cần cho nén dữ liệu
      unsigned int idat_chunkDataLength = (unsigned int)deflateBound(&c_stream, beDaiDuLieuAnhLoc );
		   // 8 bytes for idat length, mã thành phần (tên). Cần mã thành phần cho tính crc
		unsigned char *idat_chunkData = malloc( idat_chunkDataLength + 8);

      // ---- đệm cho chứa dữ liệu nén
      c_stream.next_out  = &(idat_chunkData[8]);
      c_stream.avail_out = idat_chunkDataLength;

      err = deflate(&c_stream, Z_FINISH);

	   if( err != Z_STREAM_END ) {
	      NSLog( @"LuuTapTinPNG: luuPNG: SAI LẦM deflate %d (%x) c_stream.avail_out %d c_stream.total_out %ld c_stream.avail_in %d",
		           err, err, c_stream.avail_out, c_stream.total_out, c_stream.avail_in );
      }

	   // ---- không cần dữ liệu lọc nữa
	   free( duLieuAnhLoc );

      // ---- tạo dữ liệu lưu trong tệp PNG
	   NSMutableData *dongTapTin = [self luuPNGVoiDuLieuIDAT:idat_chunkData
		           beDaiDuLieuNen:(unsigned int)c_stream.total_out beRong:beRong beCao:beCao
		           bitMoiKenh:soLuongBit >> 2 loai:kRGBO];

      // ---- lưư tập tin PNG
      if( dongTapTin ) {
//         NSError *error;
         if( ![dongTapTin writeToURL:urlTapTin atomically:YES] )
	         NSLog( @"LuuTapTinPNG: luuTapTinPNG: SAI LẦM không thể lưu tập tin %@", urlTapTin );
      }

	   // ---- không cần dữ liệu nén nữa
      free( idat_chunkData );

      // ---- bỏ c_stream
		deflateEnd( &c_stream );
	}
}
/*
+ (void)luuXam16bit_PNG_voiURL:(NSURL *)urlTapTin duLieuAnh:(unsigned char *)duLieuAnh
          beRong:(unsigned int)beRong beCao:(unsigned int)beCao; {

   // ---- lọc các hàng ảnh
   unsigned int beDaiDuLieuAnhLoc;
   unsigned char *duLieuAnhLoc = [self locDuLieuAnh_xam16bit:duLieuAnh beRong:beRong beCao:beCao
	                             beDaiDuLieuAnhLoc:&beDaiDuLieuAnhLoc];

   if( duLieuAnhLoc ) {
      // ---- dùng zlib để nén dữ liệu
      int err;
      z_stream c_stream; // struct cho nén dữ liệu

      c_stream.zalloc = (alloc_func)0;
      c_stream.zfree = (free_func)0;
      c_stream.opaque = (voidpf)0;

       // ---- xem nếu chuẩn bị có sai lầm nào
      err = deflateInit(&c_stream, kZLIB_COMPRESSION_LEVEL);

	   if( err != Z_OK ) {
	      NSLog( @"LuuTapTinPNG: WritePNG: error deflateInit %d (%x) c_stream.avail_in %d", err, err, c_stream.avail_out );
      }

      // ---- cho dữ liệu cần nén
      c_stream.next_in = duLieuAnhLoc;
      c_stream.avail_in = beDaiDuLieuAnhLoc;

      // ---- dự đoán trí nhớ cần cho nén dữ liệu
      unsigned int idat_chunkDataLength = (unsigned int)deflateBound(&c_stream, beDaiDuLieuAnhLoc );
		   // 8 bytes for idat length, mã thành phần (tên). Cần mã thành ưhần cho crc
		unsigned char *idat_chunkData = malloc( idat_chunkDataLength + 8);

      // ---- cho địa chỉ trí nhớ cho nén dữ liệu
      c_stream.next_out  = &(idat_chunkData[8]);
      c_stream.avail_out = idat_chunkDataLength;

//      NSLog( @"LuuTapTinPNG: before: c_stream.avail_in %d\n", c_stream.avail_in );
//      NSLog( @"LuuTapTinPNG: before: c_stream.avail_out %d\n", c_stream.avail_out );
//      NSLog( @"LuuTapTinPNG: before: c_stream.total_out %ld\n", c_stream.total_out );

      err = deflate(&c_stream, Z_FINISH);

	   if( err != Z_STREAM_END ) {
	      NSLog( @"LuuTapTinPNG: writePNG: luuPNG: SAI LẦM deflate %d (%x) c_stream.avail_out %d c_stream.total_out %ld c_stream.avail_in %d",
		           err, err, c_stream.avail_out, c_stream.total_out, c_stream.avail_in );
      }

//      NSLog(@"LuuTapTinPNG: after: c_stream.avail_in %d\n", c_stream.avail_in );
//      NSLog(@"LuuTapTinPNG: after: c_stream.avail_out %d\n", c_stream.avail_out );
//      NSLog(@"LuuTapTinPNG: after: c_stream.total_out %d\n", c_stream.total_out );

	   // ---- không cần dữ liệu lọc nữa
	   free( duLieuAnhLoc );

      // ---- dòng dữ liệu tập tin
	   NSMutableData *dongTapTin = [self luuPNGVoiDuLieuIDAT:idat_chunkData
		           beDaiDuLieuNen:(unsigned int)c_stream.total_out beRong:beRong beCao:beCao
		           bitMoiKenh:16 loai:kXAM];

      // ---- lưu tập tin PNG
      if( ![dongTapTin writeToURL:urlTapTin atomically:YES] ) {
	      NSLog( @"LuuTapTinPNG: writeRGBO_PNG: SAI LẦM không được lưu tập tin %@", urlTapTin );
      }

	   // ---- không cần dữ liệu nén nữa
      free( idat_chunkData );

      // ---- free stream
		deflateEnd( &c_stream );
	}
}
*/
/*
+ (void)luuBGRO_StereoPNG_voiURL:(NSURL *)urlTapTin duLieuMau:(unsigned char *)duLieuMau
         duLieuAnhSau:(unsigned char *)duLieuSau beRong:(unsigned int)beRong beCao:(unsigned int)beCao; {

   // ---- lọc các hàng ảnh
   unsigned int beDaiDuLieuAnhLoc;
   unsigned char *duLieuAnhLoc = [self locDuLieuAnh_32bit:duLieuMau beRong:beRong beCao:beCao
	                             beDaiDuLieuAnhLoc:&beDaiDuLieuAnhLoc];

   if( duLieuAnhLoc ) {
      // ---- dùng zlib để nén dữ liệu
      int err;
      z_stream c_stream; // struct cho nén dữ liệu

      c_stream.zalloc = (alloc_func)0;
      c_stream.zfree = (free_func)0;
      c_stream.opaque = (voidpf)0;

      // ---- xem nếu chuẩn bị có sai lầm nào
      err = deflateInit(&c_stream, kZLIB_COMPRESSION_LEVEL);

	   if( err != Z_OK ) {
	      NSLog( @"LuuTapTinPNG: WritePNGStereo: error deflateInit %d (%x) c_stream.avail_in %d", err, err, c_stream.avail_out );
      }

      // ---- cho dữ liệu cần nén
      c_stream.next_in = duLieuAnhLoc;
      c_stream.avail_in = beDaiDuLieuAnhLoc;

      // ---- dự đoán trí nhớ cần cho nén dữ liệu
      unsigned int idat_chunkDataLength = (unsigned int)deflateBound(&c_stream, beDaiDuLieuAnhLoc );
      // kèm 8 byte cho bầ dài thành phần IDAT. Cần mã thàh phần cho tính crc
		unsigned char *idat_chunkData = malloc( idat_chunkDataLength + 8);

      // ---- cho địa chỉ trí nhớ để nén dữ liệu
      c_stream.next_out  = &(idat_chunkData[8]);
      c_stream.avail_out = idat_chunkDataLength;


      err = deflate(&c_stream, Z_FINISH);

	   if( err != Z_STREAM_END ) {
	      NSLog( @"LuuTapTinPNG: writePNG: error deflate %d (%x) c_stream.avail_out %d c_stream.total_out %ld c_stream.avail_in %d",
		           err, err, c_stream.avail_out, c_stream.total_out, c_stream.avail_in );
      }

	   // ---- không cần dữ liệu lọc nữa
	   free( duLieuAnhLoc );

      // ---- ký hiệu cho tấp tin PNG (dài 8 byte)
      unsigned long long int fileSignature = 0x0a1a0a0d474e5089;  // reverse order for intel;
	   NSMutableData *dongTapTin = [NSMutableData dataWithBytes:&fileSignature length:8];

      // ---- thành phần IHDR
		[self kemThanhPhanIHDRChoDong:dongTapTin beRong:beRong beCao:beCao loai:kRGBO bitMoiKenh:8];
      // ---- thành phần tIME
		[self kemThanhPhantIMEChoDong:dongTapTin nam:2554 thang:3 ngay:18 gio:1 phut:0 giay:0];
		// ---- thành phần IDAT
		[self kemThanhPhanIDATChoDong:dongTapTin duLieuMauAnhNen:idat_chunkData beDaiDuLieuNen:(unsigned int)c_stream.total_out];
	   // ---- không cần dữ liệu nén nữa
      free( idat_chunkData );

      // ==== cho kênh z (độ xa/sâu)
      // ---- lọc hàng ảnh
//      beDaiDuLieuAnhLoc;
      duLieuAnhLoc = [self locDuLieuAnh_xam16bit:duLieuSau beRong:beRong beCao:beCao beDaiDuLieuAnhLoc:&beDaiDuLieuAnhLoc];
      if( duLieuAnhLoc ) {

          // ---- chuẩn bị cho dòng dữ liệu tiếp
         deflateReset( &c_stream );

	      if( err != Z_OK ) {
	         NSLog( @"LuuTapTinPNG: WritePNGStereo: error deflateInit %d (%x) c_stream.avail_in %d", err, err, c_stream.avail_out );
         }
         // ---- cho dữ liệu cần nén
         c_stream.next_in = duLieuAnhLoc;
         c_stream.avail_in = beDaiDuLieuAnhLoc;

         // ---- dự đoán trí nhớ cần cho nén dữ liệu
         unsigned int sWEI_chunkDataLength = (unsigned int)deflateBound(&c_stream, beDaiDuLieuAnhLoc );
		      // 8 bytes for idat length, chunk name. Need chunk name for crc
		   unsigned char *sWEI_chunkData = malloc( sWEI_chunkDataLength + 8);

         // ---- cho địa chỉ trí nhớ để nén dữ liệu
         c_stream.next_out  = &(sWEI_chunkData[8]);
         c_stream.avail_out = sWEI_chunkDataLength;

         err = deflate(&c_stream, Z_FINISH);

	      if( err != Z_STREAM_END ) {
	         NSLog( @"LuuTapTinPNG: writePNGStereo: error deflate %d (%x) c_stream.avail_out %d c_stream.total_out %ld c_stream.avail_in %d",
		              err, err, c_stream.avail_out, c_stream.total_out, c_stream.avail_in );
         }

	      // ---- không cần dữ liệu lọc nữa
	      free( duLieuAnhLoc );

         // ---- thành phần zCHA
			[self kemThanhPhanzCHAChoDong:dongTapTin duLieuSauNen:sWEI_chunkData beDaiDuLieuNen:(unsigned int)c_stream.total_out];

	      // ---- không cần dữ liệu lọc nữa
	      free( sWEI_chunkData );

      }

      // ---- thành phần IEND
		[self kemThanhPhanIENDChoDong:dongTapTin];

      // ---- Lưu tập tin PNG
      if( ![dongTapTin writeToURL:urlTapTin atomically:YES] ) {
	      NSLog( @"LuuTapTinPNG: luuBGROStereo_PNG: SAI LẦM không thể lưu tập tin %@", urlTapTin );
      }

      // ---- bỏ c_stream
      deflateEnd( &c_stream );
	}
}
*/



@end
