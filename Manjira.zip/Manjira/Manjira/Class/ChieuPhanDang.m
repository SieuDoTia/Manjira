//
//  ChieuPhanDang.m
//  Manjira
//
//  Created by 小小 on 20/11/2556.
//

#import "ChieuPhanDang.h"
#import "ToBong.h"
#import <OpenGL/gl.h>

// ---- màu cảnh sau
#define kMAU_CANH__DO   0.894f
#define kMAU_CANH__LUC  0.894f
#define kMAU_CANH__XANH 0.894f
#define kMAU_CANH__DUC  1.000f

#define kHOA_TIET__RONG 2048
#define kHOA_TIET__CAO  2048

// ---- cho shader
enum {
   ATTRIB_DINH,
   ATTRIB_HOA_TIET
};

@implementation ChieuPhanDang
/*
- (id)initWithFrame:(NSRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {

    }
    return self;
}
*/
- (void)awakeFromNib; {

}


#pragma mark ---- Chuẩn Bị OpenGL
//      |
//      |                   + tâm họa tiết
//      |
// +----+--------------+
// |    +---------+    |
// |    |ảnh chiếu|    |
// |    |*** + ***|    |   họa tiết
// |    |*********|    |
// |    +---------+----+---------------
// +-------------------+
//    màn
// |<------->|
//      |<----------------->|
//      |<-->|
//      HT/2 - A/2


- (void)prepareOpenGL; {
   // initialize OpenGL state after creating the NSOpenGLContext object
   glEnable( GL_BLEND );
   glBlendFunc( GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA );

   // ---- phóng to cửa sổ cho màn Retina
   phongToCuaSo = [[self window] backingScaleFactor];

   // ---- họa tiết
   glGenTextures(1, &hoaTietPhanDang );
   [self taoHoaTietCoBeRong:kHOA_TIET__RONG cao:kHOA_TIET__CAO choSoHoaTiet:hoaTietPhanDang];

   // ---- ma trận chiếu
   CGRect khung = [self frame];
   float tiSoPhongTo = khung.size.width/khung.size.height;
   
   // ---- ma trận chiếu
   float phongTo = kHOA_TIET__RONG/(khung.size.width*phongToCuaSo);
   maTranChieu[0] = phongTo;
   maTranChieu[5] = phongTo*tiSoPhongTo;
   maTranChieu[10] = 1.0f;
   
//   maTranChieu[12] = phongTo - (float)beRong/khung.size.width;  // địch x
//   maTranChieu[13] = (phongTo - (float)beCao/khung.size.width)*tiSoPhongTo;  // dịch y

   maTranChieu[15] = 1.0f;

   glClearColor( kMAU_CANH__DO, kMAU_CANH__LUC, kMAU_CANH__XANH, kMAU_CANH__DUC );
   
   // ===== SHADERS =====
   NSString *applicationBundleFilePath;
   
   // ---- biên dịch tô bóng
   // ----------- tô bóng -----------
   unsigned int shaderDinh = 0;
   unsigned int shaderDiemAnh = 0;
	applicationBundleFilePath = [[NSBundle mainBundle] pathForResource:@"TôBóng_HọaTiết" ofType:@"vsh"];
	[ToBong compileShader:&shaderDinh type:GL_VERTEX_SHADER filePath:applicationBundleFilePath];
	applicationBundleFilePath = [[NSBundle mainBundle] pathForResource:@"TôBóng_HọaTiết" ofType:@"fsh"];
	[ToBong compileShader:&shaderDiemAnh type:GL_FRAGMENT_SHADER filePath:applicationBundleFilePath];
   
   // ---- tạo nên chương trình tô bóng
   soChuongTrinhVe = [ToBong createShaderProgramWithVertexShader:shaderDinh andFragmentShader:shaderDiemAnh];
   
   // need to do this before linking
   glBindAttribLocation(soChuongTrinhVe, ATTRIB_DINH, "dinh");
   glBindAttribLocation(soChuongTrinhVe, ATTRIB_HOA_TIET, "toaDoHoaTiet");
   
   
	[ToBong linkAndValidateProgram:soChuongTrinhVe];
   
	uniform_MaTranChieu = glGetUniformLocation(soChuongTrinhVe, "maTranChieu");
   
   //  enable attributes for shaders
   glEnableVertexAttribArray( ATTRIB_DINH );
   glEnableVertexAttribArray( ATTRIB_HOA_TIET );
}

#pragma mark ---- Vẽ
// Toàn họa tiết có tọa đồ này, nhưng chỉ cần vẽ góc có ảnh chiếu
// (0; 1)        (1; 1)
// +----------------+
// | 0            2 |
// |                |            +--------+
// |                |   ----->   | 0    2 |
// |                |            |        |
// | 1            3 |            | 1    3 |
// +----------------+            +--------+
// (0;0)       (1; 0)          (0;0)



- (void)drawRect:(NSRect)dirtyRect; {
   
//   NSLog( @"ChieuPhanDang: drawRect: %5.3f %5.3f %5.3f %5.3f", dirtyRect.origin.x, dirtyRect.origin.y, dirtyRect.size.width, dirtyRect.size.height );
//   NSLog( @"%d", keoHinh );
//   NSLog( @"ChieuPhanDang: drawRect: cachKeoMan %5.3f %5.3f", cachKeoMan.x, cachKeoMan.y );
//   NSLog( @"ChieuPhanDang: drawRect: cachKeoMan %5.3f %5.3f", cachKeoMan.x, cachKeoMan.y );
   float beRongHoaTiet = (float)beRong/(float)kHOA_TIET__RONG;
   float beCaoHoaTiet = (float)beCao/(float)kHOA_TIET__RONG;
   NSLog( @"ChieuPhanDang: drawRect: beRongHoaTiet %5.3f beCaoHoaTiet %5.3f", beRongHoaTiet, beCaoHoaTiet );
   
   float mangDinhChuNhat[8] = {
      -beRongHoaTiet, beCaoHoaTiet,   // đỉnh 0
      -beRongHoaTiet, -beCaoHoaTiet,  // đỉnh 1
       beRongHoaTiet, beCaoHoaTiet,   // đỉnh 2
       beRongHoaTiet, -beCaoHoaTiet}; // đỉnh 3
   
   float mangToaDoHoaTiet[16] = {
      0.0f, beCaoHoaTiet,            // đỉnh 0
      0.0f, 0.0f,                    // đỉnh 1
      beRongHoaTiet, beCaoHoaTiet,   // đỉnh 2
      beRongHoaTiet, 0.0f,           // đỉnh 3
   };
   
   if( keoHinh ) {
      float dichX = cachKeoMan.x/kHOA_TIET__RONG;
      float dichY = cachKeoMan.y/kHOA_TIET__RONG;
      mangToaDoHoaTiet[0] -= dichX;
      mangToaDoHoaTiet[2] -= dichX;
      mangToaDoHoaTiet[4] -= dichX;
      mangToaDoHoaTiet[6] -= dichX;
      
      mangToaDoHoaTiet[1] -= dichY;
      mangToaDoHoaTiet[3] -= dichY;
      mangToaDoHoaTiet[5] -= dichY;
      mangToaDoHoaTiet[7] -= dichY;
   }
   
   glClear( GL_COLOR_BUFFER_BIT );

   if( hoaTietPhanDang ) {
      glUseProgram( soChuongTrinhVe );
      glUniformMatrix4fv( uniform_MaTranChieu, 1, GL_FALSE, maTranChieu );
      glBindTexture(GL_TEXTURE_2D, hoaTietPhanDang);

      glVertexAttribPointer(ATTRIB_DINH, 2, GL_FLOAT, NO, 0, mangDinhChuNhat );
      glVertexAttribPointer(ATTRIB_HOA_TIET, 2, GL_FLOAT, YES, 0, mangToaDoHoaTiet );
      glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
   }

   glFlush();
}

#pragma mark ---- Họa Tiết

- (void)taoHoaTietCoBeRong:(unsigned int)rong cao:(unsigned int)cao choSoHoaTiet:(unsigned int)soHoaTiet; {
   
   // ---- dính tên họa tiết (tên là số)
   glBindTexture(GL_TEXTURE_2D, soHoaTiet );
   glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR );
   glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR );
   glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT );
   glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT );
   
   // ---- 
   hoaTietChanh = malloc( rong * cao * sizeof( float ) << 2 );
   
   if( hoaTietChanh ) {
      unsigned int chiSo = 0;
      unsigned int chiSoCuoi = rong * cao;
      while( chiSo < chiSoCuoi ) {
         hoaTietChanh[chiSo] = kMAU_CANH__DO;
         hoaTietChanh[chiSo+1] = kMAU_CANH__LUC;
         hoaTietChanh[chiSo+2] = kMAU_CANH__XANH;
         hoaTietChanh[chiSo+3] = kMAU_CANH__DUC;
         chiSo += 4;
      }
      
      glTexImage2D( GL_TEXTURE_2D, 0, GL_RGBA, rong, cao, 0, GL_RGBA, GL_FLOAT, hoaTietChanh );

   }
   else
      NSLog( @"ChieuPhanDang: taoHoaTiet: Vấn đề dành bộ nhớ" );
}


#pragma mark ---- Chép Ảnh Vào Họa Tiết

// +----------------+
// |    họa tiết    |
// |                |
// +--------+       |
// |********|       |
// |**ảnh***|       |
// |********|       |
// +--------+-------+
//  bỏ ảnh chiếu ở góc trái dưới của họa tiết


- (void)chepAnh:(float *)anh; {
   
   NSLog(@"ChieuPhanDang: chepAnh: beRong %d  beCao %d", beRong, beCao );

   // ---- coi chừng ảnh == NULL
   if( anh ) {
      [[self openGLContext] makeCurrentContext];
      // ---- dính tên họa tiết (tên là số)
      glBindTexture(GL_TEXTURE_2D, hoaTietPhanDang );
      
      glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR );
      glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR );
      glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT );
      glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT );
      
      glTexSubImage2D( GL_TEXTURE_2D, 0, 0, 0, beRong, beCao, GL_RGBA, GL_FLOAT, anh );
      //   unsigned int error = glGetError();
      [self setNeedsDisplay:YES];
   }
}

#pragma mark ---- Xóa
- (void)xoa; {
   
   [[self openGLContext] makeCurrentContext];
   // ---- dính tên họa tiết (tên là số)
   glBindTexture(GL_TEXTURE_2D, hoaTietPhanDang );
   
   glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR );
   glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR );
   glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT );
   glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT );

   // ---- chỉ dành bộ nhớ khi ảnh == NULL
   if( hoaTietChanh == NULL ) 
      hoaTietChanh = malloc( kHOA_TIET__RONG*kHOA_TIET__CAO*sizeof( float ) << 2 );
   
   if( hoaTietChanh ) {
      unsigned int chiSo = 0;
      unsigned int chiSoCuoi = kHOA_TIET__RONG*kHOA_TIET__CAO << 2;
      
      // ---- xóa họa tiệt bằng đặc màu mặc định
      while( chiSo < chiSoCuoi ) {
         hoaTietChanh[chiSo] = kMAU_CANH__DO;
         hoaTietChanh[chiSo+1] = kMAU_CANH__LUC;
         hoaTietChanh[chiSo+2] = kMAU_CANH__XANH;
         hoaTietChanh[chiSo+3] = kMAU_CANH__DUC;
         chiSo +=4;
      }
      
      glTexSubImage2D( GL_TEXTURE_2D, 0, 0, 0, kHOA_TIET__RONG, kHOA_TIET__CAO, GL_RGBA, GL_FLOAT, hoaTietChanh );
      
      //   unsigned int error = glGetError();
      [self setNeedsDisplay:YES];
   }
   else {
      NSLog( @"ChieuPhanDang: xoa: có vấn đề dành bộ nhớ cho họa tiết OpenGL" );
   }
}

#pragma mark ---- Reshape
- (void)reshape {
	// We draw on a secondary thread through the display link
	// When resizing the view, -reshape is called automatically on the main thread
	// Add a mutex around to avoid the threads accessing the context simultaneously when resizing
	CGLLockContext([[self openGLContext] CGLContextObj]);

   CGRect khung = [self frame];
	glViewport(0, 0, khung.size.width*phongToCuaSo, khung.size.height*phongToCuaSo);
   
   
   float tiSoPhongTo = khung.size.width/khung.size.height;
   
//   NSLog( @"ChieuPhanDang: reshape: khung.size.width*phongToCuaSo %5.3f %5.3f  phongToCuaSo %5.3f\n     tiSoPhongTo %5.3f",
//         khung.size.width*phongToCuaSo, khung.size.width*phongToCuaSo, phongToCuaSo, tiSoPhongTo );
   
   // ---- ma trận chiếu
   float phongTo = kHOA_TIET__RONG/(khung.size.width*phongToCuaSo);
   maTranChieu[0] = phongTo;
   maTranChieu[5] = phongTo*tiSoPhongTo;

//   maTranChieu[12] = phongTo - (float)beRong/khung.size.width;  // địch x
//   maTranChieu[13] = (phongTo - (float)beCao/khung.size.width)*tiSoPhongTo;  // dịch y
	
	CGLUnlockContext([[self openGLContext] CGLContextObj]);
}

#pragma mark ---- Chuột
- (void)mouseDown:(NSEvent *)suKien; {
   
   // ---- chưa biết sẽ kéo hình, đặt = SAI trước
   keoHinh = NO;
   viTriBamDau = [suKien locationInWindow];
}

- (void)mouseDragged:(NSEvent *)suKien; {

   keoHinh = YES;
   CGPoint cachKeo = [suKien locationInWindow];
   cachKeoMan.x = cachKeo.x - viTriBamDau.x;
   cachKeoMan.y = cachKeo.y - viTriBamDau.y;
    
    cachKeo.x *= phongToCuaSo;
    cachKeo.y *= phongToCuaSo;
//   NSLog( @"  cachKeoMan %5.3f %5.3f", cachKeoMan.x, cachKeoMan.x );
   [self setNeedsDisplay:YES];
}

- (void)mouseUp:(NSEvent *)suKien; {

   viTriBamTuongDoi = [suKien locationInWindow];

   // ---- chỉ làm nếu chưa kéo hình
   if( !keoHinh ) {

      CGRect chuNhatChieu = [self frame];
      
      // ---- vị trí trong cửa sổ
      viTriBamTuongDoi.x -= chuNhatChieu.origin.x;
      viTriBamTuongDoi.y -= chuNhatChieu.origin.y;

      // ---- vị trí với ảnh phần dạng
      viTriBamTuongDoi.x -= (chuNhatChieu.size.width - beRong)*0.5f;
      viTriBamTuongDoi.y -= (chuNhatChieu.size.height - beCao)*0.5f;
      
      // ----- tương đối với trung tâm
      viTriBamTuongDoi.x -= beRong*0.5;
      viTriBamTuongDoi.y -= beCao*0.5;
      
      // ---- chia bề cỡ thước ảnh phần ảnh (không phải của NSOenGLView)
      viTriBamTuongDoi.x /= (float)beRong;
      viTriBamTuongDoi.y /= (float)beCao;
      
       // ---- phóng to tương đối màn Retina
       viTriBamTuongDoi.x *= phongToCuaSo;
       viTriBamTuongDoi.y *= phongToCuaSo;
       
      // ---- chỉ phạt nếu bấm ở trong ảnh phần dạng
      if( viTriBamTuongDoi.x <= 0.5f && viTriBamTuongDoi.x >= -0.5f && viTriBamTuongDoi.y <= 0.5f && viTriBamTuongDoi.y >= -0.5f ) {
         // ---- xem bấm đang phím shift
         if( [suKien modifierFlags] & NSShiftKeyMask )
            phimShift = YES;
         else
            phimShift = NO;
         
         // ---- có bấm đang bấm phím ctrl
         if( [suKien modifierFlags] & NSControlKeyMask )
            phimCtrl = YES;
         else
            phimCtrl = NO;
         
         [[NSNotificationCenter defaultCenter] postNotificationName:@"星凤BấmĐiểm" object:self];
      }
   }
   else {
      keoHinh = NO;
      // ---- tính cách bị kéo đi
      cachKeoMan = CGPointMake( viTriBamTuongDoi.x - viTriBamDau.x, viTriBamTuongDoi.y - viTriBamDau.y );

      [[NSNotificationCenter defaultCenter] postNotificationName:@"星凤KéoMàn" object:self];
   }
}



#pragma mark --- Bàn Phím
- (BOOL)acceptsFirstResponder; {
   return YES;
}

//- (BOOL)resignFirstResponder; {
//   return YES;
//}

- (void)keyDown:(NSEvent *)event; {

   huong = [event keyCode];
   if( [event modifierFlags] & NSControlKeyMask )
     phimCtrl = YES;
   else
      phimCtrl = NO;

   [[NSNotificationCenter defaultCenter] postNotificationName:@"星凤DiChuyển" object:self];
}

- (void)dealloc {
   
   // ---- thả bộ nhớ
   if( hoaTietChanh != NULL )
      free( hoaTietChanh );
}


#pragma mark ---- Biến
//@synthesize anhViDu;
@synthesize beRong;
@synthesize beCao;
@synthesize viTriBamTuongDoi;
@synthesize phimShift;
@synthesize phimCtrl;

@synthesize huong;
@synthesize cachKeoMan;

@synthesize phongToCuaSo;

@end
