//
//  LuuXML_DanhSachMau.m
//  Manjira
//
//  Created by 小小 on 16/2/2560.
//

#import "LuuXML_DanhSachMau.h"
#import "ToMau.h"

@implementation LuuXML_DanhSachMau

+ (void)luuVoiURL:(NSURL *)URL_tapTin danhSachMau:(ToMau *)toMau; {
   
   // ----
   char *dauTep = "<?xml version=\"1.0\" ?>\n\n";

   NSMutableData *dongDuLieu = [NSMutableData dataWithBytes:dauTep length:24];
   
   // ==== đầu phần tử danhSáchMàu
   [dongDuLieu appendData:[[NSString stringWithFormat:@"<%@>\n", NSLocalizedString(@"danhSáchMàu", @"tên phần tử trong tệp XML")] dataUsingEncoding:NSUTF8StringEncoding]];

   // ==== lưu danh sách màu
   float *danhSachMau = [toMau danhSachMau];

   unsigned char soLuondMau = [toMau soLuongMau];
   unsigned char chiSoMau = 0;
   while( chiSoMau < soLuondMau ) {
      unsigned int diaChi = chiSoMau << 2;
      
      [dongDuLieu appendData:[[NSString stringWithFormat:@"   <%@  ", NSLocalizedString(@"màu", @"tên phần tử trong tệp XML")] dataUsingEncoding:NSUTF8StringEncoding]];
         // ---- đỏ
      [dongDuLieu appendData:[[NSString stringWithFormat:@"%@=\"", NSLocalizedString(@"đỏ", @"tên phần tử trong tệp XML")] dataUsingEncoding:NSUTF8StringEncoding]];
      [dongDuLieu appendData:[[NSString stringWithFormat:@"%8.6f\" ", danhSachMau[diaChi]] dataUsingEncoding:NSUTF8StringEncoding]];
      
         // ---- lục
      [dongDuLieu appendData:[[NSString stringWithFormat:@"%@=\"", NSLocalizedString(@"lục", @"tên phần tử trong tệp XML")] dataUsingEncoding:NSUTF8StringEncoding]];
      [dongDuLieu appendData:[[NSString stringWithFormat:@"%8.6f\" ", danhSachMau[diaChi+1]] dataUsingEncoding:NSUTF8StringEncoding]];

      
      // ---- xanh
      [dongDuLieu appendData:[[NSString stringWithFormat:@"%@=\"", NSLocalizedString(@"xanh", @"tên phần tử trong tệp XML")] dataUsingEncoding:NSUTF8StringEncoding]];
      [dongDuLieu appendData:[[NSString stringWithFormat:@"%8.6f\" ", danhSachMau[diaChi+2]] dataUsingEncoding:NSUTF8StringEncoding]];
      
      // ---- đục
      [dongDuLieu appendData:[[NSString stringWithFormat:@"%@=\"", NSLocalizedString(@"độ đục", @"tên phần tử trong tệp XML")] dataUsingEncoding:NSUTF8StringEncoding]];
      [dongDuLieu appendData:[[NSString stringWithFormat:@"%8.6f\"/>\n", danhSachMau[diaChi+3]] dataUsingEncoding:NSUTF8StringEncoding]];

      chiSoMau++;
   }
   
   // ==== màu tập hợp
   float *mauTap = [toMau mauTapHop];
   [dongDuLieu appendData:[[NSString stringWithFormat:@"   <%@  ", NSLocalizedString(@"màuTậpHợp", @"tên phần tử trong tệp XML")] dataUsingEncoding:NSUTF8StringEncoding]];
   // ---- đỏ
   [dongDuLieu appendData:[[NSString stringWithFormat:@"%@=\"", NSLocalizedString(@"đỏ", @"tên phần tử trong tệp XML")] dataUsingEncoding:NSUTF8StringEncoding]];
   [dongDuLieu appendData:[[NSString stringWithFormat:@"%8.6f\" ", mauTap[0]] dataUsingEncoding:NSUTF8StringEncoding]];

   
   // ---- lục
   [dongDuLieu appendData:[[NSString stringWithFormat:@"%@=\"", NSLocalizedString(@"lục", @"tên phần tử trong tệp XML")] dataUsingEncoding:NSUTF8StringEncoding]];
   [dongDuLieu appendData:[[NSString stringWithFormat:@"%8.6f\" ",mauTap[1]] dataUsingEncoding:NSUTF8StringEncoding]];

   
   // ---- xanh
   [dongDuLieu appendData:[[NSString stringWithFormat:@"%@=\"", NSLocalizedString(@"xanh", @"tên phần tử trong tệp XML")] dataUsingEncoding:NSUTF8StringEncoding]];
   [dongDuLieu appendData:[[NSString stringWithFormat:@"%8.6f\" ", mauTap[2]] dataUsingEncoding:NSUTF8StringEncoding]];
   
   // ---- đục
   [dongDuLieu appendData:[[NSString stringWithFormat:@"%@=\"", NSLocalizedString(@"độ đục", @"tên phần tử trong tệp XML")] dataUsingEncoding:NSUTF8StringEncoding]];
   [dongDuLieu appendData:[[NSString stringWithFormat:@"%8.6f", mauTap[3]] dataUsingEncoding:NSUTF8StringEncoding]];
   [dongDuLieu appendData:[[NSString stringWithFormat:@"\"/>\n", NSLocalizedString(@"độ đục", @"tên phần tử trong tệp XML")] dataUsingEncoding:NSUTF8StringEncoding]];


   // ==== kết thúc phần tử danhSáchMàu
   [dongDuLieu appendData:[[NSString stringWithFormat:@"</%@>\n", NSLocalizedString(@"danhSáchMàu", @"tên phần tử trong tệp XML")]dataUsingEncoding:NSUTF8StringEncoding]];

   // ---- lưu tập tin
   [dongDuLieu writeToURL:URL_tapTin atomically:YES];
}
@end
