//
//  ToMauPhanDang4x4.h
//  Manjira
//
//  Created by 小小 on 11/10/2557.
//

#import <Foundation/Foundation.h>

@class ThongTinPhanDang;
@class ToMau;

@interface ToMauPhanDang4x4 : NSOperation {
   
   ThongTinPhanDang *thongTinPhanDang;
   ToMau *toMau;
   
   unsigned short soHang;
   unsigned short soLuongHang;
   
   unsigned short soCot;
   unsigned short soLuongCot;
}


- (id)initChoSoHang:(unsigned short)_soHang soLuongHang:(unsigned short)_soLuongHang
              soCot:(unsigned short)_soCot soLuongCot:(unsigned short)_soLuongCot
   thongTinPhanDang:(ThongTinPhanDang *)_thongTinPhanDang;

@end
