//
//  TinhPhanDang4x4.m
//  Manjira
//
//  Created by 小小 on 10/10/2557.
//

#import "TinhPhanDang4x4.h"
#import "ThongTinPhanDang.h"
#import "GiaiThuatPhanDang.h"

@implementation TinhPhanDang4x4

- (id)initVoiThongTinPhanDang:(ThongTinPhanDang *)thongTinPhanDang soLuongHang:(unsigned short)_soLuongHang soLuongCot:(unsigned short)_soLuongCot; {

   // ---- coi trừng cho các hàng và cột cuối
   unsigned short beCao = [thongTinPhanDang beCao];
   beRong = [thongTinPhanDang beRong];
   unsigned short _soHang = [thongTinPhanDang soHangDangTinh];
   unsigned short _soCot = [thongTinPhanDang soCotDangTinh];

   // ---- xem nếu ra ngoài phạm vi ảnh, hơn bề cao ảnh
   if( _soHang >= beCao )
      return NULL;
   if( _soCot >= beRong )
      return NULL;
   
   self = [super init];
   
   if( self ) {
      // ---- coi chừng đi ra ngoài phạm vi ảnh
      if( _soHang + _soLuongHang >= beCao ) {
         _soLuongHang = beCao - _soHang;
      }
      
      if( _soCot + _soLuongCot >= beRong ) {
         _soLuongCot = beRong - _soCot;
      }

      soHang = _soHang;
      soLuongHang = _soLuongHang;
      
      soCot = _soCot;
      soLuongCot = _soLuongCot;
      
      // ---- thông tin về phân dạng
      buoc = [thongTinPhanDang buocTinh];
      buocTinhPhanTu = buoc*0.25;
      banKinhNghiTinhMu2 = [thongTinPhanDang banKinhNghiTinhMu2];

      mu = [thongTinPhanDang mu];
      lapLaiToiDa = [thongTinPhanDang soLapLaiToiDa];

      // ---- góc trái dưới của ô
      gocX = soCot * buoc + [thongTinPhanDang gocX];
      gocY = soHang * buoc + [thongTinPhanDang gocY];

      // ---- chỉ dùng nếu tính phân dạng Julia
      tinhJulia = [thongTinPhanDang tinhJulia];
      hangSoJuliaX = [thongTinPhanDang hangSoThat];
      hangSoJuliaY = [thongTinPhanDang hangSoAo];
      
      // ---- cột và hàng trong ô
      cot = 0;
      hang = 0;
      
      // ---- tọa độ góc ô
      x = gocX;
      y = gocY;
      NSLog(@"TinhPhanDang4x4: initVoiThongTinPhanDang: soCot %d  sốHàng %d  (%5.3f; %5.3f)", soCot, soHang, gocX, gocY );
      
      mangSoLapLai = [thongTinPhanDang mangSoLapLai];
   }
   
   return self;
}


#pragma mark ---- Main
- (void)main {
   
   if( ![self isCancelled] ) {
      hang = 0;
      
      while( hang < soLuongHang ) {
         cot = 0;
         x = gocX;

         // ---- địa chỉ trong ảnh xuất
         diaChi = (soHang * beRong + soCot) << 2;
   
         while( cot < soLuongCot ) {
            // ---- tính
            unsigned int soLuongLapLai0 = 0;
            unsigned int soLuongLapLai1 = 0;
            unsigned int soLuongLapLai2 = 0;
            unsigned int soLuongLapLai3 = 0;

            if( tinhJulia ) {
               soLuongLapLai0 = [giaiThuat tinhDiemThat:x-buocTinhPhanTu ao:y-buocTinhPhanTu
                                             hangSoThat:hangSoJuliaX ao:hangSoJuliaY banKinhThoatMu2:banKinhNghiTinhMu2 mu:mu
                                         gioiHanhLapLai:lapLaiToiDa];
               soLuongLapLai1 = [giaiThuat tinhDiemThat:x+buocTinhPhanTu ao:y-buocTinhPhanTu
                                             hangSoThat:hangSoJuliaX ao:hangSoJuliaY banKinhThoatMu2:banKinhNghiTinhMu2 mu:mu
                                         gioiHanhLapLai:lapLaiToiDa];
               soLuongLapLai2 = [giaiThuat tinhDiemThat:x-buocTinhPhanTu ao:y+buocTinhPhanTu
                                             hangSoThat:hangSoJuliaX ao:hangSoJuliaY banKinhThoatMu2:banKinhNghiTinhMu2 mu:mu
                                         gioiHanhLapLai:lapLaiToiDa];
               soLuongLapLai3 = [giaiThuat tinhDiemThat:x+buocTinhPhanTu ao:y+buocTinhPhanTu
                                             hangSoThat:hangSoJuliaX ao:hangSoJuliaY banKinhThoatMu2:banKinhNghiTinhMu2 mu:mu
                                         gioiHanhLapLai:lapLaiToiDa];
            }
            else {
               soLuongLapLai0 = [giaiThuat tinhDiemThat:x-buocTinhPhanTu ao:y-buocTinhPhanTu
                                        banKinhThoatMu2:banKinhNghiTinhMu2 mu:mu gioiHanhLapLai:lapLaiToiDa];
               soLuongLapLai1 = [giaiThuat tinhDiemThat:x+buocTinhPhanTu ao:y-buocTinhPhanTu
                                        banKinhThoatMu2:banKinhNghiTinhMu2 mu:mu gioiHanhLapLai:lapLaiToiDa];
               soLuongLapLai2 = [giaiThuat tinhDiemThat:x-buocTinhPhanTu ao:y+buocTinhPhanTu
                                        banKinhThoatMu2:banKinhNghiTinhMu2 mu:mu gioiHanhLapLai:lapLaiToiDa];
               soLuongLapLai3 = [giaiThuat tinhDiemThat:x+buocTinhPhanTu ao:y+buocTinhPhanTu
                                        banKinhThoatMu2:banKinhNghiTinhMu2 mu:mu gioiHanhLapLai:lapLaiToiDa];
            }
         
            // ---- giữ số lặp vòng tính
            mangSoLapLai[diaChi] = soLuongLapLai0;
            mangSoLapLai[diaChi+1] = soLuongLapLai1;
            mangSoLapLai[diaChi+2] = soLuongLapLai2;
            mangSoLapLai[diaChi+3] = soLuongLapLai3;
            
            
            // ---- xem tính hàng xong chưa
            cot++;
            x += buoc;
            diaChi += 4;
            
            if( [self isCancelled] )
               return;
         }
         hang++;
         soHang++;
         y += buoc;
      }
      
      // ---- kêu tính chùm tiếp
      [[NSNotificationCenter defaultCenter] postNotificationName:@"星凤NângCấpẢnhXuất" object:self];
   }
   
}


#pragma mark ---- Biến
@synthesize soHang;
@synthesize soLuongHang;
@synthesize soCot;
@synthesize soLuongCot;

@synthesize giaiThuat;

@end
