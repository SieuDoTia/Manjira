//
//  AppDelegate.h
//  Manjira
//
//  Created by 小小 on 20/11/2556.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>

@property (assign) IBOutlet NSWindow *window;

@end
