//
//  ManChonThuTapTin.h
//  Manjira
//
//  Created by 小小 on 20/12/2556.
//  Copyright (c) 2556 BE 星凤. All rights reserved.
//

#import <Cocoa/Cocoa.h>

#define kTAP_TIN__PNG 0
#define kTAP_TIN__EXR 1

@interface ManChonThuTapTin : NSView {

   IBOutlet NSMatrix *maTran;
   unsigned char thuTapTin;
}

- (IBAction)doiThuTapTin:(id)sender;

@property (readonly) unsigned char thuTapTin;

@end
