//
//  LuuEXR.h
//  Manjira
//
//  Created by 小小 on 18/12/2556.
//

#import <Foundation/Foundation.h>

@interface LuuEXR : NSObject

+ (void)luuEXRHalf_voiURL:(NSURL *)URL_tapTin beRong:(unsigned int)beRong beCao:(unsigned int)beCao
                 vaKenhDo:(unsigned char *)kenhDo kenhLuc:(unsigned char *)kenhLuc kenhXanh:(unsigned char *)kenhXanh
                  kenhDuc:(unsigned char *)kenhDuc;

+ (void)luuEXRFloat_voiURL:(NSURL *)URL_tapTin beRong:(unsigned int)beRong beCao:(unsigned int)beCao
                 vaKenhDo:(unsigned char *)kenhDo kenhLuc:(unsigned char *)kenhLuc kenhXanh:(unsigned char *)kenhXanh
                  kenhDuc:(unsigned char *)kenhDuc;

@end
